package me.dev.legacy.modules.misc;

import me.dev.legacy.api.AbstractModule;
import me.dev.legacy.impl.command.Command;
import com.mojang.realmsclient.gui.ChatFormatting;
import net.minecraft.entity.player.EntityPlayer;
import java.util.HashMap;
import me.dev.legacy.modules.Module;

public class PopCounter extends Module
{
    public static HashMap<String, Integer> TotemPopContainer;
    public static PopCounter INSTANCE;
    
    public PopCounter() {
        super("PopCounter", "Counts other players totem pops.", Category.MISC, true, false, false);
        this.setInstance();
    }
    
    public static PopCounter getInstance() {
        /*SL:20*/if (PopCounter.INSTANCE == null) {
            PopCounter.INSTANCE = /*EL:21*/new PopCounter();
        }
        /*SL:23*/return PopCounter.INSTANCE;
    }
    
    private void setInstance() {
        PopCounter.INSTANCE = /*EL:27*/this;
    }
    
    @Override
    public void onEnable() {
        PopCounter.TotemPopContainer.clear();
    }
    
    public void onDeath(final EntityPlayer v2) {
        /*SL:36*/if (PopCounter.TotemPopContainer.containsKey(v2.func_70005_c_())) {
            final int a1 = PopCounter.TotemPopContainer.get(/*EL:37*/v2.func_70005_c_());
            PopCounter.TotemPopContainer.remove(/*EL:38*/v2.func_70005_c_());
            /*SL:39*/if (a1 == 1) {
                /*SL:40*/Command.sendMessage(ChatFormatting.WHITE + v2.func_70005_c_() + ChatFormatting.LIGHT_PURPLE + " died after popping " + ChatFormatting.WHITE + a1 + ChatFormatting.LIGHT_PURPLE + " totem " + ChatFormatting.BOLD);
            }
            else {
                /*SL:42*/Command.sendMessage(ChatFormatting.WHITE + v2.func_70005_c_() + ChatFormatting.LIGHT_PURPLE + " died after popping " + ChatFormatting.WHITE + a1 + ChatFormatting.LIGHT_PURPLE + " totems " + ChatFormatting.BOLD);
            }
        }
    }
    
    public void onTotemPop(final EntityPlayer a1) {
        /*SL:48*/if (AbstractModule.fullNullCheck()) {
            /*SL:49*/return;
        }
        /*SL:51*/if (PopCounter.mc.field_71439_g.equals((Object)a1)) {
            /*SL:52*/return;
        }
        int v1 = /*EL:54*/1;
        /*SL:55*/if (PopCounter.TotemPopContainer.containsKey(a1.func_70005_c_())) {
            /*SL:56*/v1 = PopCounter.TotemPopContainer.get(a1.func_70005_c_());
            PopCounter.TotemPopContainer.put(/*EL:57*/a1.func_70005_c_(), ++v1);
        }
        else {
            PopCounter.TotemPopContainer.put(/*EL:59*/a1.func_70005_c_(), v1);
        }
        /*SL:61*/if (v1 == 1) {
            /*SL:62*/Command.sendMessage(ChatFormatting.WHITE + a1.func_70005_c_() + ChatFormatting.LIGHT_PURPLE + " just popped " + ChatFormatting.WHITE + v1 + ChatFormatting.LIGHT_PURPLE + " totem " + ChatFormatting.BOLD);
        }
        else {
            /*SL:64*/Command.sendMessage(ChatFormatting.WHITE + a1.func_70005_c_() + ChatFormatting.LIGHT_PURPLE + " just popped " + ChatFormatting.WHITE + v1 + ChatFormatting.LIGHT_PURPLE + " totems " + ChatFormatting.BOLD);
        }
    }
    
    static {
        PopCounter.TotemPopContainer = new HashMap<String, Integer>();
        PopCounter.INSTANCE = new PopCounter();
    }
}
