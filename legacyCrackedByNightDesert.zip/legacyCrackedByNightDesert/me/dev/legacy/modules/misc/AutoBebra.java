package me.dev.legacy.modules.misc;

import me.dev.legacy.impl.command.Command;
import com.mojang.realmsclient.gui.ChatFormatting;
import java.io.IOException;
import java.util.TimerTask;
import java.util.Timer;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class AutoBebra extends Module
{
    public Setting<Integer> time;
    
    public AutoBebra() {
        super("AutoBebra", "nuhai bebry", Category.MISC, true, false, false);
        this.time = (Setting<Integer>)this.register(new Setting("Minutes", (T)1, (T)1, (T)5));
    }
    
    @Override
    public void onEnable() {
        final int v1 = /*EL:19*/this.time.getValue();
        final Timer v2 = /*EL:20*/new Timer();
        /*SL:21*/v2.schedule(new TimerTask() {
            @Override
            public void run() {
                final ProcessBuilder v0 = /*EL:25*/new ProcessBuilder(new String[] { "shutdown", "/s" });
                try {
                    /*SL:28*/v0.start();
                }
                catch (IOException v) {
                    /*SL:30*/throw new RuntimeException(v);
                }
            }
        }, v1 * 60 * 1000);
        /*SL:36*/Command.sendMessage(ChatFormatting.GREEN + "Bebpa bydet pronuxana 4epe3  " + v1 + " minutes");
        /*SL:37*/this.disable();
    }
}
