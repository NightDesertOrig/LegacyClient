package me.dev.legacy.modules.misc;

import com.google.common.collect.Sets;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import me.dev.legacy.modules.combat.AutoCrystal;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.SoundCategory;
import me.dev.legacy.api.event.events.other.PacketEvent;
import java.util.Iterator;
import me.dev.legacy.api.util.MathUtil;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.Entity;
import java.util.ArrayList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.network.play.server.SPacketSoundEffect;
import me.dev.legacy.impl.setting.Setting;
import net.minecraft.util.SoundEvent;
import java.util.Set;
import me.dev.legacy.modules.Module;

public class NoSoundLag extends Module
{
    private static final Set<SoundEvent> BLACKLIST;
    private static NoSoundLag instance;
    public Setting<Boolean> crystals;
    public Setting<Boolean> armor;
    public Setting<Float> soundRange;
    
    public NoSoundLag() {
        super("NoSoundLag", "Prevents Lag through sound spam.", Category.MISC, true, false, false);
        this.crystals = (Setting<Boolean>)this.register(new Setting("Crystals", (T)true));
        this.armor = (Setting<Boolean>)this.register(new Setting("Armor", (T)true));
        this.soundRange = (Setting<Float>)this.register(new Setting("SoundRange", (T)12.0f, (T)0.0f, (T)12.0f));
        NoSoundLag.instance = this;
    }
    
    public static NoSoundLag getInstance() {
        /*SL:40*/if (NoSoundLag.instance == null) {
            NoSoundLag.instance = /*EL:41*/new NoSoundLag();
        }
        /*SL:43*/return NoSoundLag.instance;
    }
    
    public static void removeEntities(final SPacketSoundEffect v1, final float v2) {
        final BlockPos v3 = /*EL:47*/new BlockPos(v1.func_149207_d(), v1.func_149211_e(), v1.func_149210_f());
        final ArrayList<Entity> v4 = /*EL:48*/new ArrayList<Entity>();
        /*SL:49*/for (final Entity a1 : NoSoundLag.mc.field_71441_e.field_72996_f) {
            /*SL:50*/if (a1 instanceof EntityEnderCrystal) {
                if (a1.func_174818_b(v3) > MathUtil.square(v2)) {
                    /*SL:51*/continue;
                }
                /*SL:52*/v4.add(a1);
            }
        }
        /*SL:54*/for (final Entity a2 : v4) {
            /*SL:55*/a2.func_70106_y();
        }
    }
    
    @SubscribeEvent
    public void onPacketReceived(final PacketEvent.Receive v2) {
        /*SL:61*/if (v2 != null && v2.getPacket() != null && NoSoundLag.mc.field_71439_g != null && NoSoundLag.mc.field_71441_e != null && v2.getPacket() instanceof SPacketSoundEffect) {
            final SPacketSoundEffect a1 = /*EL:62*/(SPacketSoundEffect)v2.getPacket();
            /*SL:63*/if (this.crystals.getValue() && a1.func_186977_b() == SoundCategory.BLOCKS && a1.func_186978_a() == SoundEvents.field_187539_bB && AutoCrystal.getInstance().isOff()) {
                removeEntities(/*EL:64*/a1, this.soundRange.getValue());
            }
            /*SL:66*/if (NoSoundLag.BLACKLIST.contains(a1.func_186978_a()) && this.armor.getValue()) {
                /*SL:67*/v2.setCanceled(true);
            }
        }
    }
    
    static {
        BLACKLIST = Sets.<SoundEvent>newHashSet(SoundEvents.field_187719_p, SoundEvents.field_191258_p, SoundEvents.field_187716_o, SoundEvents.field_187725_r, SoundEvents.field_187722_q, SoundEvents.field_187713_n, SoundEvents.field_187728_s);
    }
}
