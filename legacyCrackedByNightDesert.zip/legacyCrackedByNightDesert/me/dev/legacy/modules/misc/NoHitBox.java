package me.dev.legacy.modules.misc;

import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class NoHitBox extends Module
{
    private static NoHitBox INSTANCE;
    public Setting<Boolean> pickaxe;
    public Setting<Boolean> crystal;
    public Setting<Boolean> gapple;
    
    public NoHitBox() {
        super("NoHitBox", "nhb", Category.MISC, true, false, false);
        this.pickaxe = (Setting<Boolean>)this.register(new Setting("Pickaxe", (T)true));
        this.crystal = (Setting<Boolean>)this.register(new Setting("Crystal", (T)true));
        this.gapple = (Setting<Boolean>)this.register(new Setting("Gapple", (T)true));
        this.setInstance();
    }
    
    public static NoHitBox getINSTANCE() {
        /*SL:22*/if (NoHitBox.INSTANCE == null) {
            NoHitBox.INSTANCE = /*EL:23*/new NoHitBox();
        }
        /*SL:25*/return NoHitBox.INSTANCE;
    }
    
    private void setInstance() {
        NoHitBox.INSTANCE = /*EL:29*/this;
    }
    
    static {
        NoHitBox.INSTANCE = new NoHitBox();
    }
}
