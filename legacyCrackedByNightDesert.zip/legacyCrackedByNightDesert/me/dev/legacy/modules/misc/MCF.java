package me.dev.legacy.modules.misc;

import net.minecraft.entity.Entity;
import me.dev.legacy.impl.command.Command;
import com.mojang.realmsclient.gui.ChatFormatting;
import me.dev.legacy.Legacy;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.RayTraceResult;
import org.lwjgl.input.Mouse;
import me.dev.legacy.modules.Module;

public class MCF extends Module
{
    private boolean clicked;
    
    public MCF() {
        super("MCF", "Middleclick Friends.", Category.MISC, true, false, false);
        this.clicked = false;
    }
    
    @Override
    public void onUpdate() {
        /*SL:21*/if (Mouse.isButtonDown(2)) {
            /*SL:22*/if (!this.clicked && MCF.mc.field_71462_r == null) {
                /*SL:23*/this.onClick();
            }
            /*SL:25*/this.clicked = true;
        }
        else {
            /*SL:27*/this.clicked = false;
        }
    }
    
    private void onClick() {
        RayTraceResult v2 = MCF.mc.field_71476_x;
        /*SL:34*/if (v2 != null && v2.field_72313_a == RayTraceResult.Type.ENTITY && (v2 = v2.field_72308_g) instanceof EntityPlayer) {
            /*SL:35*/if (Legacy.friendManager.isFriend(v2.func_70005_c_())) {
                Legacy.friendManager.removeFriend(/*EL:36*/v2.func_70005_c_());
                /*SL:37*/Command.sendMessage(ChatFormatting.RED + v2.func_70005_c_() + ChatFormatting.RED + " has been unfriended.");
            }
            else {
                Legacy.friendManager.addFriend(/*EL:39*/v2.func_70005_c_());
                /*SL:40*/Command.sendMessage(ChatFormatting.AQUA + v2.func_70005_c_() + ChatFormatting.AQUA + " has been friended.");
            }
        }
        /*SL:43*/this.clicked = true;
    }
}
