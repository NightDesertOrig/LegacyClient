package me.dev.legacy.modules.misc;

import me.dev.legacy.impl.command.Command;
import com.mojang.realmsclient.gui.ChatFormatting;
import net.minecraft.client.audio.ISound;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.init.SoundEvents;
import java.io.IOException;
import java.io.FileWriter;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.network.play.server.SPacketChunkData;
import me.dev.legacy.api.AbstractModule;
import me.dev.legacy.api.event.events.other.PacketEvent;
import net.minecraft.client.Minecraft;
import net.minecraft.nbt.NBTTagCompound;
import java.util.Iterator;
import java.io.File;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class StashLogger extends Module
{
    private final Setting<Boolean> chests;
    private final Setting<Integer> chestsValue;
    private final Setting<Boolean> Shulkers;
    private final Setting<Integer> shulkersValue;
    private final Setting<Boolean> writeToFile;
    File mainFolder;
    final Iterator<NBTTagCompound> iterator;
    
    public StashLogger() {
        super("StashLogger", "Logs stashes", Category.MISC, true, false, false);
        this.chests = (Setting<Boolean>)this.register(new Setting("Chests", (T)true));
        this.chestsValue = (Setting<Integer>)this.register(new Setting("ChestsValue", (T)4, (T)1, (T)30, a1 -> this.chests.getValue()));
        this.Shulkers = (Setting<Boolean>)this.register(new Setting("Shulkers", (T)true));
        this.shulkersValue = (Setting<Integer>)this.register(new Setting("ShulkersValue", (T)4, (T)1, (T)30, a1 -> this.Shulkers.getValue()));
        this.writeToFile = (Setting<Boolean>)this.register(new Setting("CoordsSaver", (T)true));
        this.mainFolder = new File(Minecraft.func_71410_x().field_71412_D + File.separator + "legacy");
        this.iterator = null;
    }
    
    @SubscribeEvent
    public void onPacket(final PacketEvent v-4) {
        /*SL:38*/if (AbstractModule.nullCheck()) {
            /*SL:39*/return;
        }
        /*SL:41*/if (v-4.getPacket() instanceof SPacketChunkData) {
            final SPacketChunkData sPacketChunkData = /*EL:42*/(SPacketChunkData)v-4.getPacket();
            int n = /*EL:43*/0;
            int n2 = /*EL:44*/0;
            /*SL:45*/for (final NBTTagCompound v1 : sPacketChunkData.func_189554_f()) {
                final String a1 = /*EL:46*/v1.func_74779_i("id");
                /*SL:47*/if (a1.equals("minecraft:chest") && this.chests.getValue()) {
                    /*SL:48*/++n;
                }
                else {
                    /*SL:51*/if (!a1.equals("minecraft:shulker_box")) {
                        continue;
                    }
                    if (!this.Shulkers.getValue()) {
                        /*SL:52*/continue;
                    }
                    /*SL:54*/++n2;
                }
            }
            /*SL:57*/if (n >= this.chestsValue.getValue()) {
                /*SL:58*/this.SendMessage(String.format("%s chests located at X: %s, Z: %s", n, sPacketChunkData.func_149273_e() * 16, sPacketChunkData.func_149271_f() * 16), true);
            }
            /*SL:60*/if (n2 >= this.shulkersValue.getValue()) {
                /*SL:61*/this.SendMessage(String.format("%s shulker boxes at X: %s, Z: %s", n2, sPacketChunkData.func_149273_e() * 16, sPacketChunkData.func_149271_f() * 16), true);
            }
        }
    }
    
    private void SendMessage(final String v2, final boolean v3) {
        final String v4 = /*EL:67*/Minecraft.func_71410_x().func_71356_B() ? "singleplayer".toUpperCase() : StashLogger.mc.func_147104_D().field_78845_b;
        /*SL:68*/if (this.writeToFile.getValue() && v3) {
            try {
                final FileWriter a1 = /*EL:70*/new FileWriter(this.mainFolder + "/stashes.txt", true);
                /*SL:71*/a1.write("[" + v4 + "]: " + v2 + "\n");
                /*SL:72*/a1.close();
            }
            catch (IOException a2) {
                /*SL:75*/a2.printStackTrace();
            }
        }
        StashLogger.mc.func_147118_V().func_147682_a(/*EL:78*/(ISound)PositionedSoundRecord.func_194007_a(SoundEvents.field_187604_bf, 1.0f, 1.0f));
        /*SL:79*/Command.sendMessage(ChatFormatting.GREEN + v2);
    }
}
