package me.dev.legacy.modules.misc;

import net.minecraft.entity.item.EntityItem;
import net.minecraft.item.ItemStack;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import me.dev.legacy.impl.command.Command;
import java.util.Random;
import me.dev.legacy.modules.Module;

public class Dupe extends Module
{
    private final Random random;
    
    public Dupe() {
        super("Dupe", "Ez dupe.", Category.MISC, true, false, false);
        this.random = new Random();
    }
    
    @Override
    public void onEnable() {
        final EntityPlayerSP field_71439_g = Dupe.mc.field_71439_g;
        final WorldClient field_71441_e = Dupe.mc.field_71441_e;
        /*SL:24*/if (field_71439_g == null || Dupe.mc.field_71441_e == null) {
            return;
        }
        final ItemStack func_184614_ca = /*EL:26*/field_71439_g.func_184614_ca();
        /*SL:28*/if (func_184614_ca.func_190926_b()) {
            /*SL:29*/Command.sendMessage("You need to hold an item in hand to dupe!");
            /*SL:30*/this.disable();
            /*SL:31*/return;
        }
        final int n = /*EL:34*/this.random.nextInt(31) + 1;
        /*SL:36*/for (int v0 = 0; v0 <= n; ++v0) {
            final EntityItem v = /*EL:37*/field_71439_g.func_146097_a(func_184614_ca.func_77946_l(), false, true);
            /*SL:38*/if (v != null) {
                field_71441_e.func_73027_a(v.field_145783_c, (Entity)v);
            }
        }
        int v0 = /*EL:41*/n * func_184614_ca.func_190916_E();
        /*SL:42*/field_71439_g.func_71165_d("I just used the Legacy Client Dupe and got " + v0 + " " + func_184614_ca.func_82833_r() + " thanks to Legacy dev's!");
        /*SL:43*/this.disable();
    }
}
