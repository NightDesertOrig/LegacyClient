package me.dev.legacy.modules.misc;

import net.minecraft.block.BlockObsidian;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.block.Block;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.Vec3i;
import net.minecraft.util.EnumFacing;
import me.dev.legacy.api.util.BlockInteractHelper;
import java.util.Iterator;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.network.Packet;
import net.minecraft.entity.Entity;
import net.minecraft.network.play.client.CPacketEntityAction;
import me.dev.legacy.impl.command.Command;
import com.mojang.realmsclient.gui.ChatFormatting;
import net.minecraft.util.math.Vec3d;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class PortalBuilder extends Module
{
    public Setting<Boolean> rotate;
    private final Setting<Integer> tick_for_place;
    Vec3d[] targets;
    int new_slot;
    int old_slot;
    int y_level;
    int tick_runs;
    int blocks_placed;
    int offset_step;
    boolean sneak;
    
    public PortalBuilder() {
        super("PortalBuilder", "Auto nether portal.", Category.MISC, true, false, false);
        this.rotate = (Setting<Boolean>)this.register(new Setting("Rotate", (T)true));
        this.tick_for_place = (Setting<Integer>)this.register(new Setting("BPT", (T)2, (T)1, (T)8));
        this.targets = new Vec3d[] { new Vec3d(1.0, 1.0, 0.0), new Vec3d(1.0, 1.0, 1.0), new Vec3d(1.0, 1.0, 2.0), new Vec3d(1.0, 1.0, 3.0), new Vec3d(1.0, 2.0, 0.0), new Vec3d(1.0, 3.0, 0.0), new Vec3d(1.0, 4.0, 0.0), new Vec3d(1.0, 5.0, 0.0), new Vec3d(1.0, 5.0, 1.0), new Vec3d(1.0, 5.0, 2.0), new Vec3d(1.0, 5.0, 3.0), new Vec3d(1.0, 4.0, 3.0), new Vec3d(1.0, 3.0, 3.0), new Vec3d(1.0, 2.0, 3.0) };
        this.new_slot = 0;
        this.old_slot = 0;
        this.y_level = 0;
        this.tick_runs = 0;
        this.blocks_placed = 0;
        this.offset_step = 0;
        this.sneak = false;
    }
    
    @Override
    public void onEnable() {
        /*SL:46*/if (PortalBuilder.mc.field_71439_g != null) {
            /*SL:48*/this.old_slot = PortalBuilder.mc.field_71439_g.field_71071_by.field_70461_c;
            /*SL:49*/this.new_slot = this.find_in_hotbar();
            /*SL:51*/if (this.new_slot == -1) {
                /*SL:52*/Command.sendMessage(ChatFormatting.RED + "Cannot find obi in hotbar!");
                /*SL:53*/this.toggle();
            }
            /*SL:56*/this.y_level = (int)Math.round(PortalBuilder.mc.field_71439_g.field_70163_u);
        }
    }
    
    @Override
    public void onDisable() {
        /*SL:65*/if (PortalBuilder.mc.field_71439_g != null) {
            /*SL:67*/if (this.new_slot != this.old_slot && this.old_slot != -1) {
                PortalBuilder.mc.field_71439_g.field_71071_by.field_70461_c = /*EL:68*/this.old_slot;
            }
            /*SL:71*/if (this.sneak) {
                PortalBuilder.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:72*/(Packet)new CPacketEntityAction((Entity)PortalBuilder.mc.field_71439_g, CPacketEntityAction.Action.STOP_SNEAKING));
                /*SL:74*/this.sneak = false;
            }
            /*SL:77*/this.old_slot = -1;
            /*SL:78*/this.new_slot = -1;
        }
    }
    
    @Override
    public void onUpdate() {
        /*SL:86*/if (PortalBuilder.mc.field_71439_g != null) {
            /*SL:88*/this.blocks_placed = 0;
            /*SL:90*/while (this.blocks_placed < this.tick_for_place.getValue()) {
                /*SL:92*/if (this.offset_step >= this.targets.length) {
                    /*SL:93*/this.offset_step = 0;
                    /*SL:94*/break;
                }
                final BlockPos blockPos = /*EL:97*/new BlockPos(this.targets[this.offset_step]);
                final BlockPos func_177977_b = /*EL:98*/new BlockPos(PortalBuilder.mc.field_71439_g.func_174791_d()).func_177982_a(blockPos.func_177958_n(), blockPos.func_177956_o(), blockPos.func_177952_p()).func_177977_b();
                boolean b = /*EL:100*/true;
                /*SL:102*/if (!PortalBuilder.mc.field_71441_e.func_180495_p(func_177977_b).func_185904_a().func_76222_j()) {
                    /*SL:103*/b = false;
                }
                /*SL:106*/for (final Entity v1 : PortalBuilder.mc.field_71441_e.func_72839_b((Entity)null, new AxisAlignedBB(func_177977_b))) {
                    /*SL:107*/if (!(v1 instanceof EntityItem)) {
                        if (v1 instanceof EntityXPOrb) {
                            continue;
                        }
                        /*SL:108*/b = false;
                        break;
                    }
                }
                /*SL:112*/if (b && this.place_blocks(func_177977_b)) {
                    /*SL:113*/++this.blocks_placed;
                }
                /*SL:116*/++this.offset_step;
            }
            /*SL:120*/if (this.blocks_placed > 0 && this.new_slot != this.old_slot) {
                PortalBuilder.mc.field_71439_g.field_71071_by.field_70461_c = /*EL:121*/this.old_slot;
            }
            /*SL:124*/++this.tick_runs;
        }
    }
    
    private boolean place_blocks(final BlockPos v-5) {
        /*SL:130*/if (!PortalBuilder.mc.field_71441_e.func_180495_p(v-5).func_185904_a().func_76222_j()) {
            /*SL:131*/return false;
        }
        /*SL:134*/if (!BlockInteractHelper.checkForNeighbours(v-5)) {
            /*SL:135*/return false;
        }
        /*SL:138*/for (final EnumFacing enumFacing : EnumFacing.values()) {
            final BlockPos v1 = /*EL:141*/v-5.func_177972_a(enumFacing);
            final EnumFacing v2 = /*EL:143*/enumFacing.func_176734_d();
            /*SL:145*/if (BlockInteractHelper.canBeClicked(v1)) {
                PortalBuilder.mc.field_71439_g.field_71071_by.field_70461_c = /*EL:147*/this.new_slot;
                final Block a1;
                /*SL:149*/if (BlockInteractHelper.blackList.contains(a1 = PortalBuilder.mc.field_71441_e.func_180495_p(v1).func_177230_c())) {
                    PortalBuilder.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:150*/(Packet)new CPacketEntityAction((Entity)PortalBuilder.mc.field_71439_g, CPacketEntityAction.Action.START_SNEAKING));
                    /*SL:151*/this.sneak = true;
                }
                final Vec3d v3 = /*EL:154*/new Vec3d((Vec3i)v1).func_72441_c(0.5, 0.5, 0.5).func_178787_e(new Vec3d(v2.func_176730_m()).func_186678_a(0.5));
                /*SL:156*/if (this.rotate.getValue()) {
                    /*SL:157*/BlockInteractHelper.faceVectorPacketInstant(v3);
                }
                PortalBuilder.mc.field_71442_b.func_187099_a(PortalBuilder.mc.field_71439_g, PortalBuilder.mc.field_71441_e, /*EL:160*/v1, v2, v3, EnumHand.MAIN_HAND);
                PortalBuilder.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
                /*SL:163*/return true;
            }
        }
        /*SL:166*/return false;
    }
    
    private int find_in_hotbar() {
        /*SL:172*/for (int i = 0; i < 9; ++i) {
            final ItemStack v0 = PortalBuilder.mc.field_71439_g.field_71071_by.func_70301_a(/*EL:174*/i);
            /*SL:176*/if (v0 != ItemStack.field_190927_a && v0.func_77973_b() instanceof ItemBlock) {
                final Block v = /*EL:178*/((ItemBlock)v0.func_77973_b()).func_179223_d();
                /*SL:180*/if (v instanceof BlockObsidian) {
                    /*SL:181*/return i;
                }
            }
        }
        /*SL:185*/return -1;
    }
}
