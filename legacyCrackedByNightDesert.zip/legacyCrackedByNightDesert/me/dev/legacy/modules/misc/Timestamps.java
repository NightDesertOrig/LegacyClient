package me.dev.legacy.modules.misc;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.util.text.TextComponentString;
import com.mojang.realmsclient.gui.ChatFormatting;
import java.text.SimpleDateFormat;
import java.util.Date;
import net.minecraftforge.client.event.ClientChatReceivedEvent;
import me.dev.legacy.modules.Module;

public class Timestamps extends Module
{
    public Timestamps() {
        super("Timestamps", "Prefixes chat messages with the time", Category.MISC, true, false, false);
    }
    
    @SubscribeEvent
    public void onClientChatReceived(final ClientChatReceivedEvent a1) {
        final Date v1 = /*EL:19*/new Date();
        final SimpleDateFormat v2 = /*EL:20*/new SimpleDateFormat("HH:mm");
        final String v3 = /*EL:21*/v2.format(v1);
        final TextComponentString v4 = /*EL:22*/new TextComponentString(ChatFormatting.GREEN + "<" + ChatFormatting.GREEN + v3 + ChatFormatting.GREEN + ">" + ChatFormatting.GREEN + " ");
        /*SL:23*/a1.setMessage(v4.func_150257_a(a1.getMessage()));
    }
}
