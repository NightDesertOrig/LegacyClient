package me.dev.legacy.modules.player;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.util.EnumHand;
import me.dev.legacy.api.util.BlockUtil;
import me.dev.legacy.api.event.events.block.BlockEvent;
import net.minecraft.item.ItemStack;
import me.dev.legacy.modules.combat.Surround;
import net.minecraft.init.Items;
import me.dev.legacy.api.util.RenderUtil;
import java.awt.Color;
import me.dev.legacy.Legacy;
import me.dev.legacy.api.event.events.render.Render3DEvent;
import me.dev.legacy.api.AbstractModule;
import me.dev.legacy.api.util.InventoryUtil;
import net.minecraft.item.ItemSword;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.init.Blocks;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.math.BlockPos;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.api.util.Timer;
import me.dev.legacy.modules.Module;

public class FastBreak extends Module
{
    private static FastBreak INSTANCE;
    private final Timer timer;
    public Setting<Mode> mode;
    public Setting<Float> damage;
    public Setting<Boolean> webSwitch;
    public Setting<Boolean> doubleBreak;
    public Setting<Boolean> autosw;
    public Setting<Boolean> render;
    public Setting<Boolean> box;
    private final Setting<Integer> boxAlpha;
    public Setting<Boolean> outline;
    private final Setting<Float> lineWidth;
    public BlockPos currentPos;
    public IBlockState currentBlockState;
    private int lasthotbarslot;
    
    public FastBreak() {
        super("FastBreak", "Speeds up mining.", Category.PLAYER, true, false, false);
        this.timer = new Timer();
        this.mode = (Setting<Mode>)this.register(new Setting("Mode", (T)Mode.PACKET));
        this.damage = (Setting<Float>)this.register(new Setting("Damage", (T)0.7f, (T)0.0f, (T)1.0f, a1 -> this.mode.getValue() == Mode.DAMAGE));
        this.webSwitch = (Setting<Boolean>)this.register(new Setting("WebSwitch", (T)false));
        this.doubleBreak = (Setting<Boolean>)this.register(new Setting("DoubleBreak", (T)false));
        this.autosw = (Setting<Boolean>)this.register(new Setting("AutoSwitch", (T)false));
        this.render = (Setting<Boolean>)this.register(new Setting("Render", (T)false));
        this.box = (Setting<Boolean>)this.register(new Setting("Box", (T)false, a1 -> this.render.getValue()));
        this.boxAlpha = (Setting<Integer>)this.register(new Setting("BoxAlpha", (T)85, (T)0, (T)255, a1 -> this.box.getValue() && this.render.getValue()));
        this.outline = (Setting<Boolean>)this.register(new Setting("Outline", (T)true, a1 -> this.render.getValue()));
        this.lineWidth = (Setting<Float>)this.register(new Setting("Width", (T)1.0f, (T)0.1f, (T)5.0f, a1 -> this.outline.getValue() && this.render.getValue()));
        this.setInstance();
    }
    
    public static FastBreak getInstance() {
        /*SL:49*/if (FastBreak.INSTANCE == null) {
            FastBreak.INSTANCE = /*EL:50*/new FastBreak();
        }
        /*SL:52*/return FastBreak.INSTANCE;
    }
    
    private void setInstance() {
        FastBreak.INSTANCE = /*EL:56*/this;
    }
    
    @Override
    public void onTick() {
        /*SL:61*/if (this.currentPos != null) {
            /*SL:62*/if (!FastBreak.mc.field_71441_e.func_180495_p(this.currentPos).equals(this.currentBlockState) || FastBreak.mc.field_71441_e.func_180495_p(this.currentPos).func_177230_c() == Blocks.field_150350_a) {
                /*SL:63*/this.currentPos = null;
                /*SL:64*/this.currentBlockState = null;
            }
            else/*SL:65*/ if (this.webSwitch.getValue() && this.currentBlockState.func_177230_c() == Blocks.field_150321_G && FastBreak.mc.field_71439_g.func_184614_ca().func_77973_b() instanceof ItemPickaxe) {
                /*SL:66*/InventoryUtil.switchToHotbarSlot(ItemSword.class, false);
            }
        }
    }
    
    @Override
    public void onUpdate() {
        /*SL:73*/if (AbstractModule.fullNullCheck()) {
            /*SL:74*/return;
        }
        FastBreak.mc.field_71442_b.field_78781_i = /*EL:76*/0;
    }
    
    @Override
    public void onRender3D(final Render3DEvent v-2) {
        /*SL:81*/if (this.render.getValue() && this.currentPos != null && this.currentBlockState.func_177230_c() == Blocks.field_150343_Z) {
            final Color color = /*EL:82*/new Color(this.timer.passedMs((int)(2000.0f * Legacy.serverManager.getTpsFactor())) ? 0 : 255, this.timer.passedMs((int)(2000.0f * Legacy.serverManager.getTpsFactor())) ? 255 : 0, 0, 255);
            /*SL:83*/RenderUtil.drawBoxESP(this.currentPos, color, false, color, this.lineWidth.getValue(), this.outline.getValue(), this.box.getValue(), this.boxAlpha.getValue(), false);
            /*SL:84*/if (this.autosw.getValue()) {
                boolean v0 = FastBreak.mc.field_71439_g.func_184614_ca().func_77973_b() == Items.field_151046_w;
                /*SL:86*/if (!v0) {
                    /*SL:87*/for (int v = 0; v < 9; ++v) {
                        final ItemStack a1 = FastBreak.mc.field_71439_g.field_71071_by.func_70301_a(/*EL:88*/v);
                        /*SL:89*/if (!a1.func_190926_b()) {
                            /*SL:91*/this.lasthotbarslot = Surround.mc.field_71439_g.field_71071_by.field_70461_c;
                            /*SL:92*/if (FastBreak.mc.field_71439_g.field_71071_by.field_70461_c != this.lasthotbarslot) {
                                /*SL:93*/this.lasthotbarslot = FastBreak.mc.field_71439_g.field_71071_by.field_70461_c;
                            }
                            /*SL:95*/if (a1.func_77973_b() == Items.field_151046_w) {
                                /*SL:96*/v0 = true;
                                FastBreak.mc.field_71439_g.field_71071_by.field_70461_c = /*EL:97*/v;
                                FastBreak.mc.field_71442_b.func_78765_e();
                                /*SL:99*/break;
                            }
                        }
                    }
                }
            }
        }
    }
    
    @SubscribeEvent
    public void onBlockEvent(final BlockEvent v2) {
        /*SL:110*/if (AbstractModule.fullNullCheck()) {
            /*SL:111*/return;
        }
        /*SL:113*/if (v2.getStage() == 3 && FastBreak.mc.field_71442_b.field_78770_f > 0.1f) {
            FastBreak.mc.field_71442_b.field_78778_j = /*EL:114*/true;
        }
        /*SL:116*/if (v2.getStage() == 4) {
            /*SL:118*/if (BlockUtil.canBreak(v2.pos)) {
                FastBreak.mc.field_71442_b.field_78778_j = /*EL:119*/false;
                /*SL:120*/switch (this.mode.getValue()) {
                    case PACKET: {
                        /*SL:122*/if (this.currentPos == null) {
                            /*SL:123*/this.currentPos = v2.pos;
                            /*SL:124*/this.currentBlockState = FastBreak.mc.field_71441_e.func_180495_p(this.currentPos);
                            /*SL:125*/this.timer.reset();
                        }
                        FastBreak.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
                        FastBreak.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:128*/(Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, v2.pos, v2.facing));
                        FastBreak.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:129*/(Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, v2.pos, v2.facing));
                        /*SL:130*/v2.setCanceled(true);
                        /*SL:131*/break;
                    }
                    case DAMAGE: {
                        /*SL:134*/if (FastBreak.mc.field_71442_b.field_78770_f < this.damage.getValue()) {
                            /*SL:135*/break;
                        }
                        FastBreak.mc.field_71442_b.field_78770_f = /*EL:136*/1.0f;
                        /*SL:137*/break;
                    }
                    case INSTANT: {
                        FastBreak.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
                        FastBreak.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:141*/(Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, v2.pos, v2.facing));
                        FastBreak.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:142*/(Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, v2.pos, v2.facing));
                        FastBreak.mc.field_71442_b.func_187103_a(/*EL:143*/v2.pos);
                        FastBreak.mc.field_71441_e.func_175698_g(/*EL:144*/v2.pos);
                        break;
                    }
                }
            }
            final BlockPos a1;
            /*SL:148*/if (this.doubleBreak.getValue() && BlockUtil.canBreak(a1 = v2.pos.func_177982_a(0, 1, 0)) && FastBreak.mc.field_71439_g.func_70011_f((double)a1.func_177958_n(), (double)a1.func_177956_o(), (double)a1.func_177952_p()) <= 5.0) {
                FastBreak.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
                FastBreak.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:150*/(Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, a1, v2.facing));
                FastBreak.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:151*/(Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, a1, v2.facing));
                FastBreak.mc.field_71442_b.func_187103_a(/*EL:152*/a1);
                FastBreak.mc.field_71441_e.func_175698_g(/*EL:153*/a1);
            }
        }
    }
    
    @Override
    public String getDisplayInfo() {
        /*SL:160*/return this.mode.currentEnumName();
    }
    
    static {
        FastBreak.INSTANCE = new FastBreak();
    }
    
    public enum Mode
    {
        PACKET, 
        DAMAGE, 
        INSTANT;
    }
}
