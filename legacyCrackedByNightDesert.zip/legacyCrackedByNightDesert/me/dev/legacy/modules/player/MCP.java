package me.dev.legacy.modules.player;

import net.minecraft.world.World;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumHand;
import net.minecraft.init.Items;
import me.dev.legacy.api.util.InventoryUtil;
import net.minecraft.item.ItemEnderPearl;
import org.lwjgl.input.Mouse;
import me.dev.legacy.api.AbstractModule;
import me.dev.legacy.modules.Module;

public class MCP extends Module
{
    private boolean clicked;
    
    public MCP() {
        super("MCP", "Throws a pearl", Category.PLAYER, false, false, false);
        this.clicked = false;
    }
    
    @Override
    public void onEnable() {
        /*SL:19*/if (AbstractModule.fullNullCheck()) {
            /*SL:20*/this.disable();
        }
    }
    
    @Override
    public void onTick() {
        /*SL:26*/if (Mouse.isButtonDown(2)) {
            /*SL:27*/if (!this.clicked) {
                /*SL:28*/this.throwPearl();
            }
            /*SL:30*/this.clicked = true;
        }
        else {
            /*SL:32*/this.clicked = false;
        }
    }
    
    private void throwPearl() {
        final int hotbarBlock = /*EL:38*/InventoryUtil.findHotbarBlock(ItemEnderPearl.class);
        final boolean v0;
        final boolean b = /*EL:39*/v0 = (MCP.mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_151079_bi);
        /*SL:40*/if (hotbarBlock != -1 || b) {
            final int v = MCP.mc.field_71439_g.field_71071_by.field_70461_c;
            /*SL:42*/if (!b) {
                /*SL:43*/InventoryUtil.switchToHotbarSlot(hotbarBlock, false);
            }
            MCP.mc.field_71442_b.func_187101_a((EntityPlayer)MCP.mc.field_71439_g, (World)MCP.mc.field_71441_e, /*EL:45*/b ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND);
            /*SL:46*/if (!b) {
                /*SL:47*/InventoryUtil.switchToHotbarSlot(v, false);
            }
        }
    }
}
