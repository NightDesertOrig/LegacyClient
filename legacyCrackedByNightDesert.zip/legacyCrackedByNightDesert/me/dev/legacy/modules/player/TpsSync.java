package me.dev.legacy.modules.player;

import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class TpsSync extends Module
{
    private static TpsSync INSTANCE;
    public Setting<Boolean> attack;
    public Setting<Boolean> mining;
    
    public TpsSync() {
        super("TpsSync", "Syncs your client with the TPS.", Category.PLAYER, true, false, false);
        this.attack = (Setting<Boolean>)this.register(new Setting("Attack", (T)Boolean.FALSE));
        this.mining = (Setting<Boolean>)this.register(new Setting("Mine", (T)Boolean.TRUE));
        this.setInstance();
    }
    
    public static TpsSync getInstance() {
        /*SL:17*/if (TpsSync.INSTANCE == null) {
            TpsSync.INSTANCE = /*EL:18*/new TpsSync();
        }
        /*SL:20*/return TpsSync.INSTANCE;
    }
    
    private void setInstance() {
        TpsSync.INSTANCE = /*EL:24*/this;
    }
    
    static {
        TpsSync.INSTANCE = new TpsSync();
    }
}
