package me.dev.legacy.modules.player;

import java.util.function.Predicate;
import net.minecraft.network.play.client.CPacketPlayer;
import me.zero.alpine.listener.EventHandler;
import me.dev.legacy.api.event.events.other.PacketEvent;
import me.zero.alpine.listener.Listener;
import me.dev.legacy.modules.Module;

public class AntiHunger extends Module
{
    @EventHandler
    public Listener<PacketEvent.Send> packetListener;
    
    public AntiHunger() {
        super("AntiHunger", "AntiHunger", Category.PLAYER, true, false, false);
        this.packetListener = new Listener<PacketEvent.Send>(a1 -> {
            if (a1.getPacket() instanceof CPacketPlayer) {
                ((CPacketPlayer)a1.getPacket()).field_149474_g = false;
            }
        }, (Predicate<PacketEvent.Send>[])new Predicate[0]);
    }
}
