package me.dev.legacy.modules.player;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.network.FMLNetworkEvent;
import net.minecraft.world.GameType;
import net.minecraft.entity.Entity;
import net.minecraft.world.World;
import com.mojang.authlib.GameProfile;
import java.util.UUID;
import me.dev.legacy.impl.command.Command;
import java.util.ArrayList;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import java.util.List;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class FakePlayer extends Module
{
    public Setting<String> fakename;
    public List<Integer> fakePlayerIdList;
    private static FakePlayer INSTANCE;
    private EntityOtherPlayerMP clonedPlayer;
    
    public FakePlayer() {
        super("FakePlayer", "Spawns a literal fake player", Category.PLAYER, false, false, false);
        this.fakename = (Setting<String>)this.register(new Setting("Name", (T)"FakePlayer"));
        this.fakePlayerIdList = new ArrayList<Integer>();
        this.setInstance();
    }
    
    public static FakePlayer getInstance() {
        /*SL:23*/if (FakePlayer.INSTANCE == null) {
            FakePlayer.INSTANCE = /*EL:24*/new FakePlayer();
        }
        /*SL:26*/return FakePlayer.INSTANCE;
    }
    
    private void setInstance() {
        FakePlayer.INSTANCE = /*EL:30*/this;
    }
    
    @Override
    public void onEnable() {
        /*SL:40*/Command.sendMessage("FakePlayer by the name of " + this.fakename.getValueAsString() + " has been spawned!");
        /*SL:41*/if (FakePlayer.mc.field_71439_g == null || FakePlayer.mc.field_71439_g.field_70128_L) {
            /*SL:42*/this.disable();
            /*SL:43*/return;
        }
        /*SL:46*/(this.clonedPlayer = new EntityOtherPlayerMP((World)FakePlayer.mc.field_71441_e, new GameProfile(UUID.fromString("48efc40f-56bf-42c3-aa24-28e0c053f325"), this.fakename.getValueAsString()))).func_82149_j((Entity)FakePlayer.mc.field_71439_g);
        /*SL:48*/this.clonedPlayer.field_70759_as = FakePlayer.mc.field_71439_g.field_70759_as;
        /*SL:49*/this.clonedPlayer.field_70177_z = FakePlayer.mc.field_71439_g.field_70177_z;
        /*SL:50*/this.clonedPlayer.field_70125_A = FakePlayer.mc.field_71439_g.field_70125_A;
        /*SL:51*/this.clonedPlayer.func_71033_a(GameType.SURVIVAL);
        /*SL:52*/this.clonedPlayer.func_70606_j(20.0f);
        FakePlayer.mc.field_71441_e.func_73027_a(/*EL:53*/-12345, (Entity)this.clonedPlayer);
        /*SL:54*/this.clonedPlayer.func_70636_d();
    }
    
    @Override
    public void onDisable() {
        /*SL:58*/if (FakePlayer.mc.field_71441_e != null) {
            FakePlayer.mc.field_71441_e.func_73028_b(/*EL:59*/-12345);
        }
    }
    
    @SubscribeEvent
    public void onClientDisconnect(final FMLNetworkEvent.ClientDisconnectionFromServerEvent a1) {
        /*SL:65*/if (this.isEnabled()) {
            /*SL:66*/this.disable();
        }
    }
    
    static {
        FakePlayer.INSTANCE = new FakePlayer();
    }
}
