package me.dev.legacy.modules.player;

import java.util.function.Predicate;
import net.minecraft.network.play.client.CPacketConfirmTeleport;
import me.zero.alpine.listener.EventHandler;
import me.dev.legacy.api.event.events.other.PacketEvent;
import me.zero.alpine.listener.Listener;
import me.dev.legacy.modules.Module;

public class PortalGodMode extends Module
{
    @EventHandler
    public Listener<PacketEvent.Send> listener;
    
    public PortalGodMode() {
        super("PortalGodMode", "PortalGodMode", Category.PLAYER, true, false, false);
        this.listener = new Listener<PacketEvent.Send>(a1 -> {
            if (this.isEnabled() && a1.getPacket() instanceof CPacketConfirmTeleport) {
                a1.setCanceled(true);
            }
        }, (Predicate<PacketEvent.Send>[])new Predicate[0]);
    }
}
