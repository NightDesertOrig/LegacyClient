package me.dev.legacy.modules.combat;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import java.util.Objects;
import net.minecraft.entity.Entity;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.world.World;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.network.play.client.CPacketUseEntity;
import me.dev.legacy.api.event.events.other.PacketEvent;
import me.dev.legacy.api.util.Timer;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class Crits extends Module
{
    Setting<Integer> packets;
    private final Timer timer;
    
    public Crits() {
        super("Crits", "Criticals", Category.COMBAT, true, false, false);
        this.packets = (Setting<Integer>)this.register(new Setting("Packets", (T)2, (T)1, (T)4));
        this.timer = new Timer();
    }
    
    @SubscribeEvent
    public void onPacketSend(final PacketEvent.Send v2) {
        final CPacketUseEntity a1;
        /*SL:24*/if (v2.getPacket() instanceof CPacketUseEntity && (a1 = (CPacketUseEntity)v2.getPacket()).func_149565_c() == CPacketUseEntity.Action.ATTACK) {
            /*SL:25*/if (!this.timer.passedMs(0L)) {
                /*SL:26*/return;
            }
            /*SL:28*/if (Crits.mc.field_71439_g.field_70122_E && !Crits.mc.field_71474_y.field_74314_A.func_151470_d() && a1.func_149564_a((World)Crits.mc.field_71441_e) instanceof EntityLivingBase && !Crits.mc.field_71439_g.func_70090_H() && !Crits.mc.field_71439_g.func_180799_ab()) {
                /*SL:29*/switch (this.packets.getValue()) {
                    case 1: {
                        Crits.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:31*/(Packet)new CPacketPlayer.Position(Crits.mc.field_71439_g.field_70165_t, Crits.mc.field_71439_g.field_70163_u + 0.10000000149011612, Crits.mc.field_71439_g.field_70161_v, false));
                        Crits.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:32*/(Packet)new CPacketPlayer.Position(Crits.mc.field_71439_g.field_70165_t, Crits.mc.field_71439_g.field_70163_u, Crits.mc.field_71439_g.field_70161_v, false));
                        /*SL:33*/break;
                    }
                    case 2: {
                        Crits.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:36*/(Packet)new CPacketPlayer.Position(Crits.mc.field_71439_g.field_70165_t, Crits.mc.field_71439_g.field_70163_u + 0.0625101, Crits.mc.field_71439_g.field_70161_v, false));
                        Crits.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:37*/(Packet)new CPacketPlayer.Position(Crits.mc.field_71439_g.field_70165_t, Crits.mc.field_71439_g.field_70163_u, Crits.mc.field_71439_g.field_70161_v, false));
                        Crits.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:38*/(Packet)new CPacketPlayer.Position(Crits.mc.field_71439_g.field_70165_t, Crits.mc.field_71439_g.field_70163_u + 1.1E-5, Crits.mc.field_71439_g.field_70161_v, false));
                        Crits.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:39*/(Packet)new CPacketPlayer.Position(Crits.mc.field_71439_g.field_70165_t, Crits.mc.field_71439_g.field_70163_u, Crits.mc.field_71439_g.field_70161_v, false));
                        /*SL:40*/break;
                    }
                    case 3: {
                        Crits.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:43*/(Packet)new CPacketPlayer.Position(Crits.mc.field_71439_g.field_70165_t, Crits.mc.field_71439_g.field_70163_u + 0.0625101, Crits.mc.field_71439_g.field_70161_v, false));
                        Crits.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:44*/(Packet)new CPacketPlayer.Position(Crits.mc.field_71439_g.field_70165_t, Crits.mc.field_71439_g.field_70163_u, Crits.mc.field_71439_g.field_70161_v, false));
                        Crits.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:45*/(Packet)new CPacketPlayer.Position(Crits.mc.field_71439_g.field_70165_t, Crits.mc.field_71439_g.field_70163_u + 0.0125, Crits.mc.field_71439_g.field_70161_v, false));
                        Crits.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:46*/(Packet)new CPacketPlayer.Position(Crits.mc.field_71439_g.field_70165_t, Crits.mc.field_71439_g.field_70163_u, Crits.mc.field_71439_g.field_70161_v, false));
                        /*SL:47*/break;
                    }
                    case 4: {
                        Crits.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:50*/(Packet)new CPacketPlayer.Position(Crits.mc.field_71439_g.field_70165_t, Crits.mc.field_71439_g.field_70163_u + 0.1625, Crits.mc.field_71439_g.field_70161_v, false));
                        Crits.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:51*/(Packet)new CPacketPlayer.Position(Crits.mc.field_71439_g.field_70165_t, Crits.mc.field_71439_g.field_70163_u, Crits.mc.field_71439_g.field_70161_v, false));
                        Crits.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:52*/(Packet)new CPacketPlayer.Position(Crits.mc.field_71439_g.field_70165_t, Crits.mc.field_71439_g.field_70163_u + 4.0E-6, Crits.mc.field_71439_g.field_70161_v, false));
                        Crits.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:53*/(Packet)new CPacketPlayer.Position(Crits.mc.field_71439_g.field_70165_t, Crits.mc.field_71439_g.field_70163_u, Crits.mc.field_71439_g.field_70161_v, false));
                        Crits.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:54*/(Packet)new CPacketPlayer.Position(Crits.mc.field_71439_g.field_70165_t, Crits.mc.field_71439_g.field_70163_u + 1.0E-6, Crits.mc.field_71439_g.field_70161_v, false));
                        Crits.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:55*/(Packet)new CPacketPlayer.Position(Crits.mc.field_71439_g.field_70165_t, Crits.mc.field_71439_g.field_70163_u, Crits.mc.field_71439_g.field_70161_v, false));
                        Crits.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:56*/(Packet)new CPacketPlayer());
                        Crits.mc.field_71439_g.func_71009_b(/*EL:57*/(Entity)Objects.<Entity>requireNonNull(a1.func_149564_a((World)Crits.mc.field_71441_e)));
                        break;
                    }
                }
                /*SL:60*/this.timer.reset();
            }
        }
    }
}
