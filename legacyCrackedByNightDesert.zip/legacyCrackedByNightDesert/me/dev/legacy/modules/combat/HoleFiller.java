package me.dev.legacy.modules.combat;

import me.dev.legacy.api.util.EntityUtil;
import me.dev.legacy.api.util.TestUtil;
import me.dev.legacy.api.util.BlockUtil;
import net.minecraft.util.EnumHand;
import net.minecraft.block.BlockEnderChest;
import me.dev.legacy.api.util.InventoryUtil;
import net.minecraft.block.BlockObsidian;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.AxisAlignedBB;
import java.util.Iterator;
import java.util.function.Consumer;
import net.minecraft.block.material.Material;
import net.minecraft.init.Blocks;
import me.dev.legacy.api.AbstractModule;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Map;
import me.dev.legacy.api.util.Timer;
import me.dev.legacy.impl.setting.Setting;
import net.minecraft.util.math.BlockPos;
import me.dev.legacy.modules.Module;

public class HoleFiller extends Module
{
    private static final BlockPos[] surroundOffset;
    private static HoleFiller INSTANCE;
    private final Setting<Integer> range;
    private final Setting<Integer> delay;
    private final Setting<Boolean> rotate;
    private final Setting<Integer> blocksPerTick;
    private final Setting<Boolean> packet;
    private final Timer offTimer;
    private final Timer timer;
    private boolean isSneaking;
    private boolean hasOffhand;
    private final Map<BlockPos, Integer> retries;
    private final Timer retryTimer;
    private int blocksThisTick;
    private ArrayList<BlockPos> holes;
    private int trie;
    
    public HoleFiller() {
        super("HoleFill", "Fills holes around you.", Category.COMBAT, true, false, true);
        this.packet = (Setting<Boolean>)this.register(new Setting("Packet", (T)false));
        this.hasOffhand = false;
        this.range = (Setting<Integer>)this.register(new Setting("PlaceRange", (T)8, (T)0, (T)10));
        this.delay = (Setting<Integer>)this.register(new Setting("Delay", (T)0, (T)0, (T)250));
        this.blocksPerTick = (Setting<Integer>)this.register(new Setting("BlocksPerTick", (T)20, (T)8, (T)30));
        this.rotate = (Setting<Boolean>)this.register(new Setting("Rotate", (T)false));
        this.offTimer = new Timer();
        this.timer = new Timer();
        this.blocksThisTick = 0;
        this.retries = new HashMap<BlockPos, Integer>();
        this.retryTimer = new Timer();
        this.holes = new ArrayList<BlockPos>();
        this.setInstance();
    }
    
    public static HoleFiller getInstance() {
        /*SL:60*/if (HoleFiller.INSTANCE == null) {
            HoleFiller.INSTANCE = /*EL:61*/new HoleFiller();
        }
        /*SL:63*/return HoleFiller.INSTANCE;
    }
    
    private void setInstance() {
        HoleFiller.INSTANCE = /*EL:67*/this;
    }
    
    @Override
    public void onEnable() {
        /*SL:72*/if (AbstractModule.fullNullCheck()) {
            /*SL:73*/this.disable();
        }
        /*SL:75*/this.offTimer.reset();
        /*SL:76*/this.trie = 0;
    }
    
    @Override
    public void onTick() {
        /*SL:81*/if (this.isOn() && (this.blocksPerTick.getValue() != 1 || !this.rotate.getValue())) {
            /*SL:82*/this.doHoleFill();
        }
    }
    
    @Override
    public void onDisable() {
        /*SL:88*/this.retries.clear();
    }
    
    private void doHoleFill() {
        /*SL:92*/if (this.check()) {
            /*SL:93*/return;
        }
        /*SL:95*/this.holes = new ArrayList<BlockPos>();
        final Iterable<BlockPos> func_177980_a = /*EL:96*/(Iterable<BlockPos>)BlockPos.func_177980_a(HoleFiller.mc.field_71439_g.func_180425_c().func_177982_a(-this.range.getValue(), -this.range.getValue(), -this.range.getValue()), HoleFiller.mc.field_71439_g.func_180425_c().func_177982_a((int)this.range.getValue(), (int)this.range.getValue(), (int)this.range.getValue()));
        /*SL:97*/for (final BlockPos v0 : func_177980_a) {
            /*SL:98*/if (!HoleFiller.mc.field_71441_e.func_180495_p(v0).func_185904_a().func_76230_c() && !HoleFiller.mc.field_71441_e.func_180495_p(v0.func_177982_a(0, 1, 0)).func_185904_a().func_76230_c()) {
                final boolean v = (HoleFiller.mc.field_71441_e.func_180495_p(/*EL:99*/v0.func_177982_a(1, 0, 0)).func_177230_c() == Blocks.field_150357_h | HoleFiller.mc.field_71441_e.func_180495_p(v0.func_177982_a(1, 0, 0)).func_177230_c() == Blocks.field_150343_Z) && (HoleFiller.mc.field_71441_e.func_180495_p(v0.func_177982_a(0, 0, 1)).func_177230_c() == Blocks.field_150357_h | HoleFiller.mc.field_71441_e.func_180495_p(v0.func_177982_a(0, 0, 1)).func_177230_c() == Blocks.field_150343_Z) && (HoleFiller.mc.field_71441_e.func_180495_p(v0.func_177982_a(-1, 0, 0)).func_177230_c() == Blocks.field_150357_h | HoleFiller.mc.field_71441_e.func_180495_p(v0.func_177982_a(-1, 0, 0)).func_177230_c() == Blocks.field_150343_Z) && (HoleFiller.mc.field_71441_e.func_180495_p(v0.func_177982_a(0, 0, -1)).func_177230_c() == Blocks.field_150357_h | HoleFiller.mc.field_71441_e.func_180495_p(v0.func_177982_a(0, 0, -1)).func_177230_c() == Blocks.field_150343_Z) && HoleFiller.mc.field_71441_e.func_180495_p(v0.func_177982_a(0, 0, 0)).func_185904_a() == Material.field_151579_a && HoleFiller.mc.field_71441_e.func_180495_p(v0.func_177982_a(0, 1, 0)).func_185904_a() == Material.field_151579_a && HoleFiller.mc.field_71441_e.func_180495_p(v0.func_177982_a(0, 2, 0)).func_185904_a() == Material.field_151579_a;
                /*SL:100*/if (!v) {
                    /*SL:101*/continue;
                }
                /*SL:103*/this.holes.add(v0);
            }
        }
        /*SL:106*/this.holes.forEach(this::placeBlock);
        /*SL:107*/this.toggle();
    }
    
    private void placeBlock(final BlockPos v0) {
        /*SL:111*/for (final Entity a1 : HoleFiller.mc.field_71441_e.func_72839_b((Entity)null, new AxisAlignedBB(v0))) {
            /*SL:112*/if (a1 instanceof EntityLivingBase) {
                /*SL:113*/return;
            }
        }
        /*SL:116*/if (this.blocksThisTick < this.blocksPerTick.getValue()) {
            final int v = /*EL:117*/InventoryUtil.findHotbarBlock(BlockObsidian.class);
            final int v2 = /*EL:118*/InventoryUtil.findHotbarBlock(BlockEnderChest.class);
            /*SL:119*/if (v == -1 && v2 == -1) {
                /*SL:120*/this.toggle();
            }
            final boolean v3 = /*EL:122*/this.blocksPerTick.getValue() == 1 && this.rotate.getValue();
            /*SL:123*/if (v3) {
                /*SL:124*/this.isSneaking = BlockUtil.placeBlockSmartRotate(v0, this.hasOffhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, true, this.packet.getValue(), this.isSneaking);
            }
            else {
                /*SL:126*/this.isSneaking = BlockUtil.placeBlock(v0, this.hasOffhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, this.rotate.getValue(), this.packet.getValue(), this.isSneaking);
            }
            final int v4 = HoleFiller.mc.field_71439_g.field_71071_by.field_70461_c;
            HoleFiller.mc.field_71439_g.field_71071_by.field_70461_c = /*EL:129*/((v == -1) ? v2 : v);
            HoleFiller.mc.field_71442_b.func_78765_e();
            /*SL:131*/TestUtil.placeBlock(v0);
            /*SL:132*/if (HoleFiller.mc.field_71439_g.field_71071_by.field_70461_c != v4) {
                HoleFiller.mc.field_71439_g.field_71071_by.field_70461_c = /*EL:133*/v4;
                HoleFiller.mc.field_71442_b.func_78765_e();
            }
            /*SL:136*/this.timer.reset();
            /*SL:137*/++this.blocksThisTick;
        }
    }
    
    private boolean check() {
        /*SL:142*/if (AbstractModule.fullNullCheck()) {
            /*SL:143*/this.disable();
            /*SL:144*/return true;
        }
        /*SL:146*/this.blocksThisTick = 0;
        /*SL:147*/if (this.retryTimer.passedMs(2000L)) {
            /*SL:148*/this.retries.clear();
            /*SL:149*/this.retryTimer.reset();
        }
        /*SL:151*/return !this.timer.passedMs(this.delay.getValue());
    }
    
    static {
        HoleFiller.INSTANCE = new HoleFiller();
        surroundOffset = BlockUtil.toBlockPos(EntityUtil.getOffsets(0, true));
    }
}
