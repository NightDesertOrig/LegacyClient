package me.dev.legacy.modules.combat;

import net.minecraft.item.ItemShulkerBox;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import me.dev.legacy.api.event.events.other.PacketEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.network.Packet;
import net.minecraft.util.EnumFacing;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.util.EnumHand;
import net.minecraft.block.BlockShulkerBox;
import me.dev.legacy.api.util.BlockUtil;
import me.dev.legacy.api.event.events.update.UpdateEvent;
import java.util.ArrayList;
import net.minecraft.util.math.BlockPos;
import java.util.List;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class AntiRegear extends Module
{
    private final Setting<Float> reach;
    private final Setting<Integer> retry;
    private final List<BlockPos> retries;
    private final List<BlockPos> selfPlaced;
    private int ticks;
    
    public AntiRegear() {
        super("AntiRegear", "AntiRegear.", Category.COMBAT, true, false, false);
        this.reach = (Setting<Float>)this.register(new Setting("Reach", (T)5.0f, (T)1.0f, (T)6.0f));
        this.retry = (Setting<Integer>)this.register(new Setting("Retry Delay", (T)10, (T)0, (T)20));
        this.retries = new ArrayList<BlockPos>();
        this.selfPlaced = new ArrayList<BlockPos>();
    }
    
    @SubscribeEvent
    public void onUpdate(final UpdateEvent v-2) {
        /*SL:35*/if (this.ticks++ < this.retry.getValue()) {
            /*SL:36*/this.ticks = 0;
            /*SL:37*/this.retries.clear();
        }
        final List<BlockPos> sphere = /*EL:40*/BlockUtil.getSphere(this.reach.getValue());
        /*SL:42*/for (int v0 = sphere.size(), v = 0; v < v0; ++v) {
            final BlockPos a1 = /*EL:43*/sphere.get(v);
            /*SL:44*/if (!this.retries.contains(a1)) {
                if (!this.selfPlaced.contains(a1)) {
                    /*SL:47*/if (AntiRegear.mc.field_71441_e.func_180495_p(a1).func_177230_c() instanceof BlockShulkerBox) {
                        AntiRegear.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
                        AntiRegear.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:49*/(Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, a1, EnumFacing.UP));
                        AntiRegear.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:50*/(Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, a1, EnumFacing.UP));
                        /*SL:51*/this.retries.add(a1);
                    }
                }
            }
        }
    }
    
    @SubscribeEvent
    public void onPacketSend(final PacketEvent.Send v2) {
        /*SL:58*/if (v2.getPacket() instanceof CPacketPlayerTryUseItemOnBlock) {
            final CPacketPlayerTryUseItemOnBlock a1 = /*EL:59*/(CPacketPlayerTryUseItemOnBlock)v2.getPacket();
            /*SL:60*/if (AntiRegear.mc.field_71439_g.func_184586_b(a1.func_187022_c()).func_77973_b() instanceof ItemShulkerBox) {
                /*SL:61*/this.selfPlaced.add(a1.func_187023_a().func_177972_a(a1.func_187024_b()));
            }
        }
    }
}
