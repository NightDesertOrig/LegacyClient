package me.dev.legacy.modules.combat;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import java.util.HashMap;
import java.util.Iterator;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import java.util.Map;
import me.dev.legacy.Legacy;
import net.minecraft.item.ItemExpBottle;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.client.gui.inventory.GuiContainer;
import me.dev.legacy.api.AbstractModule;
import java.util.ArrayList;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.List;
import me.dev.legacy.api.util.InventoryUtil;
import java.util.Queue;
import me.dev.legacy.api.util.Timer;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class AutoArmor extends Module
{
    private final Setting<Integer> delay;
    private final Setting<Boolean> curse;
    private final Setting<Boolean> mendingTakeOff;
    private final Setting<Integer> closestEnemy;
    private final Setting<Integer> repair;
    private final Setting<Integer> actions;
    private final Timer timer;
    private final Queue<InventoryUtil.Task> taskList;
    private final List<Integer> doneSlots;
    boolean flag;
    
    public AutoArmor() {
        super("AutoArmor", "Puts Armor on for you.", Category.COMBAT, true, false, false);
        this.delay = (Setting<Integer>)this.register(new Setting("Delay", (T)50, (T)0, (T)500));
        this.curse = (Setting<Boolean>)this.register(new Setting("Vanishing", (T)false));
        this.mendingTakeOff = (Setting<Boolean>)this.register(new Setting("AutoMend", (T)false));
        this.closestEnemy = (Setting<Integer>)this.register(new Setting("Enemy", (T)8, (T)1, (T)20, a1 -> this.mendingTakeOff.getValue()));
        this.repair = (Setting<Integer>)this.register(new Setting("Repair%", (T)80, (T)1, (T)100, a1 -> this.mendingTakeOff.getValue()));
        this.actions = (Setting<Integer>)this.register(new Setting("Packets", (T)3, (T)1, (T)12));
        this.timer = new Timer();
        this.taskList = new ConcurrentLinkedQueue<InventoryUtil.Task>();
        this.doneSlots = new ArrayList<Integer>();
    }
    
    @Override
    public void onLogin() {
        /*SL:37*/this.timer.reset();
    }
    
    @Override
    public void onDisable() {
        /*SL:42*/this.taskList.clear();
        /*SL:43*/this.doneSlots.clear();
        /*SL:44*/this.flag = false;
    }
    
    @Override
    public void onLogout() {
        /*SL:49*/this.taskList.clear();
        /*SL:50*/this.doneSlots.clear();
    }
    
    @Override
    public void onTick() {
        /*SL:55*/if (AbstractModule.fullNullCheck() || (AutoArmor.mc.field_71462_r instanceof GuiContainer && !(AutoArmor.mc.field_71462_r instanceof GuiInventory))) {
            /*SL:56*/return;
        }
        /*SL:58*/if (this.taskList.isEmpty()) {
            /*SL:66*/if (this.mendingTakeOff.getValue() && InventoryUtil.holdingItem(ItemExpBottle.class) && AutoArmor.mc.field_71474_y.field_74313_G.func_151470_d() && AutoArmor.mc.field_71441_e.field_73010_i.stream().noneMatch(a1 -> a1 != AutoArmor.mc.field_71439_g && !Legacy.friendManager.isFriend(((EntityPlayer)a1).func_70005_c_()) && AutoArmor.mc.field_71439_g.func_70032_d(a1) <= this.closestEnemy.getValue()) && !this.flag) {
                int n = /*EL:69*/0;
                /*SL:70*/for (final Map.Entry<Integer, ItemStack> v0 : this.getArmor().entrySet()) {
                    final ItemStack v = /*EL:71*/v0.getValue();
                    final float v2 = /*EL:72*/this.repair.getValue() / 100.0f;
                    final int n2 = /*EL:73*/Math.round(v.func_77958_k() * v2);
                    final int n3;
                    /*SL:74*/if (n2 >= (n3 = v.func_77958_k() - v.func_77952_i())) {
                        continue;
                    }
                    /*SL:75*/++n;
                }
                /*SL:77*/if (n == 4) {
                    /*SL:78*/this.flag = true;
                }
                /*SL:80*/if (!this.flag) {
                    final ItemStack func_75211_c = AutoArmor.mc.field_71439_g.field_71069_bz.func_75139_a(/*EL:81*/5).func_75211_c();
                    /*SL:82*/if (!func_75211_c.field_190928_g) {
                        final float v3 = /*EL:84*/this.repair.getValue() / 100.0f;
                        final int v4 = /*EL:85*/Math.round(func_75211_c.func_77958_k() * v3);
                        final int v5;
                        /*SL:86*/if (v4 < (v5 = func_75211_c.func_77958_k() - func_75211_c.func_77952_i())) {
                            /*SL:87*/this.takeOffSlot(5);
                        }
                    }
                    final ItemStack v6 = AutoArmor.mc.field_71439_g.field_71069_bz.func_75139_a(/*EL:90*/6).func_75211_c();
                    /*SL:91*/if (!v6.field_190928_g) {
                        final float v2 = /*EL:93*/this.repair.getValue() / 100.0f;
                        final int v7 = /*EL:94*/Math.round(v6.func_77958_k() * v2);
                        final int v8;
                        /*SL:95*/if (v7 < (v8 = v6.func_77958_k() - v6.func_77952_i())) {
                            /*SL:96*/this.takeOffSlot(6);
                        }
                    }
                    final ItemStack v = AutoArmor.mc.field_71439_g.field_71069_bz.func_75139_a(/*EL:99*/7).func_75211_c();
                    /*SL:100*/if (!v.field_190928_g) {
                        final float v2 = /*EL:101*/this.repair.getValue() / 100.0f;
                        final int n2 = /*EL:102*/Math.round(v.func_77958_k() * v2);
                        final int n3;
                        /*SL:103*/if (n2 < (n3 = v.func_77958_k() - v.func_77952_i())) {
                            /*SL:104*/this.takeOffSlot(7);
                        }
                    }
                    final ItemStack v9 = AutoArmor.mc.field_71439_g.field_71069_bz.func_75139_a(/*EL:107*/8).func_75211_c();
                    /*SL:108*/if (!v9.field_190928_g) {
                        final float v10 = /*EL:110*/this.repair.getValue() / 100.0f;
                        final int v11 = /*EL:111*/Math.round(v9.func_77958_k() * v10);
                        final int v7;
                        /*SL:112*/if (v11 < (v7 = v9.func_77958_k() - v9.func_77952_i())) {
                            /*SL:113*/this.takeOffSlot(8);
                        }
                    }
                }
                /*SL:117*/return;
            }
            /*SL:119*/this.flag = false;
            final ItemStack func_75211_c2 = AutoArmor.mc.field_71439_g.field_71069_bz.func_75139_a(/*EL:120*/5).func_75211_c();
            final int armorSlot;
            /*SL:121*/if (func_75211_c2.func_77973_b() == Items.field_190931_a && (armorSlot = InventoryUtil.findArmorSlot(EntityEquipmentSlot.HEAD, this.curse.getValue(), true)) != -1) {
                /*SL:122*/this.getSlotOn(5, armorSlot);
            }
            final ItemStack func_75211_c3;
            final int armorSlot2;
            /*SL:124*/if ((func_75211_c3 = AutoArmor.mc.field_71439_g.field_71069_bz.func_75139_a(6).func_75211_c()).func_77973_b() == Items.field_190931_a && (armorSlot2 = InventoryUtil.findArmorSlot(EntityEquipmentSlot.CHEST, this.curse.getValue(), true)) != -1) {
                /*SL:125*/this.getSlotOn(6, armorSlot2);
            }
            final ItemStack func_75211_c4;
            final int armorSlot3;
            /*SL:127*/if ((func_75211_c4 = AutoArmor.mc.field_71439_g.field_71069_bz.func_75139_a(7).func_75211_c()).func_77973_b() == Items.field_190931_a && (armorSlot3 = InventoryUtil.findArmorSlot(EntityEquipmentSlot.LEGS, this.curse.getValue(), true)) != -1) {
                /*SL:128*/this.getSlotOn(7, armorSlot3);
            }
            final ItemStack func_75211_c5;
            final int i;
            /*SL:130*/if ((func_75211_c5 = AutoArmor.mc.field_71439_g.field_71069_bz.func_75139_a(8).func_75211_c()).func_77973_b() == Items.field_190931_a && (i = InventoryUtil.findArmorSlot(EntityEquipmentSlot.FEET, this.curse.getValue(), true)) != -1) {
                /*SL:131*/this.getSlotOn(8, i);
            }
        }
        /*SL:134*/if (this.timer.passedMs((int)(this.delay.getValue() * Legacy.serverManager.getTpsFactor()))) {
            /*SL:135*/if (!this.taskList.isEmpty()) {
                /*SL:136*/for (int i = 0; i < this.actions.getValue(); ++i) {
                    final InventoryUtil.Task task = /*EL:137*/this.taskList.poll();
                    /*SL:138*/if (task != null) {
                        /*SL:139*/task.run();
                    }
                }
            }
            /*SL:142*/this.timer.reset();
        }
    }
    
    private void takeOffSlot(final int v0) {
        /*SL:147*/if (this.taskList.isEmpty()) {
            int v = /*EL:148*/-1;
            /*SL:149*/for (final int a1 : InventoryUtil.findEmptySlots(true)) {
                /*SL:150*/if (this.doneSlots.contains(v)) {
                    continue;
                }
                /*SL:151*/v = a1;
                /*SL:152*/this.doneSlots.add(a1);
            }
            /*SL:154*/if (v != -1) {
                /*SL:155*/this.taskList.add(new InventoryUtil.Task(v0));
                /*SL:156*/this.taskList.add(new InventoryUtil.Task(v));
                /*SL:157*/this.taskList.add(new InventoryUtil.Task());
            }
        }
    }
    
    private void getSlotOn(final int a1, final int a2) {
        /*SL:163*/if (this.taskList.isEmpty()) {
            /*SL:164*/this.doneSlots.remove((Object)a2);
            /*SL:165*/this.taskList.add(new InventoryUtil.Task(a2));
            /*SL:166*/this.taskList.add(new InventoryUtil.Task(a1));
            /*SL:167*/this.taskList.add(new InventoryUtil.Task());
        }
    }
    
    private Map<Integer, ItemStack> getArmor() {
        /*SL:172*/return this.getInventorySlots(5, 8);
    }
    
    private Map<Integer, ItemStack> getInventorySlots(int a1, final int a2) {
        final HashMap<Integer, ItemStack> v1 = /*EL:176*/new HashMap<Integer, ItemStack>();
        /*SL:177*/while (a1 <= a2) {
            /*SL:178*/v1.put(a1, (ItemStack)AutoArmor.mc.field_71439_g.field_71069_bz.func_75138_a().get(a1));
            /*SL:179*/++a1;
        }
        /*SL:181*/return v1;
    }
}
