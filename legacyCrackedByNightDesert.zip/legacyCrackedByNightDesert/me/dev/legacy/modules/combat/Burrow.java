package me.dev.legacy.modules.combat;

import java.util.Iterator;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.Entity;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.util.EnumHand;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import me.dev.legacy.impl.command.Command;
import net.minecraft.block.BlockObsidian;
import net.minecraft.block.BlockEnderChest;
import me.dev.legacy.api.util.BurrowUtil;
import net.minecraft.block.BlockAnvil;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class Burrow extends Module
{
    private final Setting<Integer> offset;
    private final Setting<Boolean> ground;
    private final Setting<Boolean> rotate;
    private final Setting<Boolean> echest;
    private final Setting<Boolean> anvil;
    private BlockPos originalPos;
    private int oldSlot;
    
    public Burrow() {
        super("Burrow", "TPs you into a block", Category.COMBAT, true, false, false);
        this.offset = (Setting<Integer>)this.register(new Setting("Offset", (T)3, (T)(-5), (T)5));
        this.ground = (Setting<Boolean>)this.register(new Setting("Ground check", (T)true));
        this.rotate = (Setting<Boolean>)this.register(new Setting("Rotate", (T)false));
        this.echest = (Setting<Boolean>)this.register(new Setting("Use echest", (T)false));
        this.anvil = (Setting<Boolean>)this.register(new Setting("Use anvil", (T)false));
        this.oldSlot = -1;
    }
    
    @Override
    public void onEnable() {
        /*SL:34*/super.onEnable();
        /*SL:36*/this.originalPos = new BlockPos(Burrow.mc.field_71439_g.field_70165_t, Burrow.mc.field_71439_g.field_70163_u, Burrow.mc.field_71439_g.field_70161_v);
        /*SL:38*/if (Burrow.mc.field_71441_e.func_180495_p(new BlockPos(Burrow.mc.field_71439_g.field_70165_t, Burrow.mc.field_71439_g.field_70163_u, Burrow.mc.field_71439_g.field_70161_v)).func_177230_c().equals(Blocks.field_150343_Z) || this.intersectsWithEntity(this.originalPos)) {
            /*SL:40*/this.toggle();
            /*SL:41*/return;
        }
        /*SL:44*/this.oldSlot = Burrow.mc.field_71439_g.field_71071_by.field_70461_c;
    }
    
    @Override
    public void onUpdate() {
        /*SL:50*/if (this.ground.getValue() && !Burrow.mc.field_71439_g.field_70122_E) {
            /*SL:52*/this.toggle();
            /*SL:53*/return;
        }
        Label_0151: {
            /*SL:57*/if (!this.anvil.getValue() || BurrowUtil.findHotbarBlock(BlockAnvil.class) == -1) {
                Label_0141: {
                    /*SL:59*/if (this.echest.getValue()) {
                        if (BurrowUtil.findHotbarBlock(BlockEnderChest.class) == -1) {
                            break Label_0141;
                        }
                    }
                    else if (BurrowUtil.findHotbarBlock(BlockObsidian.class) == -1) {
                        break Label_0141;
                    }
                    /*SL:60*/BurrowUtil.switchToSlot(((boolean)this.echest.getValue()) ? BurrowUtil.findHotbarBlock(BlockEnderChest.class) : BurrowUtil.findHotbarBlock(BlockObsidian.class));
                    break Label_0151;
                }
                /*SL:62*/Command.sendMessage("Unable to place burrow block (anvil, ec or oby)");
                /*SL:63*/this.toggle();
                /*SL:64*/return;
            }
            BurrowUtil.switchToSlot(BurrowUtil.findHotbarBlock(BlockAnvil.class));
        }
        Burrow.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:67*/(Packet)new CPacketPlayer.Position(Burrow.mc.field_71439_g.field_70165_t, Burrow.mc.field_71439_g.field_70163_u + 0.41999998688698, Burrow.mc.field_71439_g.field_70161_v, true));
        Burrow.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:68*/(Packet)new CPacketPlayer.Position(Burrow.mc.field_71439_g.field_70165_t, Burrow.mc.field_71439_g.field_70163_u + 0.7531999805211997, Burrow.mc.field_71439_g.field_70161_v, true));
        Burrow.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:69*/(Packet)new CPacketPlayer.Position(Burrow.mc.field_71439_g.field_70165_t, Burrow.mc.field_71439_g.field_70163_u + 1.00133597911214, Burrow.mc.field_71439_g.field_70161_v, true));
        Burrow.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:70*/(Packet)new CPacketPlayer.Position(Burrow.mc.field_71439_g.field_70165_t, Burrow.mc.field_71439_g.field_70163_u + 1.16610926093821, Burrow.mc.field_71439_g.field_70161_v, true));
        /*SL:72*/BurrowUtil.placeBlock(this.originalPos, EnumHand.MAIN_HAND, this.rotate.getValue(), true, false);
        Burrow.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:74*/(Packet)new CPacketPlayer.Position(Burrow.mc.field_71439_g.field_70165_t, Burrow.mc.field_71439_g.field_70163_u + this.offset.getValue(), Burrow.mc.field_71439_g.field_70161_v, false));
        Burrow.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:76*/(Packet)new CPacketEntityAction((Entity)Burrow.mc.field_71439_g, CPacketEntityAction.Action.STOP_SNEAKING));
        Burrow.mc.field_71439_g.func_70095_a(/*EL:77*/false);
        /*SL:79*/BurrowUtil.switchToSlot(this.oldSlot);
        /*SL:81*/this.toggle();
    }
    
    private boolean intersectsWithEntity(final BlockPos v2) {
        /*SL:85*/for (final Entity a1 : Burrow.mc.field_71441_e.field_72996_f) {
            /*SL:86*/if (a1.equals((Object)Burrow.mc.field_71439_g)) {
                continue;
            }
            /*SL:87*/if (a1 instanceof EntityItem) {
                continue;
            }
            /*SL:88*/if (new AxisAlignedBB(v2).func_72326_a(a1.func_174813_aQ())) {
                return true;
            }
        }
        /*SL:90*/return false;
    }
}
