package me.dev.legacy.modules.combat;

import net.minecraft.util.EnumHand;
import me.dev.legacy.impl.command.Command;
import com.mojang.realmsclient.gui.ChatFormatting;
import net.minecraft.block.BlockEnderChest;
import me.dev.legacy.api.util.InventoryUtil;
import net.minecraft.block.BlockObsidian;
import java.util.Iterator;
import me.dev.legacy.api.util.BlockUtil;
import net.minecraft.init.Blocks;
import me.dev.legacy.Legacy;
import net.minecraft.entity.Entity;
import me.dev.legacy.api.util.EntityUtil;
import me.dev.legacy.api.AbstractModule;
import java.util.HashMap;
import java.util.HashSet;
import net.minecraft.util.math.BlockPos;
import java.util.Map;
import net.minecraft.util.math.Vec3d;
import java.util.Set;
import me.dev.legacy.api.util.Timer;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class Surround extends Module
{
    public static boolean isPlacing;
    private final Setting<Integer> blocksPerTick;
    private final Setting<Integer> delay;
    private final Setting<Boolean> noGhost;
    private final Setting<Boolean> center;
    private final Setting<Boolean> rotate;
    private final Setting<Boolean> helpingBlocks;
    private final Setting<Boolean> antiPedo;
    private final Setting<Boolean> floor;
    private final Timer timer;
    private final Timer retryTimer;
    private final Set<Vec3d> extendingBlocks;
    private final Map<BlockPos, Integer> retries;
    private BlockPos startPos;
    private boolean didPlace;
    private int lastHotbarSlot;
    private boolean isSneaking;
    private int placements;
    private int extenders;
    private boolean offHand;
    
    public Surround() {
        super("Surround", "surround", Category.COMBAT, true, false, false);
        this.blocksPerTick = (Setting<Integer>)this.register(new Setting("BPT", (T)20, (T)1, (T)20));
        this.delay = (Setting<Integer>)this.register(new Setting("Delay", (T)0, (T)0, (T)250));
        this.noGhost = (Setting<Boolean>)this.register(new Setting("Packet", (T)false));
        this.center = (Setting<Boolean>)this.register(new Setting("TPCenter", (T)false));
        this.rotate = (Setting<Boolean>)this.register(new Setting("Rotate", (T)false));
        this.helpingBlocks = (Setting<Boolean>)this.register(new Setting("HelpingBlocks", (T)true));
        this.antiPedo = (Setting<Boolean>)this.register(new Setting("Always Help", (T)false));
        this.floor = (Setting<Boolean>)this.register(new Setting("Floor", (T)true));
        this.timer = new Timer();
        this.retryTimer = new Timer();
        this.extendingBlocks = new HashSet<Vec3d>();
        this.retries = new HashMap<BlockPos, Integer>();
        this.didPlace = false;
        this.placements = 0;
        this.extenders = 1;
        this.offHand = false;
    }
    
    @Override
    public void onEnable() {
        /*SL:53*/if (AbstractModule.fullNullCheck()) {
            /*SL:54*/this.disable();
        }
        /*SL:56*/this.lastHotbarSlot = Surround.mc.field_71439_g.field_71071_by.field_70461_c;
        /*SL:57*/this.startPos = EntityUtil.getRoundedBlockPos((Entity)Surround.mc.field_71439_g);
        /*SL:58*/if (this.center.getValue()) {
            Legacy.positionManager.setPositionPacket(/*EL:59*/this.startPos.func_177958_n() + 0.5, this.startPos.func_177956_o(), this.startPos.func_177952_p() + 0.5, true, true, true);
        }
        /*SL:61*/this.retries.clear();
        /*SL:62*/this.retryTimer.reset();
    }
    
    @Override
    public void onTick() {
        /*SL:67*/this.doFeetPlace();
    }
    
    @Override
    public void onDisable() {
        /*SL:72*/if (AbstractModule.nullCheck()) {
            /*SL:73*/return;
        }
        Surround.isPlacing = /*EL:75*/false;
        /*SL:76*/this.isSneaking = EntityUtil.stopSneaking(this.isSneaking);
    }
    
    private void doFeetPlace() {
        /*SL:80*/if (this.check()) {
            /*SL:81*/return;
        }
        /*SL:83*/if (Surround.mc.field_71439_g.field_70163_u < Surround.mc.field_71439_g.field_70163_u) {
            /*SL:84*/this.setEnabled(false);
            /*SL:85*/return;
        }
        boolean v1 = Surround.mc.field_71441_e.func_180495_p(/*EL:87*/new BlockPos(Surround.mc.field_71439_g.func_174791_d())).func_177230_c() == Blocks.field_150477_bB;
        /*SL:88*/if (Surround.mc.field_71439_g.field_70163_u - (int)Surround.mc.field_71439_g.field_70163_u < 0.7) {
            /*SL:89*/v1 = false;
        }
        /*SL:91*/if (!BlockUtil.isSafe((Entity)Surround.mc.field_71439_g, v1 ? 1 : 0, this.floor.getValue())) {
            /*SL:92*/this.placeBlocks(Surround.mc.field_71439_g.func_174791_d(), BlockUtil.getUnsafeBlockArray((Entity)Surround.mc.field_71439_g, (int)(v1 ? 1 : 0), this.floor.getValue()), this.helpingBlocks.getValue(), false);
        }
        else/*SL:93*/ if (!BlockUtil.isSafe((Entity)Surround.mc.field_71439_g, v1 ? 0 : -1, false) && /*EL:94*/this.antiPedo.getValue()) {
            /*SL:95*/this.placeBlocks(Surround.mc.field_71439_g.func_174791_d(), BlockUtil.getUnsafeBlockArray((Entity)Surround.mc.field_71439_g, v1 ? 0 : -1, false), false, false);
        }
        /*SL:98*/this.processExtendingBlocks();
        /*SL:99*/if (this.didPlace) {
            /*SL:100*/this.timer.reset();
        }
    }
    
    private void processExtendingBlocks() {
        /*SL:105*/if (this.extendingBlocks.size() == 2 && this.extenders < 1) {
            final Vec3d[] v-4 = /*EL:106*/new Vec3d[2];
            int n = /*EL:107*/0;
            final Iterator<Vec3d> v0 = /*EL:108*/this.extendingBlocks.iterator();
            /*SL:109*/while (v0.hasNext()) {
                final Vec3d v = /*EL:111*/v-4[n] = v0.next();
                /*SL:112*/++n;
            }
            final int v2 = /*EL:114*/this.placements;
            /*SL:115*/if (this.areClose(v-4) != null) {
                /*SL:116*/this.placeBlocks(this.areClose(v-4), EntityUtil.getUnsafeBlockArrayFromVec3d(this.areClose(v-4), 0, true), true, false);
            }
            /*SL:118*/if (v2 < this.placements) {
                /*SL:119*/this.extendingBlocks.clear();
            }
        }
        else/*SL:121*/ if (this.extendingBlocks.size() > 2 || this.extenders >= 1) {
            /*SL:122*/this.extendingBlocks.clear();
        }
    }
    
    private Vec3d areClose(final Vec3d[] v-4) {
        int n = /*EL:127*/0;
        /*SL:128*/for (final Vec3d v1 : v-4) {
            /*SL:129*/for (final Vec3d a1 : EntityUtil.getUnsafeBlockArray((Entity)Surround.mc.field_71439_g, 0, true)) {
                /*SL:130*/if (v1.equals((Object)a1)) {
                    /*SL:131*/++n;
                }
            }
        }
        /*SL:134*/if (n == 2) {
            /*SL:135*/return Surround.mc.field_71439_g.func_174791_d().func_178787_e(v-4[0].func_178787_e(v-4[1]));
        }
        /*SL:137*/return null;
    }
    
    private boolean placeBlocks(final Vec3d a4, final Vec3d[] v1, final boolean v2, final boolean v3) {
        boolean v4 = /*EL:141*/true;
        /*SL:143*/for (final Vec3d a5 : v1) {
            /*SL:144*/v4 = true;
            final BlockPos a6 = /*EL:145*/new BlockPos(a4).func_177963_a(a5.field_72450_a, a5.field_72448_b, a5.field_72449_c);
            /*SL:146*/switch (BlockUtil.isPositionPlaceable(a6, false)) {
                case 1: {
                    /*SL:148*/if (this.retries.get(a6) == null || this.retries.get(a6) < 4) {
                        /*SL:149*/this.placeBlock(a6);
                        /*SL:150*/this.retries.put(a6, (this.retries.get(a6) == null) ? 1 : (this.retries.get(a6) + 1));
                        /*SL:151*/this.retryTimer.reset();
                        /*SL:152*/break;
                    }
                }
                case 2: {
                    /*SL:156*/if (!v2) {
                        break;
                    }
                    /*SL:157*/v4 = this.placeBlocks(a4, BlockUtil.getHelpingBlocks(a5), false, true);
                }
                case 3: {
                    /*SL:160*/if (v4) {
                        /*SL:161*/this.placeBlock(a6);
                    }
                    /*SL:163*/if (!v3) {
                        break;
                    }
                    /*SL:164*/return true;
                }
            }
        }
        /*SL:168*/return false;
    }
    
    private boolean check() {
        /*SL:172*/if (AbstractModule.nullCheck()) {
            /*SL:173*/return true;
        }
        int v1 = /*EL:175*/InventoryUtil.findHotbarBlock(BlockObsidian.class);
        final int v2 = /*EL:176*/InventoryUtil.findHotbarBlock(BlockEnderChest.class);
        /*SL:177*/if (v1 == -1 && v2 == -1) {
            /*SL:178*/this.toggle();
        }
        /*SL:180*/this.offHand = InventoryUtil.isBlock(Surround.mc.field_71439_g.func_184592_cb().func_77973_b(), BlockObsidian.class);
        Surround.isPlacing = /*EL:181*/false;
        /*SL:182*/this.didPlace = false;
        /*SL:183*/this.extenders = 1;
        /*SL:184*/this.placements = 0;
        /*SL:185*/v1 = InventoryUtil.findHotbarBlock(BlockObsidian.class);
        final int v3 = /*EL:186*/InventoryUtil.findHotbarBlock(BlockEnderChest.class);
        /*SL:187*/if (this.isOff()) {
            /*SL:188*/return true;
        }
        /*SL:190*/if (this.retryTimer.passedMs(2500L)) {
            /*SL:191*/this.retries.clear();
            /*SL:192*/this.retryTimer.reset();
        }
        /*SL:194*/if (v1 == -1 && !this.offHand && v3 == -1) {
            /*SL:195*/Command.sendMessage("<" + this.getDisplayName() + "> " + ChatFormatting.RED + "No Obsidian in hotbar disabling...");
            /*SL:196*/this.disable();
            /*SL:197*/return true;
        }
        /*SL:199*/this.isSneaking = EntityUtil.stopSneaking(this.isSneaking);
        /*SL:200*/if (Surround.mc.field_71439_g.field_71071_by.field_70461_c != this.lastHotbarSlot && Surround.mc.field_71439_g.field_71071_by.field_70461_c != v1 && Surround.mc.field_71439_g.field_71071_by.field_70461_c != v3) {
            /*SL:201*/this.lastHotbarSlot = Surround.mc.field_71439_g.field_71071_by.field_70461_c;
        }
        /*SL:203*/if (!this.startPos.equals((Object)EntityUtil.getRoundedBlockPos((Entity)Surround.mc.field_71439_g))) {
            /*SL:204*/this.disable();
            /*SL:205*/return true;
        }
        /*SL:207*/return !this.timer.passedMs(this.delay.getValue());
    }
    
    private void placeBlock(final BlockPos v-1) {
        /*SL:211*/if (this.placements < this.blocksPerTick.getValue()) {
            final int a1 = Surround.mc.field_71439_g.field_71071_by.field_70461_c;
            final int v1 = /*EL:213*/InventoryUtil.findHotbarBlock(BlockObsidian.class);
            final int v2 = /*EL:214*/InventoryUtil.findHotbarBlock(BlockEnderChest.class);
            /*SL:215*/if (v1 == -1 && v2 == -1) {
                /*SL:216*/this.toggle();
            }
            Surround.isPlacing = /*EL:218*/true;
            Surround.mc.field_71439_g.field_71071_by.field_70461_c = /*EL:219*/((v1 == -1) ? v2 : v1);
            Surround.mc.field_71442_b.func_78765_e();
            /*SL:221*/this.isSneaking = BlockUtil.placeBlock(v-1, this.offHand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND, this.rotate.getValue(), this.noGhost.getValue(), this.isSneaking);
            Surround.mc.field_71439_g.field_71071_by.field_70461_c = /*EL:222*/a1;
            Surround.mc.field_71442_b.func_78765_e();
            /*SL:224*/this.didPlace = true;
            /*SL:225*/++this.placements;
        }
    }
    
    static {
        Surround.isPlacing = false;
    }
}
