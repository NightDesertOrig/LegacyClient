package me.dev.legacy.modules.combat;

import net.minecraft.block.BlockObsidian;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import java.util.Iterator;
import net.minecraft.block.Block;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.world.GameType;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.Vec3i;
import me.dev.legacy.api.util.BlockInteractionHelper;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.BlockAir;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import me.dev.legacy.modules.ModuleManager;
import me.dev.legacy.Legacy;
import net.minecraft.network.Packet;
import net.minecraft.entity.Entity;
import net.minecraft.network.play.client.CPacketEntityAction;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class AntiCity extends Module
{
    private final Setting<Boolean> triggerable;
    private final Setting<Boolean> turnOffCauras;
    private final Setting<Integer> timeoutTicks;
    private final Setting<Integer> blocksPerTick;
    private final Setting<Integer> tickDelay;
    private final Setting<Boolean> rotate;
    private final Setting<Boolean> noGlitchBlocks;
    private int playerHotbarSlot;
    private int lastHotbarSlot;
    private int offsetStep;
    private int delayStep;
    private int totalTicksRunning;
    private boolean firstRun;
    private boolean isSneaking;
    double oldY;
    int cDelay;
    String caura;
    boolean isDisabling;
    boolean hasDisabled;
    
    public AntiCity() {
        super("AntiCity", "AntiCity.", Category.COMBAT, true, false, false);
        this.triggerable = (Setting<Boolean>)this.register(new Setting("Triggerable", (T)true));
        this.turnOffCauras = (Setting<Boolean>)this.register(new Setting("Toggle Other Cauras", (T)true));
        this.timeoutTicks = (Setting<Integer>)this.register(new Setting("TimeoutTicks", (T)40, (T)1, (T)100));
        this.blocksPerTick = (Setting<Integer>)this.register(new Setting("BlocksPerTick", (T)4, (T)1, (T)9));
        this.tickDelay = (Setting<Integer>)this.register(new Setting("TickDelay", (T)0, (T)0, (T)10));
        this.rotate = (Setting<Boolean>)this.register(new Setting("Rotate", (T)true));
        this.noGlitchBlocks = (Setting<Boolean>)this.register(new Setting("NoGlitchBlocks", (T)true));
        this.cDelay = 0;
        this.playerHotbarSlot = -1;
        this.lastHotbarSlot = -1;
        this.offsetStep = 0;
        this.delayStep = 0;
        this.totalTicksRunning = 0;
        this.isSneaking = false;
    }
    
    @Override
    public void onEnable() {
        /*SL:71*/if (Surround.mc.field_71439_g == null) {
            /*SL:72*/this.disable();
            /*SL:73*/return;
        }
        /*SL:75*/this.hasDisabled = false;
        /*SL:76*/this.oldY = AntiCity.mc.field_71439_g.field_70163_u;
        /*SL:77*/this.firstRun = true;
        /*SL:78*/this.playerHotbarSlot = Surround.mc.field_71439_g.field_71071_by.field_70461_c;
        /*SL:79*/this.lastHotbarSlot = -1;
    }
    
    @Override
    public void onDisable() {
        /*SL:84*/if (Surround.mc.field_71439_g == null) {
            /*SL:85*/return;
        }
        /*SL:87*/if (this.lastHotbarSlot != this.playerHotbarSlot && this.playerHotbarSlot != -1) {
            Surround.mc.field_71439_g.field_71071_by.field_70461_c = /*EL:88*/this.playerHotbarSlot;
        }
        /*SL:90*/if (this.isSneaking) {
            Surround.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:91*/(Packet)new CPacketEntityAction((Entity)Surround.mc.field_71439_g, CPacketEntityAction.Action.STOP_SNEAKING));
            /*SL:92*/this.isSneaking = false;
        }
        /*SL:94*/this.playerHotbarSlot = -1;
        /*SL:95*/this.lastHotbarSlot = -1;
    }
    
    @Override
    public void onUpdate() {
        /*SL:100*/if (this.cDelay > 0) {
            /*SL:101*/--this.cDelay;
        }
        /*SL:103*/if (this.cDelay == 0 && this.isDisabling) {
            Legacy.moduleManager.getModuleByName(/*EL:104*/this.caura).toggle();
            /*SL:105*/this.isDisabling = false;
            /*SL:106*/this.hasDisabled = true;
        }
        /*SL:108*/if (Surround.mc.field_71439_g != null) {
            final ModuleManager moduleManager = Legacy.moduleManager;
            if (!ModuleManager.isModuleEnabled("Freecam")) {
                /*SL:111*/if (Legacy.moduleManager.getModuleByName("AutoCrystal") != null && Legacy.moduleManager.getModuleByName("AutoCrystal").isEnabled() && this.turnOffCauras.getValue() && !this.hasDisabled) {
                    /*SL:112*/this.caura = "AutoCrystal";
                    /*SL:113*/this.cDelay = 19;
                    /*SL:114*/this.isDisabling = true;
                    Legacy.moduleManager.getModuleByName(/*EL:115*/this.caura).toggle();
                }
                /*SL:117*/if (this.triggerable.getValue() && this.totalTicksRunning >= this.timeoutTicks.getValue()) {
                    /*SL:118*/this.totalTicksRunning = 0;
                    /*SL:119*/this.disable();
                    /*SL:120*/return;
                }
                /*SL:122*/if (AntiCity.mc.field_71439_g.field_70163_u != this.oldY) {
                    /*SL:123*/this.disable();
                    /*SL:124*/return;
                }
                /*SL:126*/if (!this.firstRun) {
                    /*SL:127*/if (this.delayStep < this.tickDelay.getValue()) {
                        /*SL:128*/++this.delayStep;
                        /*SL:129*/return;
                    }
                    /*SL:131*/this.delayStep = 0;
                }
                /*SL:133*/if (this.firstRun) {
                    /*SL:134*/this.firstRun = false;
                }
                int v0 = /*EL:136*/0;
                /*SL:137*/while (v0 < this.blocksPerTick.getValue()) {
                    Vec3d[] v = /*EL:138*/new Vec3d[0];
                    int v2 = /*EL:139*/0;
                    /*SL:140*/v = Offsets.SURROUND;
                    /*SL:141*/v2 = Offsets.SURROUND.length;
                    /*SL:142*/if (this.offsetStep >= v2) {
                        /*SL:143*/this.offsetStep = 0;
                        /*SL:144*/break;
                    }
                    final BlockPos v3 = /*EL:146*/new BlockPos(v[this.offsetStep]);
                    final BlockPos v4 = /*EL:147*/new BlockPos(Surround.mc.field_71439_g.func_174791_d()).func_177982_a(v3.func_177958_n(), v3.func_177956_o(), v3.func_177952_p());
                    /*SL:148*/if (this.placeBlock(v4)) {
                        /*SL:149*/++v0;
                    }
                    /*SL:151*/++this.offsetStep;
                }
                /*SL:153*/if (v0 > 0) {
                    /*SL:154*/if (this.lastHotbarSlot != this.playerHotbarSlot && this.playerHotbarSlot != -1) {
                        Surround.mc.field_71439_g.field_71071_by.field_70461_c = /*EL:155*/this.playerHotbarSlot;
                        /*SL:156*/this.lastHotbarSlot = this.playerHotbarSlot;
                    }
                    /*SL:158*/if (this.isSneaking) {
                        Surround.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:159*/(Packet)new CPacketEntityAction((Entity)Surround.mc.field_71439_g, CPacketEntityAction.Action.STOP_SNEAKING));
                        /*SL:160*/this.isSneaking = false;
                    }
                }
                /*SL:163*/++this.totalTicksRunning;
            }
        }
    }
    
    private boolean placeBlock(final BlockPos v2) {
        final Block v3 = Surround.mc.field_71441_e.func_180495_p(/*EL:167*/v2).func_177230_c();
        /*SL:168*/if (!(v3 instanceof BlockAir) && !(v3 instanceof BlockLiquid)) {
            /*SL:169*/return false;
        }
        /*SL:171*/for (final Entity a1 : Surround.mc.field_71441_e.func_72839_b((Entity)null, new AxisAlignedBB(v2))) {
            /*SL:172*/if (!(a1 instanceof EntityItem) && !(a1 instanceof EntityXPOrb)) {
                /*SL:173*/return false;
            }
        }
        final EnumFacing v4 = /*EL:176*/BlockInteractionHelper.getPlaceableSide(v2);
        /*SL:177*/if (v4 == null) {
            /*SL:178*/return false;
        }
        final BlockPos v5 = /*EL:180*/v2.func_177972_a(v4);
        final EnumFacing v6 = /*EL:181*/v4.func_176734_d();
        /*SL:182*/if (!BlockInteractionHelper.canBeClicked(v5)) {
            /*SL:183*/return false;
        }
        final Vec3d v7 = /*EL:185*/new Vec3d((Vec3i)v5).func_72441_c(0.5, 0.5, 0.5).func_178787_e(new Vec3d(v6.func_176730_m()).func_186678_a(0.5));
        final Block v8 = Surround.mc.field_71441_e.func_180495_p(/*EL:186*/v5).func_177230_c();
        final int v9 = /*EL:187*/this.findObiInHotbar();
        /*SL:188*/if (v9 == -1) {
            /*SL:189*/this.disable();
        }
        /*SL:191*/if (this.lastHotbarSlot != v9) {
            Surround.mc.field_71439_g.field_71071_by.field_70461_c = /*EL:192*/v9;
            /*SL:193*/this.lastHotbarSlot = v9;
        }
        /*SL:195*/if ((!this.isSneaking && BlockInteractionHelper.blackList.contains(v8)) || BlockInteractionHelper.shulkerList.contains(v8)) {
            Surround.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:196*/(Packet)new CPacketEntityAction((Entity)Surround.mc.field_71439_g, CPacketEntityAction.Action.START_SNEAKING));
            /*SL:197*/this.isSneaking = true;
        }
        /*SL:199*/if (this.rotate.getValue()) {
            /*SL:200*/BlockInteractionHelper.faceVectorPacketInstant(v7);
        }
        Surround.mc.field_71442_b.func_187099_a(Surround.mc.field_71439_g, Surround.mc.field_71441_e, /*EL:202*/v5, v6, v7, EnumHand.MAIN_HAND);
        Surround.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
        Surround.mc.field_71467_ac = /*EL:204*/4;
        /*SL:205*/if (this.noGlitchBlocks.getValue() && !Surround.mc.field_71442_b.func_178889_l().equals((Object)GameType.CREATIVE)) {
            Surround.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:206*/(Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, v5, v6));
        }
        /*SL:208*/return true;
    }
    
    private int findObiInHotbar() {
        int n = /*EL:212*/-1;
        /*SL:213*/for (int i = 0; i < 9; ++i) {
            final ItemStack v0 = Surround.mc.field_71439_g.field_71071_by.func_70301_a(/*EL:214*/i);
            /*SL:215*/if (v0 != ItemStack.field_190927_a && v0.func_77973_b() instanceof ItemBlock) {
                final Block v = /*EL:216*/((ItemBlock)v0.func_77973_b()).func_179223_d();
                /*SL:217*/if (v instanceof BlockObsidian) {
                    /*SL:218*/n = i;
                    /*SL:219*/break;
                }
            }
        }
        /*SL:223*/return n;
    }
    
    private enum Mode
    {
        SURROUND, 
        FULL;
    }
    
    private static class Offsets
    {
        private static final Vec3d[] SURROUND;
        
        static {
            SURROUND = new Vec3d[] { new Vec3d(2.0, 0.0, 0.0), new Vec3d(0.0, 0.0, 2.0), new Vec3d(-2.0, 0.0, 0.0), new Vec3d(0.0, 0.0, -2.0) };
        }
    }
}
