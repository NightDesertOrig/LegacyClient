package me.dev.legacy.modules.combat;

import net.minecraft.item.Item;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import net.minecraft.util.ResourceLocation;
import net.minecraft.potion.PotionUtils;
import me.dev.legacy.api.util.InventoryUtil;
import net.minecraft.init.Items;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.item.ItemBow;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class Quiver extends Module
{
    private final Setting<Integer> tickDelay;
    
    public Quiver() {
        super("Quiver", "Rotates and shoots yourself with good potion effects", Category.COMBAT, true, false, false);
        this.tickDelay = (Setting<Integer>)this.register(new Setting("TickDelay", (T)3, (T)0, (T)8));
    }
    
    @Override
    public void onUpdate() {
        /*SL:20*/if (Quiver.mc.field_71439_g != null) {
            /*SL:21*/if (Quiver.mc.field_71439_g.field_71071_by.func_70448_g().func_77973_b() instanceof ItemBow && Quiver.mc.field_71439_g.func_184587_cr() && Quiver.mc.field_71439_g.func_184612_cw() >= this.tickDelay.getValue()) {
                Quiver.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:22*/(Packet)new CPacketPlayer.Rotation(Quiver.mc.field_71439_g.field_71109_bG, -90.0f, Quiver.mc.field_71439_g.field_70122_E));
                Quiver.mc.field_71442_b.func_78766_c((EntityPlayer)Quiver.mc.field_71439_g);
            }
            final List<Integer> itemInventory = /*EL:25*/InventoryUtil.getItemInventory(Items.field_185167_i);
            /*SL:26*/if (itemInventory.get(0) == -1) {
                return;
            }
            int intValue = /*EL:27*/-1;
            int intValue2 = /*EL:28*/-1;
            /*SL:29*/for (final Integer v1 : itemInventory) {
                /*SL:31*/if (PotionUtils.func_185191_c(Quiver.mc.field_71439_g.field_71071_by.func_70301_a((int)v1)).getRegistryName().func_110623_a().contains("swiftness")) {
                    intValue = v1;
                }
                else {
                    /*SL:32*/if (!Objects.<ResourceLocation>requireNonNull(PotionUtils.func_185191_c(Quiver.mc.field_71439_g.field_71071_by.func_70301_a((int)v1)).getRegistryName()).func_110623_a().contains("strength")) {
                        continue;
                    }
                    intValue2 = v1;
                }
            }
        }
    }
    
    @Override
    public void onEnable() {
    }
    
    private int findBow() {
        /*SL:43*/return InventoryUtil.getItemHotbar((Item)Items.field_151031_f);
    }
}
