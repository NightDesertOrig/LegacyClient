package me.dev.legacy.modules.movement;

import net.minecraft.util.math.BlockPos;
import me.dev.legacy.Legacy;
import net.minecraft.client.entity.EntityPlayerSP;
import java.util.function.Predicate;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.network.play.server.SPacketPlayerPosLook;
import net.minecraft.client.settings.KeyBinding;
import me.zero.alpine.listener.EventHandler;
import me.dev.legacy.api.event.events.other.PacketEvent;
import me.zero.alpine.listener.Listener;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class Phase extends Module
{
    Setting<Boolean> debug;
    Setting<Boolean> twodelay;
    Setting<Boolean> advd;
    Setting<Boolean> EnhancedRots;
    Setting<Boolean> invert;
    Setting<Boolean> SendRotPackets;
    Setting<Boolean> twobeepvp;
    Setting<Boolean> PUP;
    Setting<Integer> tickDelay;
    Setting<Integer> EnhancedRotsAmount;
    Setting<Double> speed;
    Setting<Mode> cmode;
    @EventHandler
    private Listener<PacketEvent.Receive> receiveListener;
    KeyBinding left;
    KeyBinding right;
    KeyBinding down;
    KeyBinding up;
    long last;
    
    public Phase() {
        super("Phase", "Block phase", Category.MOVEMENT, false, false, false);
        this.debug = (Setting<Boolean>)this.register(new Setting("Debug", (T)false));
        this.twodelay = (Setting<Boolean>)this.register(new Setting("2Delay", (T)true));
        this.advd = (Setting<Boolean>)this.register(new Setting("AVD", (T)false));
        this.EnhancedRots = (Setting<Boolean>)this.register(new Setting("EnchancedControl", (T)false));
        this.invert = (Setting<Boolean>)this.register(new Setting("InvertedYaw", (T)false));
        this.SendRotPackets = (Setting<Boolean>)this.register(new Setting("SendRotPackets", (T)true));
        this.twobeepvp = (Setting<Boolean>)this.register(new Setting("2b2tpvp", (T)true));
        this.PUP = (Setting<Boolean>)this.register(new Setting("PUP", (T)true));
        this.tickDelay = (Setting<Integer>)this.register(new Setting("TickDelay", (T)2, (T)0, (T)40));
        this.EnhancedRotsAmount = (Setting<Integer>)this.register(new Setting("EnhancedCtrlSpeed", (T)2, (T)0, (T)20));
        this.speed = (Setting<Double>)this.register(new Setting("Speed", (T)6.25, (T)0.0, (T)6.25));
        this.cmode = (Setting<Mode>)this.register(new Setting("ControlMode", (T)Mode.Rel));
        final SPacketPlayerPosLook a1;
        final SPacketPlayerPosLook v;
        double v2;
        final double v3;
        double v4;
        final EntityPlayerSP field_71439_g;
        final TextComponentString textComponentString;
        this.receiveListener = new Listener<PacketEvent.Receive>(v0 -> {
            if (v0.getPacket() instanceof SPacketPlayerPosLook) {
                a1 = (SPacketPlayerPosLook)v0.getPacket();
                a1.field_148936_d = Phase.mc.field_71439_g.field_70177_z;
                a1.field_148937_e = Phase.mc.field_71439_g.field_70125_A;
            }
            if (v0.getPacket() instanceof SPacketPlayerPosLook) {
                v = (SPacketPlayerPosLook)v0.getPacket();
                v2 = Math.abs(v.func_179834_f().contains(SPacketPlayerPosLook.EnumFlags.X) ? v.field_148940_a : (Phase.mc.field_71439_g.field_70165_t - v.field_148940_a));
                v3 = Math.abs(v.func_179834_f().contains(SPacketPlayerPosLook.EnumFlags.Y) ? v.field_148938_b : (Phase.mc.field_71439_g.field_70163_u - v.field_148938_b));
                v4 = Math.abs(v.func_179834_f().contains(SPacketPlayerPosLook.EnumFlags.Z) ? v.field_148939_c : (Phase.mc.field_71439_g.field_70161_v - v.field_148939_c));
                if (v2 < 0.001) {
                    v2 = 0.0;
                }
                if (v4 < 0.001) {
                    v4 = 0.0;
                }
                if ((v2 != 0.0 || v3 != 0.0 || v4 != 0.0) && this.debug.getValue()) {
                    field_71439_g = Phase.mc.field_71439_g;
                    new TextComponentString("position pak, dx=" + v2 + " dy=" + v3 + " dz=" + v4);
                    field_71439_g.func_145747_a((ITextComponent)textComponentString);
                }
                if (v.field_148936_d != Phase.mc.field_71439_g.field_70177_z || v.field_148937_e != Phase.mc.field_71439_g.field_70125_A) {
                    if (this.SendRotPackets.getValue()) {
                        Phase.mc.func_147114_u().func_147297_a((Packet)new CPacketPlayer.Rotation(Phase.mc.field_71439_g.field_70177_z, Phase.mc.field_71439_g.field_70125_A, Phase.mc.field_71439_g.field_70122_E));
                    }
                    v.field_148936_d = Phase.mc.field_71439_g.field_70177_z;
                    v.field_148937_e = Phase.mc.field_71439_g.field_70125_A;
                }
            }
            return;
        }, (Predicate<PacketEvent.Receive>[])new Predicate[0]);
        this.last = 0L;
    }
    
    @Override
    public void onUpdate() {
        try {
            Phase.mc.field_71439_g.field_70145_X = /*EL:75*/true;
            /*SL:77*/if (this.tickDelay.getValue() > 0 && Phase.mc.field_71439_g.field_70173_aa % this.tickDelay.getValue() != 0 && this.twodelay.getValue()) {
                return;
            }
            final int intValue = /*EL:79*/this.EnhancedRotsAmount.getValue();
            /*SL:81*/if (this.EnhancedRots.getValue() && this.up.func_151470_d()) {
                final EntityPlayerSP field_71439_g = Phase.mc.field_71439_g;
                field_71439_g.field_70125_A -= intValue;
            }
            /*SL:82*/if (this.EnhancedRots.getValue() && this.down.func_151470_d()) {
                final EntityPlayerSP field_71439_g2 = Phase.mc.field_71439_g;
                field_71439_g2.field_70125_A += intValue;
            }
            /*SL:84*/if (this.EnhancedRots.getValue() && this.left.func_151470_d()) {
                final EntityPlayerSP field_71439_g3 = Phase.mc.field_71439_g;
                field_71439_g3.field_70177_z -= intValue;
            }
            /*SL:85*/if (this.EnhancedRots.getValue() && this.right.func_151470_d()) {
                final EntityPlayerSP field_71439_g4 = Phase.mc.field_71439_g;
                field_71439_g4.field_70177_z += intValue;
            }
            double n = (Phase.mc.field_71439_g.field_70177_z + /*EL:87*/90.0f) * (this.invert.getValue() ? -1 : 1);
            double cos;
            double sin;
            /*SL:91*/if (this.cmode.getValue().equals("Rel")) {
                double v1 = /*EL:92*/0.0;
                double v2 = /*EL:93*/0.0;
                /*SL:95*/if (Phase.mc.field_71474_y.field_74370_x.func_151470_d()) {
                    /*SL:96*/v1 -= 90.0;
                    /*SL:97*/++v2;
                }
                /*SL:99*/if (Phase.mc.field_71474_y.field_74366_z.func_151470_d()) {
                    /*SL:100*/v1 += 90.0;
                    /*SL:101*/++v2;
                }
                /*SL:103*/if (Phase.mc.field_71474_y.field_74368_y.func_151470_d()) {
                    /*SL:104*/v1 += 180.0;
                    /*SL:105*/++v2;
                }
                /*SL:107*/if (Phase.mc.field_71474_y.field_74351_w.func_151470_d()) {
                    /*SL:108*/++v2;
                }
                /*SL:111*/if (v2 > 0.0) {
                    n += v1 / v2 % 361.0;
                }
                /*SL:114*/if (n < 0.0) {
                    n = 360.0 - n;
                }
                /*SL:115*/if (n > 360.0) {
                    n %= 361.0;
                }
                /*SL:117*/cos = Math.cos(Math.toRadians(n));
                /*SL:118*/sin = Math.sin(Math.toRadians(n));
            }
            else {
                /*SL:126*/cos = 0.0;
                /*SL:127*/sin = 0.0;
                /*SL:129*/cos += (Phase.mc.field_71474_y.field_74351_w.func_151470_d() ? 1.0 : 0.0);
                /*SL:130*/cos -= (Phase.mc.field_71474_y.field_74368_y.func_151470_d() ? 1.0 : 0.0);
                /*SL:132*/sin += (Phase.mc.field_71474_y.field_74370_x.func_151470_d() ? 1.0 : 0.0);
                /*SL:133*/sin -= (Phase.mc.field_71474_y.field_74366_z.func_151470_d() ? 1.0 : 0.0);
            }
            /*SL:136*/if (Phase.mc.field_71474_y.field_74351_w.func_151470_d() || Phase.mc.field_71474_y.field_74370_x.func_151470_d() || Phase.mc.field_71474_y.field_74366_z.func_151470_d() || Phase.mc.field_71474_y.field_74368_y.func_151470_d()) {
                Phase.mc.field_71439_g.field_70159_w = /*EL:137*/cos * (this.speed.getValue() / 100.0);
                Phase.mc.field_71439_g.field_70179_y = /*EL:138*/sin * (this.speed.getValue() / 100.0);
            }
            Phase.mc.field_71439_g.field_70181_x = /*EL:140*/0.0;
            boolean v3 = /*EL:142*/false;
            /*SL:143*/if (this.advd.getValue()) {
                /*SL:144*/if (this.last + 50L >= System.currentTimeMillis()) {
                    /*SL:145*/v3 = false;
                }
                else {
                    /*SL:147*/this.last = System.currentTimeMillis();
                    /*SL:148*/v3 = true;
                }
            }
            Phase.mc.field_71439_g.field_70145_X = /*EL:152*/true;
            /*SL:153*/if (v3) {
                Phase.mc.func_147114_u().func_147297_a(/*EL:154*/(Packet)new CPacketPlayer.Position(Phase.mc.field_71439_g.field_70165_t + Phase.mc.field_71439_g.field_70159_w, Phase.mc.field_71439_g.field_70163_u + ((Phase.mc.field_71439_g.field_70163_u < (this.twobeepvp.getValue() ? 1.1 : -0.98)) ? (this.speed.getValue() / 100.0) : 0.0) + (Phase.mc.field_71474_y.field_74314_A.func_151470_d() ? (this.speed.getValue() / 100.0) : 0.0) - (Phase.mc.field_71474_y.field_74311_E.func_151470_d() ? (this.speed.getValue() / 100.0) : 0.0), Phase.mc.field_71439_g.field_70161_v + Phase.mc.field_71439_g.field_70179_y, false));
            }
            /*SL:156*/if (this.PUP.getValue()) {
                Phase.mc.field_71439_g.field_70145_X = /*EL:157*/true;
                Phase.mc.field_71439_g.func_70012_b(Phase.mc.field_71439_g.field_70165_t + Phase.mc.field_71439_g.field_70159_w, Phase.mc.field_71439_g.field_70163_u, Phase.mc.field_71439_g.field_70161_v + Phase.mc.field_71439_g.field_70179_y, Phase.mc.field_71439_g.field_70177_z, Phase.mc.field_71439_g.field_70125_A);
            }
            Phase.mc.field_71439_g.field_70145_X = /*EL:161*/true;
            /*SL:162*/if (v3) {
                Phase.mc.func_147114_u().func_147297_a(/*EL:163*/(Packet)new CPacketPlayer.Position(Phase.mc.field_71439_g.field_70165_t + Phase.mc.field_71439_g.field_70159_w, Phase.mc.field_71439_g.field_70163_u - 42069.0, Phase.mc.field_71439_g.field_70161_v + Phase.mc.field_71439_g.field_70179_y, true));
            }
            final double v4 = /*EL:165*/0.0;
            double v5 = 0.0;
            final double v6 = 0.0;
            /*SL:166*/if (Phase.mc.field_71474_y.field_74311_E.func_151470_d()) {
                /*SL:167*/v5 = -0.0625;
            }
            /*SL:169*/if (Phase.mc.field_71474_y.field_74314_A.func_151470_d()) {
                /*SL:170*/v5 = 0.0625;
            }
            Phase.mc.field_71439_g.func_70012_b(Phase.mc.field_71439_g.field_70165_t, Phase.mc.field_71439_g.field_70163_u, Phase.mc.field_71439_g.field_70161_v, Phase.mc.field_71439_g.field_70177_z, Phase.mc.field_71439_g.field_70125_A);
            Phase.mc.func_147114_u().func_147297_a(/*EL:174*/(Packet)new CPacketPlayer.Position(Phase.mc.field_71439_g.field_70165_t, Phase.mc.field_71439_g.field_70163_u, Phase.mc.field_71439_g.field_70161_v, false));
        }
        catch (Exception ex) {
            /*SL:177*/this.disable();
        }
    }
    
    @Override
    public void onEnable() {
        /*SL:184*/Legacy.getEventManager().subscribe(this);
    }
    
    @Override
    public void onDisable() {
        /*SL:189*/if (Phase.mc.field_71439_g != null) {
            Phase.mc.field_71439_g.field_70145_X = false;
        }
        /*SL:190*/Legacy.getEventManager().unsubscribe(this);
    }
    
    public static BlockPos getPlayerPos() {
        /*SL:194*/return new BlockPos(Math.floor(Phase.mc.field_71439_g.field_70165_t), Math.floor(Phase.mc.field_71439_g.field_70163_u), Math.floor(Phase.mc.field_71439_g.field_70161_v));
    }
    
    public enum Mode
    {
        Rel, 
        Abs;
    }
}
