package me.dev.legacy.modules.movement;

import net.minecraft.block.BlockLiquid;
import net.minecraft.util.math.MathHelper;
import me.dev.legacy.api.util.HoleUtil;
import net.minecraft.init.Blocks;
import net.minecraft.world.IBlockAccess;
import net.minecraft.block.BlockSlab;
import net.minecraft.block.state.IBlockState;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.block.material.Material;
import me.dev.legacy.modules.ModuleManager;
import me.dev.legacy.modules.Module;

public class HoleTP extends Module
{
    private int packets;
    private boolean jumped;
    private final double[] oneblockPositions;
    
    public HoleTP() {
        super("HoleTP", "Teleports you in a hole.", Category.MOVEMENT, false, false, false);
        this.oneblockPositions = new double[] { 0.42, 0.75 };
    }
    
    @Override
    public void onUpdate() {
        /*SL:26*/if (HoleTP.mc.field_71441_e == null || HoleTP.mc.field_71439_g == null || ModuleManager.isModuleEnabled(Speed.class)) {
            /*SL:27*/return;
        }
        /*SL:29*/if (!HoleTP.mc.field_71439_g.field_70122_E) {
            /*SL:30*/if (HoleTP.mc.field_71474_y.field_74314_A.func_151470_d()) {
                /*SL:31*/this.jumped = true;
            }
        }
        else {
            /*SL:34*/this.jumped = false;
        }
        /*SL:36*/if (!this.jumped && HoleTP.mc.field_71439_g.field_70143_R < 0.5 && this.isInHole() && HoleTP.mc.field_71439_g.field_70163_u - this.getNearestBlockBelow() <= 1.125 && HoleTP.mc.field_71439_g.field_70163_u - this.getNearestBlockBelow() <= 0.95 && !this.isOnLiquid() && !this.isInLiquid()) {
            /*SL:37*/if (!HoleTP.mc.field_71439_g.field_70122_E) {
                /*SL:38*/++this.packets;
            }
            /*SL:40*/if (!HoleTP.mc.field_71439_g.field_70122_E && !HoleTP.mc.field_71439_g.func_70055_a(Material.field_151586_h) && !HoleTP.mc.field_71439_g.func_70055_a(Material.field_151587_i) && !HoleTP.mc.field_71474_y.field_74314_A.func_151470_d() && !HoleTP.mc.field_71439_g.func_70617_f_() && this.packets > 0) {
                final BlockPos blockPos = /*EL:41*/new BlockPos(HoleTP.mc.field_71439_g.field_70165_t, HoleTP.mc.field_71439_g.field_70163_u, HoleTP.mc.field_71439_g.field_70161_v);
                /*SL:42*/for (final double v1 : this.oneblockPositions) {
                    HoleTP.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:43*/(Packet)new CPacketPlayer.Position((double)(blockPos.func_177958_n() + 0.5f), HoleTP.mc.field_71439_g.field_70163_u - v1, (double)(blockPos.func_177952_p() + 0.5f), true));
                }
                HoleTP.mc.field_71439_g.func_70107_b(/*EL:45*/(double)(blockPos.func_177958_n() + 0.5f), this.getNearestBlockBelow() + 0.1, (double)(blockPos.func_177952_p() + 0.5f));
                /*SL:46*/this.packets = 0;
            }
        }
    }
    
    private boolean isInHole() {
        final BlockPos v1 = /*EL:52*/new BlockPos(HoleTP.mc.field_71439_g.field_70165_t, HoleTP.mc.field_71439_g.field_70163_u, HoleTP.mc.field_71439_g.field_70161_v);
        final IBlockState v2 = HoleTP.mc.field_71441_e.func_180495_p(/*EL:53*/v1);
        /*SL:54*/return this.isBlockValid(v2, v1);
    }
    
    private double getNearestBlockBelow() {
        /*SL:58*/for (int v1 = (int)Math.floor(HoleTP.mc.field_71439_g.field_70163_u); v1 > 0.0; --v1) {
            /*SL:59*/if (!(HoleTP.mc.field_71441_e.func_180495_p(new BlockPos(HoleTP.mc.field_71439_g.field_70165_t, (double)v1, HoleTP.mc.field_71439_g.field_70161_v)).func_177230_c() instanceof BlockSlab) && HoleTP.mc.field_71441_e.func_180495_p(new BlockPos(HoleTP.mc.field_71439_g.field_70165_t, (double)v1, HoleTP.mc.field_71439_g.field_70161_v)).func_177230_c().func_176223_P().func_185890_d((IBlockAccess)HoleTP.mc.field_71441_e, new BlockPos(0, 0, 0)) != null) {
                /*SL:60*/return v1 + 1;
            }
        }
        /*SL:63*/return -1.0;
    }
    
    private boolean isBlockValid(final IBlockState a1, final BlockPos a2) {
        /*SL:67*/return a1.func_177230_c() == Blocks.field_150350_a && HoleTP.mc.field_71439_g.func_174818_b(a2) >= 1.0 && HoleTP.mc.field_71441_e.func_180495_p(a2.func_177984_a()).func_177230_c() == Blocks.field_150350_a && HoleTP.mc.field_71441_e.func_180495_p(a2.func_177981_b(2)).func_177230_c() == Blocks.field_150350_a && this.isSafeHole(a2);
    }
    
    private boolean isSafeHole(final BlockPos a1) {
        /*SL:71*/return HoleUtil.isHole(a1, true, false).getType() != HoleUtil.HoleType.NONE;
    }
    
    private boolean isOnLiquid() {
        final double n = HoleTP.mc.field_71439_g.field_70163_u - /*EL:75*/0.03;
        /*SL:76*/for (int i = MathHelper.func_76128_c(HoleTP.mc.field_71439_g.field_70165_t); i < MathHelper.func_76143_f(HoleTP.mc.field_71439_g.field_70165_t); ++i) {
            /*SL:77*/for (int v0 = MathHelper.func_76128_c(HoleTP.mc.field_71439_g.field_70161_v); v0 < MathHelper.func_76143_f(HoleTP.mc.field_71439_g.field_70161_v); ++v0) {
                final BlockPos v = /*EL:78*/new BlockPos(i, MathHelper.func_76128_c(n), v0);
                /*SL:79*/if (HoleTP.mc.field_71441_e.func_180495_p(v).func_177230_c() instanceof BlockLiquid) {
                    /*SL:80*/return true;
                }
            }
        }
        /*SL:84*/return false;
    }
    
    private boolean isInLiquid() {
        final double n = HoleTP.mc.field_71439_g.field_70163_u + /*EL:88*/0.01;
        /*SL:89*/for (int i = MathHelper.func_76128_c(HoleTP.mc.field_71439_g.field_70165_t); i < MathHelper.func_76143_f(HoleTP.mc.field_71439_g.field_70165_t); ++i) {
            /*SL:90*/for (int v0 = MathHelper.func_76128_c(HoleTP.mc.field_71439_g.field_70161_v); v0 < MathHelper.func_76143_f(HoleTP.mc.field_71439_g.field_70161_v); ++v0) {
                final BlockPos v = /*EL:91*/new BlockPos(i, (int)n, v0);
                /*SL:92*/if (HoleTP.mc.field_71441_e.func_180495_p(v).func_177230_c() instanceof BlockLiquid) {
                    /*SL:93*/return true;
                }
            }
        }
        /*SL:97*/return false;
    }
}
