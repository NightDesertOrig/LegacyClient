package me.dev.legacy.modules.movement;

import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.network.play.client.CPacketPlayer;
import me.dev.legacy.api.event.events.other.PacketEvent;
import net.minecraft.client.gui.GuiChat;
import me.dev.legacy.api.event.events.other.KeyPressedEvent;
import net.minecraft.util.MovementInput;
import net.minecraftforge.client.event.InputUpdateEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.item.ItemPotion;
import net.minecraft.item.ItemBow;
import net.minecraft.item.ItemFood;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraft.item.Item;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.network.Packet;
import net.minecraft.entity.Entity;
import net.minecraft.network.play.client.CPacketEntityAction;
import me.dev.legacy.Legacy;
import org.lwjgl.input.Keyboard;
import net.minecraft.client.gui.GuiIngameMenu;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.gui.GuiScreenOptionsSounds;
import net.minecraft.client.gui.GuiVideoSettings;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.settings.KeyBinding;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class NoSlow extends Module
{
    public Setting<Boolean> guiMove;
    public Setting<Boolean> noSlow;
    public Setting<Boolean> strict;
    public Setting<Boolean> sneakPacket;
    public Setting<Boolean> webs;
    public final Setting<Double> webHorizontalFactor;
    public final Setting<Double> webVerticalFactor;
    private static NoSlow INSTANCE;
    private boolean sneaking;
    private static KeyBinding[] keys;
    
    public NoSlow() {
        super("NoSlow", "Prevents you from getting slowed down.", Category.MOVEMENT, true, false, false);
        this.guiMove = (Setting<Boolean>)this.register(new Setting("GuiMove", (T)true));
        this.noSlow = (Setting<Boolean>)this.register(new Setting("NoSlow", (T)true));
        this.strict = (Setting<Boolean>)this.register(new Setting("Strict", (T)false));
        this.sneakPacket = (Setting<Boolean>)this.register(new Setting("SneakPacket", (T)false));
        this.webs = (Setting<Boolean>)this.register(new Setting("Webs", (T)false));
        this.webHorizontalFactor = (Setting<Double>)this.register(new Setting("WebHSpeed", (T)2.0, (T)0.0, (T)100.0));
        this.webVerticalFactor = (Setting<Double>)this.register(new Setting("WebVSpeed", (T)2.0, (T)0.0, (T)100.0));
        this.sneaking = false;
        this.setInstance();
    }
    
    private void setInstance() {
        NoSlow.INSTANCE = /*EL:49*/this;
    }
    
    public static NoSlow getInstance() {
        /*SL:53*/if (NoSlow.INSTANCE == null) {
            NoSlow.INSTANCE = /*EL:54*/new NoSlow();
        }
        /*SL:56*/return NoSlow.INSTANCE;
    }
    
    @Override
    public void onUpdate() {
        /*SL:61*/if (this.guiMove.getValue()) {
            /*SL:62*/if (NoSlow.mc.field_71462_r instanceof GuiOptions || NoSlow.mc.field_71462_r instanceof GuiVideoSettings || NoSlow.mc.field_71462_r instanceof GuiScreenOptionsSounds || NoSlow.mc.field_71462_r instanceof GuiContainer || NoSlow.mc.field_71462_r instanceof GuiIngameMenu) {
                /*SL:63*/for (final KeyBinding v1 : NoSlow.keys) {
                    /*SL:64*/KeyBinding.func_74510_a(v1.func_151463_i(), Keyboard.isKeyDown(v1.func_151463_i()));
                }
            }
            else/*SL:66*/ if (NoSlow.mc.field_71462_r == null) {
                /*SL:67*/for (final KeyBinding v1 : NoSlow.keys) {
                    /*SL:68*/if (!Keyboard.isKeyDown(v1.func_151463_i())) {
                        /*SL:69*/KeyBinding.func_74510_a(v1.func_151463_i(), false);
                    }
                }
            }
        }
        /*SL:73*/if (this.webs.getValue() && Legacy.moduleManager.<PacketFly>getModuleByClass(PacketFly.class).isDisabled() && Legacy.moduleManager.<PacketFly>getModuleByClass(PacketFly.class).isDisabled() && NoSlow.mc.field_71439_g.field_70134_J) {
            final EntityPlayerSP field_71439_g = NoSlow.mc.field_71439_g;
            /*SL:74*/field_71439_g.field_70159_w *= this.webHorizontalFactor.getValue();
            final EntityPlayerSP field_71439_g2 = NoSlow.mc.field_71439_g;
            /*SL:75*/field_71439_g2.field_70179_y *= this.webHorizontalFactor.getValue();
            final EntityPlayerSP field_71439_g3 = NoSlow.mc.field_71439_g;
            /*SL:76*/field_71439_g3.field_70181_x *= this.webVerticalFactor.getValue();
        }
        final Item func_77973_b = NoSlow.mc.field_71439_g.func_184607_cu().func_77973_b();
        /*SL:79*/if (this.sneaking && !NoSlow.mc.field_71439_g.func_184587_cr() && this.sneakPacket.getValue()) {
            NoSlow.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:80*/(Packet)new CPacketEntityAction((Entity)NoSlow.mc.field_71439_g, CPacketEntityAction.Action.STOP_SNEAKING));
            /*SL:81*/this.sneaking = false;
        }
    }
    
    @SubscribeEvent
    public void onUseItem(final PlayerInteractEvent.RightClickItem a1) {
        final Item v1 = NoSlow.mc.field_71439_g.func_184586_b(/*EL:87*/a1.getHand()).func_77973_b();
        /*SL:88*/if ((v1 instanceof ItemFood || v1 instanceof ItemBow || (v1 instanceof ItemPotion && this.sneakPacket.getValue())) && !this.sneaking) {
            NoSlow.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:89*/(Packet)new CPacketEntityAction((Entity)NoSlow.mc.field_71439_g, CPacketEntityAction.Action.START_SNEAKING));
            /*SL:90*/this.sneaking = true;
        }
    }
    
    @SubscribeEvent
    public void onInput(final InputUpdateEvent a1) {
        /*SL:96*/if (this.noSlow.getValue() && NoSlow.mc.field_71439_g.func_184587_cr() && !NoSlow.mc.field_71439_g.func_184218_aH()) {
            final MovementInput movementInput = /*EL:97*/a1.getMovementInput();
            movementInput.field_78902_a *= 5.0f;
            final MovementInput movementInput2 = /*EL:98*/a1.getMovementInput();
            movementInput2.field_192832_b *= 5.0f;
        }
    }
    
    @SubscribeEvent
    public void onKeyEvent(final KeyPressedEvent a1) {
        /*SL:104*/if (this.guiMove.getValue() && a1.getStage() == 0 && !(NoSlow.mc.field_71462_r instanceof GuiChat)) {
            /*SL:105*/a1.info = a1.pressed;
        }
    }
    
    @SubscribeEvent
    public void onPacket(final PacketEvent.Send a1) {
        /*SL:111*/if (a1.getPacket() instanceof CPacketPlayer && this.strict.getValue() && this.noSlow.getValue() && NoSlow.mc.field_71439_g.func_184587_cr() && !NoSlow.mc.field_71439_g.func_184218_aH()) {
            NoSlow.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:112*/(Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.ABORT_DESTROY_BLOCK, new BlockPos(Math.floor(NoSlow.mc.field_71439_g.field_70165_t), Math.floor(NoSlow.mc.field_71439_g.field_70163_u), Math.floor(NoSlow.mc.field_71439_g.field_70161_v)), EnumFacing.DOWN));
        }
    }
    
    static {
        NoSlow.INSTANCE = new NoSlow();
        NoSlow.keys = new KeyBinding[] { NoSlow.mc.field_71474_y.field_74351_w, NoSlow.mc.field_71474_y.field_74368_y, NoSlow.mc.field_71474_y.field_74370_x, NoSlow.mc.field_71474_y.field_74366_z, NoSlow.mc.field_71474_y.field_74314_A, NoSlow.mc.field_71474_y.field_151444_V };
    }
}
