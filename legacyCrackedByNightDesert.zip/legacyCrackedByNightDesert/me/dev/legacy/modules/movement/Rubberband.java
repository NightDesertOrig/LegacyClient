package me.dev.legacy.modules.movement;

import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import me.dev.legacy.api.util.Util;
import me.dev.legacy.api.AbstractModule;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class Rubberband extends Module
{
    private final Setting<RubbeMode> mode;
    private final Setting<Integer> Ym;
    
    public Rubberband() {
        super("Rubberband", "does rubberband", Category.MOVEMENT, true, false, false);
        this.mode = (Setting<RubbeMode>)this.register(new Setting("Mode", (T)RubbeMode.Motion));
        this.Ym = (Setting<Integer>)this.register(new Setting("Motion", (T)5, (T)1, (T)15, a1 -> this.mode.getValue() == RubbeMode.Motion));
    }
    
    @Override
    public void onEnable() {
        /*SL:23*/if (AbstractModule.fullNullCheck()) {
            /*SL:24*/return;
        }
    }
    
    @Override
    public void onUpdate() {
        /*SL:30*/switch (this.mode.getValue()) {
            case Motion: {
                Util.mc.field_71439_g.field_70181_x = /*EL:32*/this.Ym.getValue();
                /*SL:33*/break;
            }
            case Packet: {
                Rubberband.mc.func_147114_u().func_147297_a(/*EL:36*/(Packet)new CPacketPlayer.Position(Rubberband.mc.field_71439_g.field_70165_t, Rubberband.mc.field_71439_g.field_70163_u + this.Ym.getValue(), Rubberband.mc.field_71439_g.field_70161_v, true));
                /*SL:37*/break;
            }
            case Teleport: {
                Rubberband.mc.field_71439_g.func_70634_a(Rubberband.mc.field_71439_g.field_70165_t, Rubberband.mc.field_71439_g.field_70163_u + /*EL:40*/this.Ym.getValue(), Rubberband.mc.field_71439_g.field_70161_v);
                break;
            }
        }
        /*SL:44*/this.toggle();
    }
    
    public enum RubbeMode
    {
        Motion, 
        Teleport, 
        Packet;
    }
}
