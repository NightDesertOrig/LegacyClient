package me.dev.legacy.modules.movement;

import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.network.play.server.SPacketMoveVehicle;
import net.minecraft.block.Block;
import me.dev.legacy.api.event.events.misc.JesusEvent;
import net.minecraft.network.play.client.CPacketPlayer;
import me.dev.legacy.api.event.events.other.PacketEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import me.dev.legacy.api.util.EntityUtil;
import me.dev.legacy.modules.player.Freecam;
import me.dev.legacy.api.AbstractModule;
import me.dev.legacy.api.event.events.move.UpdateWalkingPlayerEvent;
import net.minecraft.util.math.AxisAlignedBB;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class Jesus extends Module
{
    public Setting<Mode> mode;
    public Setting<Boolean> cancelVehicle;
    public Setting<EventMode> eventMode;
    public Setting<Boolean> fall;
    public static AxisAlignedBB offset;
    private static Jesus INSTANCE;
    private boolean grounded;
    
    public Jesus() {
        super("Jesus", "Allows you to walk on water", Category.MOVEMENT, true, false, false);
        this.mode = (Setting<Mode>)this.register(new Setting("Mode", (T)Mode.NORMAL));
        this.cancelVehicle = (Setting<Boolean>)this.register(new Setting("NoVehicle", (T)false));
        this.eventMode = (Setting<EventMode>)this.register(new Setting("Jump", (T)EventMode.PRE, a1 -> this.mode.getValue() == Mode.TRAMPOLINE));
        this.fall = (Setting<Boolean>)this.register(new Setting("NoFall", (T)false, a1 -> this.mode.getValue() == Mode.TRAMPOLINE));
        this.grounded = false;
        Jesus.INSTANCE = this;
    }
    
    public static Jesus getInstance() {
        /*SL:32*/if (Jesus.INSTANCE == null) {
            Jesus.INSTANCE = /*EL:33*/new Jesus();
        }
        /*SL:35*/return Jesus.INSTANCE;
    }
    
    @SubscribeEvent
    public void updateWalkingPlayer(final UpdateWalkingPlayerEvent a1) {
        /*SL:40*/if (AbstractModule.fullNullCheck() || Freecam.getInstance().isOn()) {
            /*SL:41*/return;
        }
        /*SL:43*/if (a1.getStage() == 0 && (this.mode.getValue() == Mode.BOUNCE || this.mode.getValue() == Mode.VANILLA || this.mode.getValue() == Mode.NORMAL) && !Jesus.mc.field_71439_g.func_70093_af() && !Jesus.mc.field_71439_g.field_70145_X && !Jesus.mc.field_71474_y.field_74314_A.func_151470_d() && EntityUtil.isInLiquid()) {
            Jesus.mc.field_71439_g.field_70181_x = /*EL:44*/0.10000000149011612;
        }
        /*SL:46*/if (a1.getStage() == 0 && this.mode.getValue() == Mode.TRAMPOLINE && (this.eventMode.getValue() == EventMode.ALL || this.eventMode.getValue() == EventMode.PRE)) {
            /*SL:47*/this.doTrampoline();
        }
        else/*SL:48*/ if (a1.getStage() == 1 && this.mode.getValue() == Mode.TRAMPOLINE && (this.eventMode.getValue() == EventMode.ALL || this.eventMode.getValue() == EventMode.POST)) {
            /*SL:49*/this.doTrampoline();
        }
    }
    
    @SubscribeEvent
    public void sendPacket(final PacketEvent.Send v2) {
        /*SL:55*/if (v2.getPacket() instanceof CPacketPlayer && Freecam.getInstance().isOff() && (this.mode.getValue() == Mode.BOUNCE || this.mode.getValue() == Mode.NORMAL) && Jesus.mc.field_71439_g.func_184187_bx() == null && !Jesus.mc.field_71474_y.field_74314_A.func_151470_d()) {
            final CPacketPlayer a1 = /*EL:56*/(CPacketPlayer)v2.getPacket();
            /*SL:57*/if (!EntityUtil.isInLiquid() && EntityUtil.isOnLiquid(0.05000000074505806) && EntityUtil.checkCollide() && Jesus.mc.field_71439_g.field_70173_aa % 3 == 0) {
                final CPacketPlayer cPacketPlayer = /*EL:58*/a1;
                cPacketPlayer.field_149477_b -= 0.05000000074505806;
            }
        }
    }
    
    @SubscribeEvent
    public void onLiquidCollision(final JesusEvent a1) {
        /*SL:65*/if (AbstractModule.fullNullCheck() || Freecam.getInstance().isOn()) {
            /*SL:66*/return;
        }
        /*SL:68*/if (a1.getStage() == 0 && (this.mode.getValue() == Mode.BOUNCE || this.mode.getValue() == Mode.VANILLA || this.mode.getValue() == Mode.NORMAL) && Jesus.mc.field_71441_e != null && Jesus.mc.field_71439_g != null && EntityUtil.checkCollide() && Jesus.mc.field_71439_g.field_70181_x < 0.10000000149011612 && a1.getPos().func_177956_o() < Jesus.mc.field_71439_g.field_70163_u - 0.05000000074505806) {
            /*SL:69*/if (Jesus.mc.field_71439_g.func_184187_bx() != null) {
                /*SL:70*/a1.setBoundingBox(new AxisAlignedBB(0.0, 0.0, 0.0, 1.0, 0.949999988079071, 1.0));
            }
            else {
                /*SL:72*/a1.setBoundingBox(Block.field_185505_j);
            }
            /*SL:74*/a1.setCanceled(true);
        }
    }
    
    @SubscribeEvent
    public void onPacketReceived(final PacketEvent.Receive a1) {
        /*SL:80*/if (this.cancelVehicle.getValue() && a1.getPacket() instanceof SPacketMoveVehicle) {
            /*SL:81*/a1.setCanceled(true);
        }
    }
    
    @Override
    public String getDisplayInfo() {
        /*SL:87*/if (this.mode.getValue() == Mode.NORMAL) {
            /*SL:88*/return null;
        }
        /*SL:90*/return this.mode.currentEnumName();
    }
    
    private void doTrampoline() {
        /*SL:94*/if (Jesus.mc.field_71439_g.func_70093_af()) {
            /*SL:95*/return;
        }
        /*SL:97*/if (EntityUtil.isAboveLiquid((Entity)Jesus.mc.field_71439_g) && !Jesus.mc.field_71439_g.func_70093_af() && !Jesus.mc.field_71474_y.field_74314_A.field_74513_e) {
            Jesus.mc.field_71439_g.field_70181_x = /*EL:98*/0.1;
            /*SL:99*/return;
        }
        /*SL:101*/if (Jesus.mc.field_71439_g.field_70122_E || Jesus.mc.field_71439_g.func_70617_f_()) {
            /*SL:102*/this.grounded = false;
        }
        /*SL:104*/if (Jesus.mc.field_71439_g.field_70181_x > 0.0) {
            /*SL:105*/if (Jesus.mc.field_71439_g.field_70181_x < 0.03 && this.grounded) {
                final EntityPlayerSP field_71439_g = Jesus.mc.field_71439_g;
                /*SL:106*/field_71439_g.field_70181_x += 0.06713;
            }
            else/*SL:107*/ if (Jesus.mc.field_71439_g.field_70181_x <= 0.05 && this.grounded) {
                final EntityPlayerSP field_71439_g2 = Jesus.mc.field_71439_g;
                /*SL:108*/field_71439_g2.field_70181_x *= 1.20000000999;
                final EntityPlayerSP field_71439_g3 = Jesus.mc.field_71439_g;
                /*SL:109*/field_71439_g3.field_70181_x += 0.06;
            }
            else/*SL:110*/ if (Jesus.mc.field_71439_g.field_70181_x <= 0.08 && this.grounded) {
                final EntityPlayerSP field_71439_g4 = Jesus.mc.field_71439_g;
                /*SL:111*/field_71439_g4.field_70181_x *= 1.20000003;
                final EntityPlayerSP field_71439_g5 = Jesus.mc.field_71439_g;
                /*SL:112*/field_71439_g5.field_70181_x += 0.055;
            }
            else/*SL:113*/ if (Jesus.mc.field_71439_g.field_70181_x <= 0.112 && this.grounded) {
                final EntityPlayerSP field_71439_g6 = Jesus.mc.field_71439_g;
                /*SL:114*/field_71439_g6.field_70181_x += 0.0535;
            }
            else/*SL:115*/ if (this.grounded) {
                final EntityPlayerSP field_71439_g7 = Jesus.mc.field_71439_g;
                /*SL:116*/field_71439_g7.field_70181_x *= 1.000000000002;
                final EntityPlayerSP field_71439_g8 = Jesus.mc.field_71439_g;
                /*SL:117*/field_71439_g8.field_70181_x += 0.0517;
            }
        }
        /*SL:120*/if (this.grounded && Jesus.mc.field_71439_g.field_70181_x < 0.0 && Jesus.mc.field_71439_g.field_70181_x > -0.3) {
            final EntityPlayerSP field_71439_g9 = Jesus.mc.field_71439_g;
            /*SL:121*/field_71439_g9.field_70181_x += 0.045835;
        }
        /*SL:123*/if (!this.fall.getValue()) {
            Jesus.mc.field_71439_g.field_70143_R = /*EL:124*/0.0f;
        }
        /*SL:126*/if (!EntityUtil.checkForLiquid((Entity)Jesus.mc.field_71439_g, true)) {
            /*SL:127*/return;
        }
        /*SL:129*/if (EntityUtil.checkForLiquid((Entity)Jesus.mc.field_71439_g, true)) {
            Jesus.mc.field_71439_g.field_70181_x = /*EL:130*/0.5;
        }
        /*SL:132*/this.grounded = true;
    }
    
    static {
        Jesus.offset = new AxisAlignedBB(0.0, 0.0, 0.0, 1.0, 0.9999, 1.0);
        Jesus.INSTANCE = new Jesus();
    }
    
    public enum Mode
    {
        TRAMPOLINE, 
        BOUNCE, 
        VANILLA, 
        NORMAL;
    }
    
    public enum EventMode
    {
        PRE, 
        POST, 
        ALL;
    }
}
