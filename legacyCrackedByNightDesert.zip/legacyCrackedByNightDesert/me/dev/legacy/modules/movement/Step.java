package me.dev.legacy.modules.movement;

import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import me.dev.legacy.api.util.MotionUtil;
import net.minecraft.entity.Entity;
import me.dev.legacy.api.util.EntityUtil;
import java.text.DecimalFormat;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class Step extends Module
{
    Setting<Double> height;
    Setting<Boolean> timer;
    Setting<Boolean> reverse;
    public Setting<Boolean> vanilla;
    private int ticks;
    
    public Step() {
        super("Step", "Allows you to step up blocks", Category.MOVEMENT, true, false, false);
        this.height = (Setting<Double>)this.register(new Setting("Height", (T)2.5, (T)0.5, (T)2.5));
        this.timer = (Setting<Boolean>)this.register(new Setting("Timer", (T)false));
        this.reverse = (Setting<Boolean>)this.register(new Setting("Reverse", (T)false));
        this.vanilla = (Setting<Boolean>)this.register(new Setting("Vanilla", (T)false));
        this.ticks = 0;
    }
    
    @Override
    public void onUpdate() {
        /*SL:24*/if (Step.mc.field_71441_e == null || Step.mc.field_71439_g == null) {
            /*SL:25*/return;
        }
        /*SL:28*/if (Step.mc.field_71439_g.func_70090_H() || Step.mc.field_71439_g.func_180799_ab() || Step.mc.field_71439_g.func_70617_f_() || Step.mc.field_71474_y.field_74314_A.func_151470_d()) {
            /*SL:29*/return;
        }
        /*SL:31*/if (this.vanilla.getValue()) {
            final DecimalFormat v1 = /*EL:32*/new DecimalFormat("#");
            Step.mc.field_71439_g.field_70138_W = /*EL:33*/Float.parseFloat(v1.format(this.height.getValue()));
        }
        else/*SL:35*/ if (this.timer.getValue()) {
            /*SL:36*/if (this.ticks == 0) {
                /*SL:37*/EntityUtil.resetTimer();
            }
            else {
                /*SL:39*/--this.ticks;
            }
        }
        /*SL:43*/if (Step.mc.field_71439_g != null && Step.mc.field_71439_g.field_70122_E && !Step.mc.field_71439_g.func_70090_H() && !Step.mc.field_71439_g.func_70617_f_() && this.reverse.getValue()) {
            /*SL:44*/for (double v2 = 0.0; v2 < this.height.getValue() + 0.5; v2 += 0.01) {
                /*SL:45*/if (!Step.mc.field_71441_e.func_184144_a((Entity)Step.mc.field_71439_g, Step.mc.field_71439_g.func_174813_aQ().func_72317_d(0.0, -v2, 0.0)).isEmpty()) {
                    Step.mc.field_71439_g.field_70181_x = /*EL:46*/-10.0;
                    /*SL:47*/break;
                }
            }
        }
        final double[] v3 = /*EL:51*/MotionUtil.forward(0.1);
        boolean v4 = /*EL:52*/false;
        boolean v5 = /*EL:53*/false;
        boolean v6 = /*EL:54*/false;
        boolean v7 = /*EL:55*/false;
        /*SL:56*/if (Step.mc.field_71441_e.func_184144_a((Entity)Step.mc.field_71439_g, Step.mc.field_71439_g.func_174813_aQ().func_72317_d(v3[0], 2.6, v3[1])).isEmpty() && !Step.mc.field_71441_e.func_184144_a((Entity)Step.mc.field_71439_g, Step.mc.field_71439_g.func_174813_aQ().func_72317_d(v3[0], 2.4, v3[1])).isEmpty()) {
            /*SL:57*/v4 = true;
        }
        /*SL:59*/if (Step.mc.field_71441_e.func_184144_a((Entity)Step.mc.field_71439_g, Step.mc.field_71439_g.func_174813_aQ().func_72317_d(v3[0], 2.1, v3[1])).isEmpty() && !Step.mc.field_71441_e.func_184144_a((Entity)Step.mc.field_71439_g, Step.mc.field_71439_g.func_174813_aQ().func_72317_d(v3[0], 1.9, v3[1])).isEmpty()) {
            /*SL:60*/v5 = true;
        }
        /*SL:62*/if (Step.mc.field_71441_e.func_184144_a((Entity)Step.mc.field_71439_g, Step.mc.field_71439_g.func_174813_aQ().func_72317_d(v3[0], 1.6, v3[1])).isEmpty() && !Step.mc.field_71441_e.func_184144_a((Entity)Step.mc.field_71439_g, Step.mc.field_71439_g.func_174813_aQ().func_72317_d(v3[0], 1.4, v3[1])).isEmpty()) {
            /*SL:63*/v6 = true;
        }
        /*SL:65*/if (Step.mc.field_71441_e.func_184144_a((Entity)Step.mc.field_71439_g, Step.mc.field_71439_g.func_174813_aQ().func_72317_d(v3[0], 1.0, v3[1])).isEmpty() && !Step.mc.field_71441_e.func_184144_a((Entity)Step.mc.field_71439_g, Step.mc.field_71439_g.func_174813_aQ().func_72317_d(v3[0], 0.6, v3[1])).isEmpty()) {
            /*SL:66*/v7 = true;
        }
        /*SL:68*/if (Step.mc.field_71439_g.field_70123_F && (Step.mc.field_71439_g.field_191988_bg != 0.0f || Step.mc.field_71439_g.field_70702_br != 0.0f) && Step.mc.field_71439_g.field_70122_E) {
            /*SL:69*/if (v7 && this.height.getValue() >= 1.0) {
                final double[] v8 = /*EL:70*/{ 0.42, 0.753 };
                /*SL:71*/for (int v9 = 0; v9 < v8.length; ++v9) {
                    Step.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:72*/(Packet)new CPacketPlayer.Position(Step.mc.field_71439_g.field_70165_t, Step.mc.field_71439_g.field_70163_u + v8[v9], Step.mc.field_71439_g.field_70161_v, Step.mc.field_71439_g.field_70122_E));
                }
                /*SL:74*/if (this.timer.getValue()) {
                    /*SL:75*/EntityUtil.setTimer(0.6f);
                }
                Step.mc.field_71439_g.func_70107_b(Step.mc.field_71439_g.field_70165_t, Step.mc.field_71439_g.field_70163_u + /*EL:77*/1.0, Step.mc.field_71439_g.field_70161_v);
                /*SL:78*/this.ticks = 1;
            }
            /*SL:80*/if (v6 && this.height.getValue() >= 1.5) {
                final double[] v8 = /*EL:81*/{ 0.42, 0.75, 1.0, 1.16, 1.23, 1.2 };
                /*SL:82*/for (int v9 = 0; v9 < v8.length; ++v9) {
                    Step.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:83*/(Packet)new CPacketPlayer.Position(Step.mc.field_71439_g.field_70165_t, Step.mc.field_71439_g.field_70163_u + v8[v9], Step.mc.field_71439_g.field_70161_v, Step.mc.field_71439_g.field_70122_E));
                }
                /*SL:85*/if (this.timer.getValue()) {
                    /*SL:86*/EntityUtil.setTimer(0.35f);
                }
                Step.mc.field_71439_g.func_70107_b(Step.mc.field_71439_g.field_70165_t, Step.mc.field_71439_g.field_70163_u + /*EL:88*/1.5, Step.mc.field_71439_g.field_70161_v);
                /*SL:89*/this.ticks = 1;
            }
            /*SL:91*/if (v5 && this.height.getValue() >= 2.0) {
                final double[] v8 = /*EL:92*/{ 0.42, 0.78, 0.63, 0.51, 0.9, 1.21, 1.45, 1.43 };
                /*SL:93*/for (int v9 = 0; v9 < v8.length; ++v9) {
                    Step.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:94*/(Packet)new CPacketPlayer.Position(Step.mc.field_71439_g.field_70165_t, Step.mc.field_71439_g.field_70163_u + v8[v9], Step.mc.field_71439_g.field_70161_v, Step.mc.field_71439_g.field_70122_E));
                }
                /*SL:96*/if (this.timer.getValue()) {
                    /*SL:97*/EntityUtil.setTimer(0.25f);
                }
                Step.mc.field_71439_g.func_70107_b(Step.mc.field_71439_g.field_70165_t, Step.mc.field_71439_g.field_70163_u + /*EL:99*/2.0, Step.mc.field_71439_g.field_70161_v);
                /*SL:100*/this.ticks = 2;
            }
            /*SL:102*/if (v4 && this.height.getValue() >= 2.5) {
                final double[] v8 = /*EL:103*/{ 0.425, 0.821, 0.699, 0.599, 1.022, 1.372, 1.652, 1.869, 2.019, 1.907 };
                /*SL:104*/for (int v9 = 0; v9 < v8.length; ++v9) {
                    Step.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:105*/(Packet)new CPacketPlayer.Position(Step.mc.field_71439_g.field_70165_t, Step.mc.field_71439_g.field_70163_u + v8[v9], Step.mc.field_71439_g.field_70161_v, Step.mc.field_71439_g.field_70122_E));
                }
                /*SL:107*/if (this.timer.getValue()) {
                    /*SL:108*/EntityUtil.setTimer(0.15f);
                }
                Step.mc.field_71439_g.func_70107_b(Step.mc.field_71439_g.field_70165_t, Step.mc.field_71439_g.field_70163_u + /*EL:110*/2.5, Step.mc.field_71439_g.field_70161_v);
                /*SL:111*/this.ticks = 2;
            }
        }
    }
    
    @Override
    public void onDisable() {
        Step.mc.field_71439_g.field_70138_W = /*EL:117*/0.6f;
    }
}
