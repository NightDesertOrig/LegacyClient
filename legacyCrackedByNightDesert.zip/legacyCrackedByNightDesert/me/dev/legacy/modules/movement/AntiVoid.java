package me.dev.legacy.modules.movement;

import me.dev.legacy.impl.command.Command;
import com.mojang.realmsclient.gui.ChatFormatting;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class AntiVoid extends Module
{
    public Setting<Mode> mode;
    public Setting<Boolean> display;
    
    public AntiVoid() {
        super("AntiVoid", "Glitches you up from void.", Category.MOVEMENT, false, false, false);
        this.mode = (Setting<Mode>)this.register(new Setting("Mode", (T)Mode.BOUNCE));
        this.display = (Setting<Boolean>)this.register(new Setting("Display", (T)true));
    }
    
    @Override
    public void onUpdate() {
        final double v1 = AntiVoid.mc.field_71439_g.field_70163_u;
        /*SL:19*/if (v1 <= 0.5) {
            /*SL:20*/Command.sendMessage(ChatFormatting.RED + "Player " + ChatFormatting.GREEN + AntiVoid.mc.field_71439_g.func_70005_c_() + ChatFormatting.RED + " is in the void!");
            /*SL:21*/if (this.mode.getValue().equals(Mode.BOUNCE)) {
                AntiVoid.mc.field_71439_g.field_70701_bs = /*EL:22*/10.0f;
                AntiVoid.mc.field_71439_g.func_70664_aZ();
            }
            /*SL:25*/if (this.mode.getValue().equals(Mode.LAUNCH)) {
                AntiVoid.mc.field_71439_g.field_70701_bs = /*EL:26*/100.0f;
                AntiVoid.mc.field_71439_g.func_70664_aZ();
            }
        }
        else {
            AntiVoid.mc.field_71439_g.field_70701_bs = /*EL:30*/0.0f;
        }
    }
    
    @Override
    public void onDisable() {
        AntiVoid.mc.field_71439_g.field_70701_bs = /*EL:36*/0.0f;
    }
    
    @Override
    public String getDisplayInfo() {
        /*SL:41*/if (this.display.getValue()) {
            /*SL:42*/if (this.mode.getValue().equals(Mode.BOUNCE)) {
                /*SL:43*/return "Bounce";
            }
            /*SL:45*/if (this.mode.getValue().equals(Mode.LAUNCH)) {
                /*SL:46*/return "Launch";
            }
        }
        /*SL:49*/return null;
    }
    
    public enum Mode
    {
        BOUNCE, 
        LAUNCH;
    }
}
