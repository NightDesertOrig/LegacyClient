package me.dev.legacy.modules.movement;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.client.entity.EntityPlayerSP;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class ReverseStep extends Module
{
    private final Setting<Float> speed;
    
    public ReverseStep() {
        super("ReverseStep", "Reverse step", Category.MOVEMENT, false, false, false);
        this.speed = (Setting<Float>)this.register(new Setting("Speed", (T)0.0f, (T)0.0f, (T)20.0f));
    }
    
    @SubscribeEvent
    @Override
    public void onUpdate() {
        /*SL:16*/if (ReverseStep.mc.field_71439_g == null || ReverseStep.mc.field_71441_e == null || ReverseStep.mc.field_71439_g.func_70090_H() || ReverseStep.mc.field_71439_g.func_180799_ab()) {
            /*SL:17*/return;
        }
        /*SL:19*/if (ReverseStep.mc.field_71439_g.field_70122_E) {
            final EntityPlayerSP field_71439_g = ReverseStep.mc.field_71439_g;
            /*SL:20*/field_71439_g.field_70181_x -= this.speed.getValue() / 10.0f;
        }
    }
}
