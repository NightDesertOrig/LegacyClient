package me.dev.legacy.modules.client;

import net.minecraft.client.gui.GuiScreen;
import me.dev.legacy.impl.gui.LegacyGui;
import java.awt.Color;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import me.dev.legacy.impl.command.Command;
import com.mojang.realmsclient.gui.ChatFormatting;
import me.dev.legacy.Legacy;
import me.dev.legacy.api.event.ClientEvent;
import net.minecraft.client.settings.GameSettings;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class ClickGui extends Module
{
    private static ClickGui INSTANCE;
    public Setting<String> prefix;
    public Setting<Boolean> customFov;
    public Setting<Float> fov;
    public Setting<Boolean> gears;
    public Setting<Integer> red;
    public Setting<Integer> green;
    public Setting<Integer> blue;
    public Setting<Integer> hoverAlpha;
    public Setting<Integer> alpha;
    public Setting<Boolean> rainbow;
    public Setting<rainbowMode> rainbowModeHud;
    public Setting<rainbowModeArray> rainbowModeA;
    public Setting<Integer> rainbowHue;
    public Setting<Float> rainbowBrightness;
    public Setting<Float> rainbowSaturation;
    public Setting<Integer> startcolorred;
    public Setting<Integer> startcolorgreen;
    public Setting<Integer> startcolorblue;
    public Setting<Integer> endcolorred;
    public Setting<Integer> endcolorgreen;
    public Setting<Integer> endcolorblue;
    public Setting<Integer> fontcolorr;
    public Setting<Integer> fontcolorg;
    public Setting<Integer> fontcolorb;
    public Setting<Boolean> outline;
    public Setting<Integer> testcolorr;
    public Setting<Integer> testcolorgreen;
    public Setting<Integer> testcolorblue;
    public float hue;
    
    public ClickGui() {
        super("ClickGui", "Opens the ClickGui", Category.CLIENT, true, false, false);
        this.prefix = (Setting<String>)this.register(new Setting("Prefix", (T)"."));
        this.customFov = (Setting<Boolean>)this.register(new Setting("CustomFov", (T)false));
        this.fov = (Setting<Float>)this.register(new Setting("Fov", (T)150.0f, (T)(-180.0f), (T)180.0f));
        this.gears = (Setting<Boolean>)this.register(new Setting("Gears", (T)false, "draws gears"));
        this.red = (Setting<Integer>)this.register(new Setting("Red", (T)210, (T)0, (T)255));
        this.green = (Setting<Integer>)this.register(new Setting("Green", (T)130, (T)0, (T)255));
        this.blue = (Setting<Integer>)this.register(new Setting("Blue", (T)255, (T)0, (T)255));
        this.hoverAlpha = (Setting<Integer>)this.register(new Setting("Alpha", (T)180, (T)0, (T)255));
        this.alpha = (Setting<Integer>)this.register(new Setting("HoverAlpha", (T)240, (T)0, (T)255));
        this.rainbow = (Setting<Boolean>)this.register(new Setting("Rainbow", (T)false));
        this.rainbowModeHud = (Setting<rainbowMode>)this.register(new Setting("HRainbowMode", (T)rainbowMode.Static, a1 -> this.rainbow.getValue()));
        this.rainbowModeA = (Setting<rainbowModeArray>)this.register(new Setting("ARainbowMode", (T)rainbowModeArray.Static, a1 -> this.rainbow.getValue()));
        this.rainbowHue = (Setting<Integer>)this.register(new Setting("Delay", (T)240, (T)0, (T)600, a1 -> this.rainbow.getValue()));
        this.rainbowBrightness = (Setting<Float>)this.register(new Setting("Brightness ", (T)150.0f, (T)1.0f, (T)255.0f, a1 -> this.rainbow.getValue()));
        this.rainbowSaturation = (Setting<Float>)this.register(new Setting("Saturation", (T)150.0f, (T)1.0f, (T)255.0f, a1 -> this.rainbow.getValue()));
        this.startcolorred = (Setting<Integer>)this.register(new Setting("StartRed", (T)210, (T)0, (T)255));
        this.startcolorgreen = (Setting<Integer>)this.register(new Setting("StartGreen", (T)210, (T)0, (T)255));
        this.startcolorblue = (Setting<Integer>)this.register(new Setting("StartBlue", (T)210, (T)0, (T)255));
        this.endcolorred = (Setting<Integer>)this.register(new Setting("EndRed", (T)210, (T)0, (T)255));
        this.endcolorgreen = (Setting<Integer>)this.register(new Setting("EndGreen", (T)210, (T)0, (T)255));
        this.endcolorblue = (Setting<Integer>)this.register(new Setting("EndBlue", (T)210, (T)0, (T)255));
        this.fontcolorr = (Setting<Integer>)this.register(new Setting("FontRed", (T)210, (T)0, (T)255));
        this.fontcolorg = (Setting<Integer>)this.register(new Setting("FontGreen", (T)210, (T)0, (T)255));
        this.fontcolorb = (Setting<Integer>)this.register(new Setting("FontBlue", (T)210, (T)0, (T)255));
        this.outline = (Setting<Boolean>)this.register(new Setting("Outline", (T)false));
        this.testcolorr = (Setting<Integer>)this.register(new Setting("PanelRed", (T)210, (T)0, (T)255));
        this.testcolorgreen = (Setting<Integer>)this.register(new Setting("PanelGreen", (T)210, (T)0, (T)255));
        this.testcolorblue = (Setting<Integer>)this.register(new Setting("PanelBlue", (T)210, (T)0, (T)255));
        this.setInstance();
    }
    
    public static ClickGui getInstance() {
        /*SL:57*/if (ClickGui.INSTANCE == null) {
            ClickGui.INSTANCE = /*EL:58*/new ClickGui();
        }
        /*SL:60*/return ClickGui.INSTANCE;
    }
    
    private void setInstance() {
        ClickGui.INSTANCE = /*EL:64*/this;
    }
    
    @Override
    public void onUpdate() {
        /*SL:69*/if (this.customFov.getValue()) {
            ClickGui.mc.field_71474_y.func_74304_a(GameSettings.Options.FOV, /*EL:70*/(float)this.fov.getValue());
        }
    }
    
    @SubscribeEvent
    public void onSettingChange(final ClientEvent a1) {
        /*SL:75*/if (a1.getStage() == 2 && a1.getSetting().getFeature().equals(this)) {
            /*SL:76*/if (a1.getSetting().equals(this.prefix)) {
                Legacy.commandManager.setPrefix(/*EL:77*/this.prefix.getPlannedValue());
                /*SL:78*/Command.sendMessage("Prefix set to " + ChatFormatting.DARK_GRAY + Legacy.commandManager.getPrefix());
            }
            Legacy.colorManager.setColor(/*EL:80*/this.red.getPlannedValue(), this.green.getPlannedValue(), this.blue.getPlannedValue(), this.hoverAlpha.getPlannedValue());
        }
    }
    
    public Color getCurrentColor() {
        /*SL:85*/if (this.rainbow.getValue()) {
            /*SL:86*/return Color.getHSBColor(this.hue, (int)(Object)this.rainbowSaturation.getValue() / 255.0f, (int)(Object)this.rainbowBrightness.getValue() / 255.0f);
        }
        /*SL:88*/return new Color(this.red.getValue(), this.green.getValue(), this.blue.getValue(), this.alpha.getValue());
    }
    
    @Override
    public void onEnable() {
        ClickGui.mc.func_147108_a(/*EL:93*/(GuiScreen)LegacyGui.getClickGui());
    }
    
    @Override
    public void onLoad() {
        Legacy.colorManager.setColor(/*EL:98*/this.red.getValue(), this.green.getValue(), this.blue.getValue(), this.hoverAlpha.getValue());
        Legacy.commandManager.setPrefix(/*EL:99*/this.prefix.getValue());
    }
    
    @Override
    public void onTick() {
        /*SL:104*/if (!(ClickGui.mc.field_71462_r instanceof LegacyGui)) {
            /*SL:105*/this.disable();
        }
    }
    
    static {
        ClickGui.INSTANCE = new ClickGui();
    }
    
    public enum rainbowModeArray
    {
        Static, 
        Up;
    }
    
    public enum rainbowMode
    {
        Static, 
        Sideway;
    }
}
