package me.dev.legacy.modules.client;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import me.dev.legacy.api.event.ClientEvent;
import net.minecraft.client.renderer.GlStateManager;
import java.util.function.ToIntFunction;
import net.minecraft.init.Items;
import me.dev.legacy.api.util.EntityUtil;
import java.util.Iterator;
import java.util.List;
import java.util.Date;
import java.text.SimpleDateFormat;
import me.dev.legacy.api.util.RenderUtil;
import me.dev.legacy.api.util.RainbowUtil;
import java.util.Collection;
import net.minecraft.potion.PotionEffect;
import java.util.ArrayList;
import net.minecraft.client.Minecraft;
import com.mojang.realmsclient.gui.ChatFormatting;
import me.dev.legacy.Legacy;
import net.minecraft.client.gui.GuiChat;
import me.dev.legacy.api.util.ColorUtil;
import me.dev.legacy.api.AbstractModule;
import me.dev.legacy.api.event.events.render.Render2DEvent;
import java.util.HashMap;
import me.dev.legacy.api.util.TextUtil;
import java.util.Map;
import me.dev.legacy.api.util.Timer;
import me.dev.legacy.impl.setting.Setting;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import me.dev.legacy.modules.Module;

public class HUD extends Module
{
    private static final ResourceLocation box;
    private static final ItemStack totem;
    private static RenderItem itemRender;
    private static HUD INSTANCE;
    private final Setting<Boolean> grayNess;
    private final Setting<Boolean> renderingUp;
    private final Setting<Boolean> waterMark;
    public Setting<Integer> waterMarkY;
    private final Setting<Boolean> arrayList;
    private final Setting<Boolean> coords;
    private final Setting<Boolean> direction;
    private final Setting<Boolean> armor;
    private final Setting<Boolean> totems;
    private final Setting<Boolean> greeter;
    private final Setting<Boolean> speed;
    private final Setting<Boolean> potions;
    private final Setting<Boolean> ping;
    private final Setting<Boolean> line;
    public Setting<Integer> lineoffset;
    private final Setting<Boolean> tps;
    private final Setting<Boolean> fps;
    private final Timer timer;
    private final Map<String, Integer> players;
    public Setting<String> command;
    public Setting<String> commandBracket;
    public Setting<String> commandBracket2;
    public Setting<TextUtil.Color> bracketColor;
    public Setting<TextUtil.Color> commandColor;
    public Setting<Boolean> notifyToggles;
    public Setting<Integer> animationHorizontalTime;
    public Setting<Integer> animationVerticalTime;
    public Setting<RenderingMode> renderingMode;
    public Setting<Boolean> time;
    private int color;
    public float hue;
    private boolean shouldIncrement;
    private int hitMarkerTimer;
    
    public HUD() {
        super("HUD", "HUD Elements rendered on your screen", Category.CLIENT, true, false, false);
        this.grayNess = (Setting<Boolean>)this.register(new Setting("Gray", (T)false));
        this.renderingUp = (Setting<Boolean>)this.register(new Setting("RenderingUp", (T)false, "Orientation of the HUD-Elements."));
        this.waterMark = (Setting<Boolean>)this.register(new Setting("Watermark", (T)false, "displays watermark"));
        this.waterMarkY = (Setting<Integer>)this.register(new Setting("WatermarkPosY", (T)2, (T)0, (T)100, a1 -> this.waterMark.getValue()));
        this.arrayList = (Setting<Boolean>)this.register(new Setting("ActiveModules", (T)false, "Lists the active modules."));
        this.coords = (Setting<Boolean>)this.register(new Setting("Coords", (T)false, "Your current coordinates"));
        this.direction = (Setting<Boolean>)this.register(new Setting("Direction", (T)false, "The Direction you are facing."));
        this.armor = (Setting<Boolean>)this.register(new Setting("Armor", (T)false, "ArmorHUD"));
        this.totems = (Setting<Boolean>)this.register(new Setting("Totems", (T)false, "TotemHUD"));
        this.greeter = (Setting<Boolean>)this.register(new Setting("Welcomer", (T)false, "The time"));
        this.speed = (Setting<Boolean>)this.register(new Setting("Speed", (T)false, "Your Speed"));
        this.potions = (Setting<Boolean>)this.register(new Setting("Potions", (T)false, "Your Speed"));
        this.ping = (Setting<Boolean>)this.register(new Setting("Ping", (T)false, "Your response time to the server."));
        this.line = (Setting<Boolean>)this.register(new Setting("RainbowBar", (T)false, "Cs moode."));
        this.lineoffset = (Setting<Integer>)this.register(new Setting("Offset", (T)1000, (T)0, (T)1000, a1 -> this.line.getValue()));
        this.tps = (Setting<Boolean>)this.register(new Setting("TPS", (T)false, "Ticks per second of the server."));
        this.fps = (Setting<Boolean>)this.register(new Setting("FPS", (T)false, "Your frames per second."));
        this.timer = new Timer();
        this.players = new HashMap<String, Integer>();
        this.command = (Setting<String>)this.register(new Setting("Prefix", (T)"legacy"));
        this.commandBracket = (Setting<String>)this.register(new Setting("Bracket", (T)"["));
        this.commandBracket2 = (Setting<String>)this.register(new Setting("Bracket2", (T)"]"));
        this.bracketColor = (Setting<TextUtil.Color>)this.register(new Setting("BracketColor", (T)TextUtil.Color.WHITE));
        this.commandColor = (Setting<TextUtil.Color>)this.register(new Setting("NameColor", (T)TextUtil.Color.LIGHT_PURPLE));
        this.notifyToggles = (Setting<Boolean>)this.register(new Setting("ChatNotify", (T)false, "notifys in chat"));
        this.animationHorizontalTime = (Setting<Integer>)this.register(new Setting("AnimationHTime", (T)500, (T)1, (T)1000, a1 -> this.arrayList.getValue()));
        this.animationVerticalTime = (Setting<Integer>)this.register(new Setting("AnimationVTime", (T)50, (T)1, (T)500, a1 -> this.arrayList.getValue()));
        this.renderingMode = (Setting<RenderingMode>)this.register(new Setting("Ordering", (T)RenderingMode.Length));
        this.time = (Setting<Boolean>)this.register(new Setting("Time", (T)false, "The time"));
        this.setInstance();
    }
    
    public static HUD getInstance() {
        /*SL:72*/if (HUD.INSTANCE == null) {
            HUD.INSTANCE = /*EL:73*/new HUD();
        }
        /*SL:74*/return HUD.INSTANCE;
    }
    
    private void setInstance() {
        HUD.INSTANCE = /*EL:78*/this;
    }
    
    @Override
    public void onUpdate() {
        /*SL:82*/if (this.shouldIncrement) {
            /*SL:83*/++this.hitMarkerTimer;
        }
        /*SL:84*/if (this.hitMarkerTimer == 10) {
            /*SL:85*/this.hitMarkerTimer = 0;
            /*SL:86*/this.shouldIncrement = false;
        }
    }
    
    @Override
    public void onRender2D(final Render2DEvent v-3) {
        /*SL:91*/if (AbstractModule.fullNullCheck()) {
            /*SL:92*/return;
        }
        final int scaledWidth = /*EL:93*/this.renderer.scaledWidth;
        final int scaledHeight = /*EL:94*/this.renderer.scaledHeight;
        /*SL:95*/this.color = ColorUtil.toRGBA(ClickGui.getInstance().red.getValue(), ClickGui.getInstance().green.getValue(), ClickGui.getInstance().blue.getValue());
        /*SL:96*/if (this.waterMark.getValue()) {
            final String v0 = /*EL:97*/"legacy v1.2.5";
            /*SL:98*/if (ClickGui.getInstance().rainbow.getValue()) {
                /*SL:99*/if (ClickGui.getInstance().rainbowModeHud.getValue() == ClickGui.rainbowMode.Static) {
                    /*SL:100*/this.renderer.drawString(v0, 2.0f, this.waterMarkY.getValue(), ColorUtil.rainbow(ClickGui.getInstance().rainbowHue.getValue()).getRGB(), true);
                }
                else {
                    final int[] v = /*EL:102*/{ 1 };
                    final char[] v2 = /*EL:103*/v0.toCharArray();
                    float v3 = /*EL:104*/0.0f;
                    /*SL:105*/for (final char a1 : v2) {
                        /*SL:106*/this.renderer.drawString(String.valueOf(a1), 2.0f + v3, this.waterMarkY.getValue(), ColorUtil.rainbow(v[0] * ClickGui.getInstance().rainbowHue.getValue()).getRGB(), true);
                        /*SL:107*/v3 += this.renderer.getStringWidth(String.valueOf(a1));
                        /*SL:108*/++v[0];
                    }
                }
            }
            else {
                /*SL:112*/this.renderer.drawString(v0, 2.0f, this.waterMarkY.getValue(), this.color, true);
            }
        }
        final int[] v4 = /*EL:116*/{ 1 };
        int v5 = /*EL:117*/(HUD.mc.field_71462_r instanceof GuiChat && !this.renderingUp.getValue()) ? 14 : 0;
        /*SL:118*/if (this.arrayList.getValue()) {
            /*SL:119*/if (this.renderingUp.getValue()) {
                /*SL:120*/if (this.renderingMode.getValue() == RenderingMode.ABC) {
                    /*SL:121*/for (int v6 = 0; v6 < Legacy.moduleManager.sortedModulesABC.size(); ++v6) {
                        final String v7 = Legacy.moduleManager.sortedModulesABC.get(/*EL:122*/v6);
                        /*SL:123*/this.renderer.drawString(v7, scaledWidth - 2 - this.renderer.getStringWidth(v7), 2 + v5 * 10, ((boolean)ClickGui.getInstance().rainbow.getValue()) ? ((ClickGui.getInstance().rainbowModeA.getValue() == ClickGui.rainbowModeArray.Up) ? ColorUtil.rainbow(v4[0] * ClickGui.getInstance().rainbowHue.getValue()).getRGB() : ColorUtil.rainbow(ClickGui.getInstance().rainbowHue.getValue()).getRGB()) : this.color, true);
                        /*SL:124*/++v5;
                        /*SL:125*/++v4[0];
                    }
                }
                else {
                    /*SL:128*/for (int v6 = 0; v6 < Legacy.moduleManager.sortedModules.size(); ++v6) {
                        final Module v8 = Legacy.moduleManager.sortedModules.get(/*EL:129*/v6);
                        final String v9 = /*EL:130*/v8.getDisplayName() + ChatFormatting.GRAY + ((v8.getDisplayInfo() != null) ? (" [" + ChatFormatting.WHITE + v8.getDisplayInfo() + ChatFormatting.GRAY + "]") : "");
                        /*SL:131*/this.renderer.drawString(v9, scaledWidth - 2 - this.renderer.getStringWidth(v9), 2 + v5 * 10, ((boolean)ClickGui.getInstance().rainbow.getValue()) ? ((ClickGui.getInstance().rainbowModeA.getValue() == ClickGui.rainbowModeArray.Up) ? ColorUtil.rainbow(v4[0] * ClickGui.getInstance().rainbowHue.getValue()).getRGB() : ColorUtil.rainbow(ClickGui.getInstance().rainbowHue.getValue()).getRGB()) : this.color, true);
                        /*SL:132*/++v5;
                        /*SL:133*/++v4[0];
                    }
                }
            }
            else/*SL:136*/ if (this.renderingMode.getValue() == RenderingMode.ABC) {
                /*SL:137*/for (int v6 = 0; v6 < Legacy.moduleManager.sortedModulesABC.size(); ++v6) {
                    final String v7 = Legacy.moduleManager.sortedModulesABC.get(/*EL:138*/v6);
                    /*SL:139*/v5 += 10;
                    /*SL:140*/this.renderer.drawString(v7, scaledWidth - 2 - this.renderer.getStringWidth(v7), scaledHeight - v5, ((boolean)ClickGui.getInstance().rainbow.getValue()) ? ((ClickGui.getInstance().rainbowModeA.getValue() == ClickGui.rainbowModeArray.Up) ? ColorUtil.rainbow(v4[0] * ClickGui.getInstance().rainbowHue.getValue()).getRGB() : ColorUtil.rainbow(ClickGui.getInstance().rainbowHue.getValue()).getRGB()) : this.color, true);
                    /*SL:141*/++v4[0];
                }
            }
            else {
                /*SL:144*/for (int v6 = 0; v6 < Legacy.moduleManager.sortedModules.size(); ++v6) {
                    final Module v8 = Legacy.moduleManager.sortedModules.get(/*EL:145*/v6);
                    final String v9 = /*EL:146*/v8.getDisplayName() + ChatFormatting.GRAY + ((v8.getDisplayInfo() != null) ? (" [" + ChatFormatting.WHITE + v8.getDisplayInfo() + ChatFormatting.GRAY + "]") : "");
                    /*SL:147*/v5 += 10;
                    /*SL:148*/this.renderer.drawString(v9, scaledWidth - 2 - this.renderer.getStringWidth(v9), scaledHeight - v5, ((boolean)ClickGui.getInstance().rainbow.getValue()) ? ((ClickGui.getInstance().rainbowModeA.getValue() == ClickGui.rainbowModeArray.Up) ? ColorUtil.rainbow(v4[0] * ClickGui.getInstance().rainbowHue.getValue()).getRGB() : ColorUtil.rainbow(ClickGui.getInstance().rainbowHue.getValue()).getRGB()) : this.color, true);
                    /*SL:149*/++v4[0];
                }
            }
        }
        final String v10 = /*EL:152*/this.grayNess.getValue() ? String.valueOf(ChatFormatting.GRAY) : "";
        int v11 = /*EL:153*/(HUD.mc.field_71462_r instanceof GuiChat && this.renderingUp.getValue()) ? 13 : (this.renderingUp.getValue() ? -2 : 0);
        /*SL:154*/if (this.renderingUp.getValue()) {
            /*SL:155*/if (this.potions.getValue()) {
                final List<PotionEffect> v12 = /*EL:156*/new ArrayList<PotionEffect>(Minecraft.func_71410_x().field_71439_g.func_70651_bq());
                /*SL:157*/for (final PotionEffect v13 : v12) {
                    final String v14 = Legacy.potionManager.getColoredPotionString(/*EL:158*/v13);
                    /*SL:159*/v11 += 10;
                    /*SL:160*/this.renderer.drawString(v14, scaledWidth - this.renderer.getStringWidth(v14) - 2, scaledHeight - 2 - v11, v13.func_188419_a().func_76401_j(), true);
                }
            }
            /*SL:163*/if (this.speed.getValue()) {
                final String v9 = /*EL:164*/v10 + "Speed " + ChatFormatting.WHITE + Legacy.speedManager.getSpeedKpH() + " km/h";
                /*SL:165*/v11 += 10;
                /*SL:166*/this.renderer.drawString(v9, scaledWidth - this.renderer.getStringWidth(v9) - 2, scaledHeight - 2 - v11, ((boolean)ClickGui.getInstance().rainbow.getValue()) ? ((ClickGui.getInstance().rainbowModeA.getValue() == ClickGui.rainbowModeArray.Up) ? ColorUtil.rainbow(v4[0] * ClickGui.getInstance().rainbowHue.getValue()).getRGB() : ColorUtil.rainbow(ClickGui.getInstance().rainbowHue.getValue()).getRGB()) : this.color, true);
                /*SL:167*/++v4[0];
            }
            /*SL:169*/if (this.line.getValue()) {
                final int v15 = /*EL:170*/5;
                /*SL:171*/RenderUtil.drawHLineG(0 - v15, 5 - v15, 1000 - v15, RainbowUtil.getColour().hashCode(), RainbowUtil.getFurtherColour(this.lineoffset.getValue()).hashCode());
            }
            /*SL:173*/if (this.time.getValue()) {
                final String v9 = /*EL:174*/v10 + "Time " + ChatFormatting.WHITE + new SimpleDateFormat("h:mm a").format(new Date());
                /*SL:175*/v11 += 10;
                /*SL:176*/this.renderer.drawString(v9, scaledWidth - this.renderer.getStringWidth(v9) - 2, scaledHeight - 2 - v11, ((boolean)ClickGui.getInstance().rainbow.getValue()) ? ((ClickGui.getInstance().rainbowModeA.getValue() == ClickGui.rainbowModeArray.Up) ? ColorUtil.rainbow(v4[0] * ClickGui.getInstance().rainbowHue.getValue()).getRGB() : ColorUtil.rainbow(ClickGui.getInstance().rainbowHue.getValue()).getRGB()) : this.color, true);
                /*SL:177*/++v4[0];
            }
            /*SL:179*/if (this.tps.getValue()) {
                final String v9 = /*EL:180*/v10 + "TPS " + ChatFormatting.WHITE + Legacy.serverManager.getTPS();
                /*SL:181*/v11 += 10;
                /*SL:182*/this.renderer.drawString(v9, scaledWidth - this.renderer.getStringWidth(v9) - 2, scaledHeight - 2 - v11, ((boolean)ClickGui.getInstance().rainbow.getValue()) ? ((ClickGui.getInstance().rainbowModeA.getValue() == ClickGui.rainbowModeArray.Up) ? ColorUtil.rainbow(v4[0] * ClickGui.getInstance().rainbowHue.getValue()).getRGB() : ColorUtil.rainbow(ClickGui.getInstance().rainbowHue.getValue()).getRGB()) : this.color, true);
                /*SL:183*/++v4[0];
            }
            final String v9 = /*EL:185*/v10 + "FPS " + ChatFormatting.WHITE + Minecraft.field_71470_ab;
            final String v16 = /*EL:186*/v10 + "Ping " + ChatFormatting.WHITE + Legacy.serverManager.getPing();
            /*SL:187*/if (this.renderer.getStringWidth(v16) > this.renderer.getStringWidth(v9)) {
                /*SL:188*/if (this.ping.getValue()) {
                    /*SL:189*/v11 += 10;
                    /*SL:190*/this.renderer.drawString(v16, scaledWidth - this.renderer.getStringWidth(v16) - 2, scaledHeight - 2 - v11, ((boolean)ClickGui.getInstance().rainbow.getValue()) ? ((ClickGui.getInstance().rainbowModeA.getValue() == ClickGui.rainbowModeArray.Up) ? ColorUtil.rainbow(v4[0] * ClickGui.getInstance().rainbowHue.getValue()).getRGB() : ColorUtil.rainbow(ClickGui.getInstance().rainbowHue.getValue()).getRGB()) : this.color, true);
                    /*SL:191*/++v4[0];
                }
                /*SL:193*/if (this.fps.getValue()) {
                    /*SL:194*/v11 += 10;
                    /*SL:195*/this.renderer.drawString(v9, scaledWidth - this.renderer.getStringWidth(v9) - 2, scaledHeight - 2 - v11, ((boolean)ClickGui.getInstance().rainbow.getValue()) ? ((ClickGui.getInstance().rainbowModeA.getValue() == ClickGui.rainbowModeArray.Up) ? ColorUtil.rainbow(v4[0] * ClickGui.getInstance().rainbowHue.getValue()).getRGB() : ColorUtil.rainbow(ClickGui.getInstance().rainbowHue.getValue()).getRGB()) : this.color, true);
                    /*SL:196*/++v4[0];
                }
            }
            else {
                /*SL:199*/if (this.fps.getValue()) {
                    /*SL:200*/v11 += 10;
                    /*SL:201*/this.renderer.drawString(v9, scaledWidth - this.renderer.getStringWidth(v9) - 2, scaledHeight - 2 - v11, ((boolean)ClickGui.getInstance().rainbow.getValue()) ? ((ClickGui.getInstance().rainbowModeA.getValue() == ClickGui.rainbowModeArray.Up) ? ColorUtil.rainbow(v4[0] * ClickGui.getInstance().rainbowHue.getValue()).getRGB() : ColorUtil.rainbow(ClickGui.getInstance().rainbowHue.getValue()).getRGB()) : this.color, true);
                    /*SL:202*/++v4[0];
                }
                /*SL:204*/if (this.ping.getValue()) {
                    /*SL:205*/v11 += 10;
                    /*SL:206*/this.renderer.drawString(v16, scaledWidth - this.renderer.getStringWidth(v16) - 2, scaledHeight - 2 - v11, ((boolean)ClickGui.getInstance().rainbow.getValue()) ? ((ClickGui.getInstance().rainbowModeA.getValue() == ClickGui.rainbowModeArray.Up) ? ColorUtil.rainbow(v4[0] * ClickGui.getInstance().rainbowHue.getValue()).getRGB() : ColorUtil.rainbow(ClickGui.getInstance().rainbowHue.getValue()).getRGB()) : this.color, true);
                    /*SL:207*/++v4[0];
                }
            }
        }
        else {
            /*SL:211*/if (this.line.getValue()) {
                final int v15 = /*EL:212*/5;
                /*SL:213*/RenderUtil.drawHLineG(0 - v15, 5 - v15, 1000 - v15, RainbowUtil.getColour().hashCode(), RainbowUtil.getFurtherColour(this.lineoffset.getValue()).hashCode());
            }
            /*SL:215*/if (this.potions.getValue()) {
                final List<PotionEffect> v12 = /*EL:216*/new ArrayList<PotionEffect>(Minecraft.func_71410_x().field_71439_g.func_70651_bq());
                /*SL:217*/for (final PotionEffect v13 : v12) {
                    final String v14 = Legacy.potionManager.getColoredPotionString(/*EL:218*/v13);
                    /*SL:219*/this.renderer.drawString(v14, scaledWidth - this.renderer.getStringWidth(v14) - 2, 2 + v11++ * 10, v13.func_188419_a().func_76401_j(), true);
                }
            }
            /*SL:222*/if (this.speed.getValue()) {
                final String v9 = /*EL:223*/v10 + "Speed " + ChatFormatting.WHITE + Legacy.speedManager.getSpeedKpH() + " km/h";
                /*SL:224*/this.renderer.drawString(v9, scaledWidth - this.renderer.getStringWidth(v9) - 2, 2 + v11++ * 10, ((boolean)ClickGui.getInstance().rainbow.getValue()) ? ((ClickGui.getInstance().rainbowModeA.getValue() == ClickGui.rainbowModeArray.Up) ? ColorUtil.rainbow(v4[0] * ClickGui.getInstance().rainbowHue.getValue()).getRGB() : ColorUtil.rainbow(ClickGui.getInstance().rainbowHue.getValue()).getRGB()) : this.color, true);
                /*SL:225*/++v4[0];
            }
            /*SL:227*/if (this.time.getValue()) {
                final String v9 = /*EL:228*/v10 + "Time " + ChatFormatting.WHITE + new SimpleDateFormat("h:mm a").format(new Date());
                /*SL:229*/this.renderer.drawString(v9, scaledWidth - this.renderer.getStringWidth(v9) - 2, 2 + v11++ * 10, ((boolean)ClickGui.getInstance().rainbow.getValue()) ? ((ClickGui.getInstance().rainbowModeA.getValue() == ClickGui.rainbowModeArray.Up) ? ColorUtil.rainbow(v4[0] * ClickGui.getInstance().rainbowHue.getValue()).getRGB() : ColorUtil.rainbow(ClickGui.getInstance().rainbowHue.getValue()).getRGB()) : this.color, true);
                /*SL:230*/++v4[0];
            }
            /*SL:232*/if (this.tps.getValue()) {
                final String v9 = /*EL:233*/v10 + "TPS " + ChatFormatting.WHITE + Legacy.serverManager.getTPS();
                /*SL:234*/this.renderer.drawString(v9, scaledWidth - this.renderer.getStringWidth(v9) - 2, 2 + v11++ * 10, ((boolean)ClickGui.getInstance().rainbow.getValue()) ? ((ClickGui.getInstance().rainbowModeA.getValue() == ClickGui.rainbowModeArray.Up) ? ColorUtil.rainbow(v4[0] * ClickGui.getInstance().rainbowHue.getValue()).getRGB() : ColorUtil.rainbow(ClickGui.getInstance().rainbowHue.getValue()).getRGB()) : this.color, true);
                /*SL:235*/++v4[0];
            }
            final String v9 = /*EL:237*/v10 + "FPS " + ChatFormatting.WHITE + Minecraft.field_71470_ab;
            final String v16 = /*EL:238*/v10 + "Ping " + ChatFormatting.WHITE + Legacy.serverManager.getPing();
            /*SL:239*/if (this.renderer.getStringWidth(v16) > this.renderer.getStringWidth(v9)) {
                /*SL:240*/if (this.ping.getValue()) {
                    /*SL:241*/this.renderer.drawString(v16, scaledWidth - this.renderer.getStringWidth(v16) - 2, 2 + v11++ * 10, ((boolean)ClickGui.getInstance().rainbow.getValue()) ? ((ClickGui.getInstance().rainbowModeA.getValue() == ClickGui.rainbowModeArray.Up) ? ColorUtil.rainbow(v4[0] * ClickGui.getInstance().rainbowHue.getValue()).getRGB() : ColorUtil.rainbow(ClickGui.getInstance().rainbowHue.getValue()).getRGB()) : this.color, true);
                    /*SL:242*/++v4[0];
                }
                /*SL:244*/if (this.fps.getValue()) {
                    /*SL:245*/this.renderer.drawString(v9, scaledWidth - this.renderer.getStringWidth(v9) - 2, 2 + v11++ * 10, ((boolean)ClickGui.getInstance().rainbow.getValue()) ? ((ClickGui.getInstance().rainbowModeA.getValue() == ClickGui.rainbowModeArray.Up) ? ColorUtil.rainbow(v4[0] * ClickGui.getInstance().rainbowHue.getValue()).getRGB() : ColorUtil.rainbow(ClickGui.getInstance().rainbowHue.getValue()).getRGB()) : this.color, true);
                    /*SL:246*/++v4[0];
                }
            }
            else {
                /*SL:249*/if (this.fps.getValue()) {
                    /*SL:250*/this.renderer.drawString(v9, scaledWidth - this.renderer.getStringWidth(v9) - 2, 2 + v11++ * 10, ((boolean)ClickGui.getInstance().rainbow.getValue()) ? ((ClickGui.getInstance().rainbowModeA.getValue() == ClickGui.rainbowModeArray.Up) ? ColorUtil.rainbow(v4[0] * ClickGui.getInstance().rainbowHue.getValue()).getRGB() : ColorUtil.rainbow(ClickGui.getInstance().rainbowHue.getValue()).getRGB()) : this.color, true);
                    /*SL:251*/++v4[0];
                }
                /*SL:253*/if (this.ping.getValue()) {
                    /*SL:254*/this.renderer.drawString(v16, scaledWidth - this.renderer.getStringWidth(v16) - 2, 2 + v11++ * 10, ((boolean)ClickGui.getInstance().rainbow.getValue()) ? ((ClickGui.getInstance().rainbowModeA.getValue() == ClickGui.rainbowModeArray.Up) ? ColorUtil.rainbow(v4[0] * ClickGui.getInstance().rainbowHue.getValue()).getRGB() : ColorUtil.rainbow(ClickGui.getInstance().rainbowHue.getValue()).getRGB()) : this.color, true);
                    /*SL:255*/++v4[0];
                }
            }
        }
        final boolean v17 = HUD.mc.field_71441_e.func_180494_b(HUD.mc.field_71439_g.func_180425_c()).func_185359_l().equals(/*EL:259*/"Hell");
        final int v18 = (int)HUD.mc.field_71439_g.field_70165_t;
        final int v19 = (int)HUD.mc.field_71439_g.field_70163_u;
        final int v20 = (int)HUD.mc.field_71439_g.field_70161_v;
        final float v21 = /*EL:263*/v17 ? 8.0f : 0.125f;
        final int v22 = (int)(HUD.mc.field_71439_g.field_70165_t * /*EL:264*/v21);
        final int v23 = (int)(HUD.mc.field_71439_g.field_70161_v * /*EL:265*/v21);
        /*SL:266*/v11 = ((HUD.mc.field_71462_r instanceof GuiChat) ? 14 : 0);
        final String v24 = ChatFormatting.WHITE + /*EL:267*/"XYZ " + ChatFormatting.RESET + (v17 ? (v18 + ", " + v19 + ", " + v20 + ChatFormatting.WHITE + " [" + ChatFormatting.RESET + v22 + ", " + v23 + ChatFormatting.WHITE + "]" + ChatFormatting.RESET) : (v18 + ", " + v19 + ", " + v20 + ChatFormatting.WHITE + " [" + ChatFormatting.RESET + v22 + ", " + v23 + ChatFormatting.WHITE + "]"));
        final String v25 = /*EL:268*/this.direction.getValue() ? Legacy.rotationManager.getDirection4D(false) : "";
        final String v26 = /*EL:269*/this.coords.getValue() ? v24 : "";
        /*SL:270*/v11 += 10;
        /*SL:271*/if (ClickGui.getInstance().rainbow.getValue()) {
            final String v27 = /*EL:272*/this.coords.getValue() ? ("XYZ " + (v17 ? (v18 + ", " + v19 + ", " + v20 + " [" + v22 + ", " + v23 + "]") : (v18 + ", " + v19 + ", " + v20 + " [" + v22 + ", " + v23 + "]"))) : "";
            /*SL:273*/if (ClickGui.getInstance().rainbowModeHud.getValue() == ClickGui.rainbowMode.Static) {
                /*SL:274*/this.renderer.drawString(v25, 2.0f, scaledHeight - v11 - 11, ColorUtil.rainbow(ClickGui.getInstance().rainbowHue.getValue()).getRGB(), true);
                /*SL:275*/this.renderer.drawString(v27, 2.0f, scaledHeight - v11, ColorUtil.rainbow(ClickGui.getInstance().rainbowHue.getValue()).getRGB(), true);
            }
            else {
                final int[] v28 = /*EL:277*/{ 1 };
                final char[] v29 = /*EL:278*/v25.toCharArray();
                float v30 = /*EL:279*/0.0f;
                /*SL:280*/for (final char v31 : v29) {
                    /*SL:281*/this.renderer.drawString(String.valueOf(v31), 2.0f + v30, scaledHeight - v11 - 11, ColorUtil.rainbow(v28[0] * ClickGui.getInstance().rainbowHue.getValue()).getRGB(), true);
                    /*SL:282*/v30 += this.renderer.getStringWidth(String.valueOf(v31));
                    /*SL:283*/++v28[0];
                }
                final int[] v32 = /*EL:285*/{ 1 };
                final char[] v33 = /*EL:286*/v27.toCharArray();
                float v34 = /*EL:287*/0.0f;
                /*SL:288*/for (final char v35 : v33) {
                    /*SL:289*/this.renderer.drawString(String.valueOf(v35), 2.0f + v34, scaledHeight - v11, ColorUtil.rainbow(v32[0] * ClickGui.getInstance().rainbowHue.getValue()).getRGB(), true);
                    /*SL:290*/v34 += this.renderer.getStringWidth(String.valueOf(v35));
                    /*SL:291*/++v32[0];
                }
            }
        }
        else {
            /*SL:295*/this.renderer.drawString(v25, 2.0f, scaledHeight - v11 - 11, this.color, true);
            /*SL:296*/this.renderer.drawString(v26, 2.0f, scaledHeight - v11, this.color, true);
        }
        /*SL:298*/if (this.armor.getValue()) {
            /*SL:299*/this.renderArmorHUD(true);
        }
        /*SL:300*/if (this.totems.getValue()) {
            /*SL:301*/this.renderTotemHUD();
        }
        /*SL:302*/if (this.greeter.getValue()) {
            /*SL:303*/this.renderGreeter();
        }
    }
    
    public Map<String, Integer> getTextRadarPlayers() {
        /*SL:307*/return EntityUtil.getTextRadarPlayers();
    }
    
    public void renderGreeter() {
        final int scaledWidth = /*EL:311*/this.renderer.scaledWidth;
        String string = /*EL:312*/"looking good today, ";
        /*SL:313*/if (this.greeter.getValue()) {
            /*SL:314*/string = string + HUD.mc.field_71439_g.getDisplayNameString() + " <3";
        }
        /*SL:315*/if (ClickGui.getInstance().rainbow.getValue()) {
            /*SL:316*/if (ClickGui.getInstance().rainbowModeHud.getValue() == ClickGui.rainbowMode.Static) {
                /*SL:317*/this.renderer.drawString(string, scaledWidth / 2.0f - this.renderer.getStringWidth(string) / 2.0f + 2.0f, 2.0f, ColorUtil.rainbow(ClickGui.getInstance().rainbowHue.getValue()).getRGB(), true);
            }
            else {
                final int[] array = /*EL:319*/{ 1 };
                final char[] charArray = /*EL:320*/string.toCharArray();
                float n = /*EL:321*/0.0f;
                /*SL:322*/for (final char v1 : charArray) {
                    /*SL:323*/this.renderer.drawString(String.valueOf(v1), scaledWidth / 2.0f - this.renderer.getStringWidth(string) / 2.0f + 2.0f + n, 2.0f, ColorUtil.rainbow(array[0] * ClickGui.getInstance().rainbowHue.getValue()).getRGB(), true);
                    /*SL:324*/n += this.renderer.getStringWidth(String.valueOf(v1));
                    /*SL:325*/++array[0];
                }
            }
        }
        else {
            /*SL:329*/this.renderer.drawString(string, scaledWidth / 2.0f - this.renderer.getStringWidth(string) / 2.0f + 2.0f, 2.0f, this.color, true);
        }
    }
    
    public void renderTotemHUD() {
        final int scaledWidth = /*EL:334*/this.renderer.scaledWidth;
        final int scaledHeight = /*EL:335*/this.renderer.scaledHeight;
        int v0 = HUD.mc.field_71439_g.field_71071_by.field_70462_a.stream().filter(/*EL:336*/a1 -> a1.func_77973_b() == Items.field_190929_cY).mapToInt(ItemStack::func_190916_E).sum();
        /*SL:337*/if (HUD.mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_190929_cY) {
            /*SL:338*/v0 += HUD.mc.field_71439_g.func_184592_cb().func_190916_E();
        }
        /*SL:339*/if (v0 > 0) {
            /*SL:340*/GlStateManager.func_179098_w();
            final int v = /*EL:341*/scaledWidth / 2;
            final int v2 = /*EL:342*/0;
            final int v3 = /*EL:343*/scaledHeight - 55 - ((HUD.mc.field_71439_g.func_70090_H() && HUD.mc.field_71442_b.func_78763_f()) ? 10 : 0);
            final int v4 = /*EL:344*/v - 189 + 180 + 2;
            /*SL:345*/GlStateManager.func_179126_j();
            RenderUtil.itemRender.field_77023_b = /*EL:346*/200.0f;
            RenderUtil.itemRender.func_180450_b(HUD.totem, /*EL:347*/v4, v3);
            RenderUtil.itemRender.func_180453_a(HUD.mc.field_71466_p, HUD.totem, /*EL:348*/v4, v3, "");
            RenderUtil.itemRender.field_77023_b = /*EL:349*/0.0f;
            /*SL:350*/GlStateManager.func_179098_w();
            /*SL:351*/GlStateManager.func_179140_f();
            /*SL:352*/GlStateManager.func_179097_i();
            /*SL:353*/this.renderer.drawStringWithShadow(v0 + "", v4 + 19 - 2 - this.renderer.getStringWidth(v0 + ""), v3 + 9, 16777215);
            /*SL:354*/GlStateManager.func_179126_j();
            /*SL:355*/GlStateManager.func_179140_f();
        }
    }
    
    public void renderCrystal() {
        final int scaledWidth = /*EL:359*/this.renderer.scaledWidth;
        final int scaledHeight = /*EL:360*/this.renderer.scaledHeight;
        int v0 = HUD.mc.field_71439_g.field_71071_by.field_70462_a.stream().filter(/*EL:361*/a1 -> a1.func_77973_b() == Items.field_185158_cP).mapToInt(ItemStack::func_190916_E).sum();
        /*SL:362*/if (HUD.mc.field_71439_g.func_184592_cb().func_77973_b() == Items.field_185158_cP) {
            /*SL:363*/v0 += HUD.mc.field_71439_g.func_184592_cb().func_190916_E();
        }
        /*SL:364*/if (v0 > 0) {
            /*SL:365*/GlStateManager.func_179098_w();
            final int v = /*EL:366*/scaledWidth / 2;
            final int v2 = /*EL:367*/0;
            final int v3 = /*EL:368*/scaledHeight - 60 - ((HUD.mc.field_71439_g.func_70090_H() && HUD.mc.field_71442_b.func_78763_f()) ? 10 : 0);
            final int v4 = /*EL:369*/v - 189 + 180 + 2;
            /*SL:370*/GlStateManager.func_179126_j();
            RenderUtil.itemRender.field_77023_b = /*EL:371*/200.0f;
            RenderUtil.itemRender.func_180450_b(HUD.totem, /*EL:372*/v4, v3);
            RenderUtil.itemRender.func_180453_a(HUD.mc.field_71466_p, HUD.totem, /*EL:373*/v4, v3, "");
            RenderUtil.itemRender.field_77023_b = /*EL:374*/0.0f;
            /*SL:375*/GlStateManager.func_179098_w();
            /*SL:376*/GlStateManager.func_179140_f();
            /*SL:377*/GlStateManager.func_179097_i();
            /*SL:378*/this.renderer.drawStringWithShadow(v0 + "", v4 + 19 - 2 - this.renderer.getStringWidth(v0 + ""), v3 + 9, 16777215);
            /*SL:379*/GlStateManager.func_179126_j();
            /*SL:380*/GlStateManager.func_179140_f();
        }
    }
    
    public void renderArmorHUD(final boolean v-10) {
        final int scaledWidth = /*EL:385*/this.renderer.scaledWidth;
        final int scaledHeight = /*EL:386*/this.renderer.scaledHeight;
        /*SL:387*/GlStateManager.func_179098_w();
        final int n = /*EL:388*/scaledWidth / 2;
        int n2 = /*EL:389*/0;
        final int n3 = /*EL:390*/scaledHeight - 55 - ((HUD.mc.field_71439_g.func_70090_H() && HUD.mc.field_71442_b.func_78763_f()) ? 10 : 0);
        /*SL:391*/for (final ItemStack itemStack : HUD.mc.field_71439_g.field_71071_by.field_70460_b) {
            /*SL:392*/++n2;
            /*SL:393*/if (itemStack.func_190926_b()) {
                continue;
            }
            final int n4 = /*EL:394*/n - 90 + (9 - n2) * 20 + 2;
            /*SL:395*/GlStateManager.func_179126_j();
            RenderUtil.itemRender.field_77023_b = /*EL:396*/200.0f;
            RenderUtil.itemRender.func_180450_b(/*EL:397*/itemStack, n4, n3);
            RenderUtil.itemRender.func_180453_a(HUD.mc.field_71466_p, /*EL:398*/itemStack, n4, n3, "");
            RenderUtil.itemRender.field_77023_b = /*EL:399*/0.0f;
            /*SL:400*/GlStateManager.func_179098_w();
            /*SL:401*/GlStateManager.func_179140_f();
            /*SL:402*/GlStateManager.func_179097_i();
            final String s = /*EL:403*/(itemStack.func_190916_E() > 1) ? (itemStack.func_190916_E() + "") : "";
            /*SL:404*/this.renderer.drawStringWithShadow(s, n4 + 19 - 2 - this.renderer.getStringWidth(s), n3 + 9, 16777215);
            /*SL:407*/if (!v-10) {
                continue;
            }
            int a1 = /*EL:408*/0;
            final int v1 = /*EL:409*/itemStack.func_77958_k() - itemStack.func_77952_i();
            final float v2 = /*EL:410*/(itemStack.func_77958_k() - itemStack.func_77952_i()) / itemStack.func_77958_k();
            final float v3 = /*EL:411*/1.0f - v2;
            /*SL:412*/if (v-10) {
                /*SL:413*/a1 = 100 - (int)(v3 * 100.0f);
            }
            else {
                /*SL:415*/a1 = v1;
            }
            /*SL:417*/this.renderer.drawStringWithShadow(a1 + "", n4 + 8 - this.renderer.getStringWidth(a1 + "") / 2, n3 - 11, ColorUtil.toRGBA((int)(v3 * 255.0f), (int)(v2 * 255.0f), 0));
        }
        /*SL:420*/GlStateManager.func_179126_j();
        /*SL:421*/GlStateManager.func_179140_f();
    }
    
    @Override
    public void onLoad() {
        Legacy.commandManager.setClientMessage(/*EL:425*/this.getCommandMessage());
    }
    
    @SubscribeEvent
    public void onSettingChange(final ClientEvent a1) {
        /*SL:430*/if (a1.getStage() == 2 && this.equals(a1.getSetting().getFeature())) {
            Legacy.commandManager.setClientMessage(/*EL:432*/this.getCommandMessage());
        }
    }
    
    public String getCommandMessage() {
        /*SL:436*/return TextUtil.coloredString(this.commandBracket.getPlannedValue(), this.bracketColor.getPlannedValue()) + TextUtil.coloredString(this.command.getPlannedValue(), this.commandColor.getPlannedValue()) + TextUtil.coloredString(this.commandBracket2.getPlannedValue(), this.bracketColor.getPlannedValue());
    }
    
    public String getRainbowCommandMessage() {
        final StringBuilder v1 = /*EL:440*/new StringBuilder(this.getRawCommandMessage());
        /*SL:441*/v1.insert(0, "�+");
        /*SL:442*/v1.append("�r");
        /*SL:443*/return v1.toString();
    }
    
    public String getRawCommandMessage() {
        /*SL:447*/return this.commandBracket.getValue() + this.command.getValue() + this.commandBracket2.getValue();
    }
    
    static {
        box = new ResourceLocation("textures/gui/container/shulker_box.png");
        totem = new ItemStack(Items.field_190929_cY);
        HUD.INSTANCE = new HUD();
    }
    
    public enum RenderingMode
    {
        Length, 
        ABC;
    }
}
