package me.dev.legacy.modules.client;

import java.util.Iterator;
import java.util.List;
import me.dev.legacy.Legacy;
import net.minecraft.entity.player.EntityPlayer;
import java.util.ArrayList;
import me.dev.legacy.api.util.ColorUtil;
import me.dev.legacy.api.event.events.render.Render2DEvent;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class Friends extends Module
{
    private int color;
    public Setting<Integer> friendX;
    public Setting<Integer> friendY;
    
    public Friends() {
        super("FriendList", "Lists ur friends in render", Category.CLIENT, true, false, false);
        this.friendX = (Setting<Integer>)this.register(new Setting("PosX", (T)740, (T)0, (T)1000));
        this.friendY = (Setting<Integer>)this.register(new Setting("PosY", (T)2, (T)0, (T)1000));
    }
    
    @Override
    public void onRender2D(final Render2DEvent a1) {
        /*SL:25*/this.color = ColorUtil.toRGBA(Colors.getInstance().red.getValue(), Colors.getInstance().green.getValue(), Colors.getInstance().blue.getValue());
        /*SL:26*/this.renderFriends();
    }
    
    private void renderFriends() {
        final List<String> list = /*EL:30*/new ArrayList<String>();
        /*SL:31*/for (final EntityPlayer v1 : Friends.mc.field_71441_e.field_73010_i) {
            /*SL:32*/if (Legacy.friendManager.isFriend(v1.func_70005_c_())) {
                /*SL:33*/list.add(v1.func_70005_c_());
            }
        }
        /*SL:36*/if (Colors.getInstance().rainbow.getValue()) {
            /*SL:37*/if (Colors.getInstance().rainbowModeHud.getValue() == Colors.rainbowMode.Static) {
                int v2 = /*EL:38*/this.friendY.getValue();
                final int v3 = /*EL:39*/this.friendX.getValue();
                /*SL:40*/if (list.isEmpty()) {
                    /*SL:41*/this.renderer.drawString("No friends online", v3, v2, ColorUtil.rainbow(Colors.getInstance().rainbowHue.getValue()).getRGB(), true);
                }
                else {
                    /*SL:44*/this.renderer.drawString("Friend(s) near you:", v3, v2, ColorUtil.rainbow(Colors.getInstance().rainbowHue.getValue()).getRGB(), true);
                    /*SL:45*/v2 += 12;
                    /*SL:46*/for (final String v4 : list) {
                        /*SL:47*/this.renderer.drawString(v4, v3, v2, ColorUtil.rainbow(Colors.getInstance().rainbowHue.getValue()).getRGB(), true);
                        /*SL:48*/v2 += 12;
                    }
                }
            }
        }
        else {
            int v2 = /*EL:54*/this.friendY.getValue();
            final int v3 = /*EL:55*/this.friendX.getValue();
            /*SL:56*/if (list.isEmpty()) {
                /*SL:57*/this.renderer.drawString("No friends online", v3, v2, this.color, true);
            }
            else {
                /*SL:60*/this.renderer.drawString("Friend(s) near you:", v3, v2, this.color, true);
                /*SL:61*/v2 += 12;
                /*SL:62*/for (final String v4 : list) {
                    /*SL:63*/this.renderer.drawString(v4, v3, v2, this.color, true);
                    /*SL:64*/v2 += 12;
                }
            }
        }
    }
}
