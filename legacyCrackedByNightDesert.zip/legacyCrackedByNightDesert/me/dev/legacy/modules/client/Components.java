package me.dev.legacy.modules.client;

import net.minecraft.inventory.Slot;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.Vec3d;
import me.dev.legacy.api.util.EntityUtil;
import net.minecraft.client.renderer.DestroyBlockProgress;
import net.minecraft.block.Block;
import net.minecraft.util.math.BlockPos;
import net.minecraft.init.Blocks;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.OpenGlHelper;
import me.dev.legacy.api.util.MathUtil;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import me.dev.legacy.api.event.events.other.PacketEvent;
import me.dev.legacy.api.util.RenderUtil;
import java.awt.Color;
import me.dev.legacy.api.AbstractModule;
import me.dev.legacy.api.event.events.render.Render2DEvent;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.opengl.GL11;
import net.minecraft.util.math.MathHelper;
import java.util.Iterator;
import net.minecraft.entity.Entity;
import me.dev.legacy.Legacy;
import java.util.HashMap;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.player.EntityPlayer;
import java.util.Map;
import me.dev.legacy.impl.setting.Setting;
import net.minecraft.util.ResourceLocation;
import me.dev.legacy.modules.Module;

public class Components extends Module
{
    private static final ResourceLocation box;
    private static final double HALF_PI = 1.5707963267948966;
    public static ResourceLocation logo;
    public Setting<Boolean> inventory;
    public Setting<Integer> invX;
    public Setting<Integer> invY;
    public Setting<Integer> fineinvX;
    public Setting<Integer> fineinvY;
    public Setting<Boolean> renderXCarry;
    public Setting<Integer> invH;
    public Setting<Boolean> holeHud;
    public Setting<Integer> holeX;
    public Setting<Integer> holeY;
    public Setting<Compass> compass;
    public Setting<Integer> compassX;
    public Setting<Integer> compassY;
    public Setting<Integer> scale;
    public Setting<Boolean> playerViewer;
    public Setting<Integer> playerViewerX;
    public Setting<Integer> playerViewerY;
    public Setting<Float> playerScale;
    public Setting<Boolean> imageLogo;
    public Setting<Integer> imageX;
    public Setting<Integer> imageY;
    public Setting<Integer> imageWidth;
    public Setting<Integer> imageHeight;
    public Setting<Boolean> clock;
    public Setting<Boolean> clockFill;
    public Setting<Float> clockX;
    public Setting<Float> clockY;
    public Setting<Float> clockRadius;
    public Setting<Float> clockLineWidth;
    public Setting<Integer> clockSlices;
    public Setting<Integer> clockLoops;
    private final Map<EntityPlayer, Map<Integer, ItemStack>> hotbarMap;
    
    public Components() {
        super("Components", "HudComponents", Category.CLIENT, false, false, true);
        this.inventory = (Setting<Boolean>)this.register(new Setting("Inventory", (T)false));
        this.invX = (Setting<Integer>)this.register(new Setting("InvX", (T)564, (T)0, (T)1000, a1 -> this.inventory.getValue()));
        this.invY = (Setting<Integer>)this.register(new Setting("InvY", (T)467, (T)0, (T)1000, a1 -> this.inventory.getValue()));
        this.fineinvX = (Setting<Integer>)this.register(new Setting("InvFineX", (T)0, a1 -> this.inventory.getValue()));
        this.fineinvY = (Setting<Integer>)this.register(new Setting("InvFineY", (T)0, a1 -> this.inventory.getValue()));
        this.renderXCarry = (Setting<Boolean>)this.register(new Setting("RenderXCarry", (T)false, a1 -> this.inventory.getValue()));
        this.invH = (Setting<Integer>)this.register(new Setting("InvH", (T)3, a1 -> this.inventory.getValue()));
        this.holeHud = (Setting<Boolean>)this.register(new Setting("HoleHUD", (T)false));
        this.holeX = (Setting<Integer>)this.register(new Setting("HoleX", (T)279, (T)0, (T)1000, a1 -> this.holeHud.getValue()));
        this.holeY = (Setting<Integer>)this.register(new Setting("HoleY", (T)485, (T)0, (T)1000, a1 -> this.holeHud.getValue()));
        this.compass = (Setting<Compass>)this.register(new Setting("Compass", (T)Compass.NONE));
        this.compassX = (Setting<Integer>)this.register(new Setting("CompX", (T)472, (T)0, (T)1000, a1 -> this.compass.getValue() != Compass.NONE));
        this.compassY = (Setting<Integer>)this.register(new Setting("CompY", (T)424, (T)0, (T)1000, a1 -> this.compass.getValue() != Compass.NONE));
        this.scale = (Setting<Integer>)this.register(new Setting("Scale", (T)3, (T)0, (T)10, a1 -> this.compass.getValue() != Compass.NONE));
        this.playerViewer = (Setting<Boolean>)this.register(new Setting("PlayerViewer", (T)false));
        this.playerViewerX = (Setting<Integer>)this.register(new Setting("PlayerX", (T)752, (T)0, (T)1000, a1 -> this.playerViewer.getValue()));
        this.playerViewerY = (Setting<Integer>)this.register(new Setting("PlayerY", (T)497, (T)0, (T)1000, a1 -> this.playerViewer.getValue()));
        this.playerScale = (Setting<Float>)this.register(new Setting("PlayerScale", (T)1.0f, (T)0.1f, (T)2.0f, a1 -> this.playerViewer.getValue()));
        this.imageLogo = (Setting<Boolean>)this.register(new Setting("ImageLogo", (T)false));
        this.imageX = (Setting<Integer>)this.register(new Setting("ImageX", (T)2, (T)0, (T)1000, a1 -> this.imageLogo.getValue()));
        this.imageY = (Setting<Integer>)this.register(new Setting("ImageY", (T)2, (T)0, (T)1000, a1 -> this.imageLogo.getValue()));
        this.imageWidth = (Setting<Integer>)this.register(new Setting("ImageWidth", (T)100, (T)0, (T)1000, a1 -> this.imageLogo.getValue()));
        this.imageHeight = (Setting<Integer>)this.register(new Setting("ImageHeight", (T)100, (T)0, (T)1000, a1 -> this.imageLogo.getValue()));
        this.clock = (Setting<Boolean>)this.register(new Setting("Clock", (T)true));
        this.clockFill = (Setting<Boolean>)this.register(new Setting("ClockFill", (T)true));
        this.clockX = (Setting<Float>)this.register(new Setting("ClockX", (T)2.0f, (T)0.0f, (T)1000.0f, a1 -> this.clock.getValue()));
        this.clockY = (Setting<Float>)this.register(new Setting("ClockY", (T)2.0f, (T)0.0f, (T)1000.0f, a1 -> this.clock.getValue()));
        this.clockRadius = (Setting<Float>)this.register(new Setting("ClockRadius", (T)6.0f, (T)0.0f, (T)100.0f, a1 -> this.clock.getValue()));
        this.clockLineWidth = (Setting<Float>)this.register(new Setting("ClockLineWidth", (T)1.0f, (T)0.0f, (T)5.0f, a1 -> this.clock.getValue()));
        this.clockSlices = (Setting<Integer>)this.register(new Setting("ClockSlices", (T)360, (T)1, (T)720, a1 -> this.clock.getValue()));
        this.clockLoops = (Setting<Integer>)this.register(new Setting("ClockLoops", (T)1, (T)1, (T)720, a1 -> this.clock.getValue()));
        this.hotbarMap = new HashMap<EntityPlayer, Map<Integer, ItemStack>>();
    }
    
    public static EntityPlayer getClosestEnemy() {
        EntityPlayer entityPlayer = /*EL:77*/null;
        /*SL:78*/for (final EntityPlayer v1 : Components.mc.field_71441_e.field_73010_i) {
            /*SL:79*/if (v1 != Components.mc.field_71439_g) {
                if (Legacy.friendManager.isFriend(v1)) {
                    continue;
                }
                /*SL:80*/if (entityPlayer == null) {
                    /*SL:81*/entityPlayer = v1;
                }
                else {
                    /*SL:84*/if (Components.mc.field_71439_g.func_70068_e((Entity)v1) >= Components.mc.field_71439_g.func_70068_e((Entity)entityPlayer)) {
                        /*SL:85*/continue;
                    }
                    /*SL:86*/entityPlayer = v1;
                }
            }
        }
        /*SL:88*/return entityPlayer;
    }
    
    private static double getPosOnCompass(final Direction a1) {
        final double v1 = /*EL:92*/Math.toRadians(MathHelper.func_76142_g(Components.mc.field_71439_g.field_70177_z));
        final int v2 = /*EL:93*/a1.ordinal();
        /*SL:94*/return v1 + v2 * 1.5707963267948966;
    }
    
    private static void preboxrender() {
        /*SL:98*/GL11.glPushMatrix();
        /*SL:99*/GlStateManager.func_179094_E();
        /*SL:100*/GlStateManager.func_179118_c();
        /*SL:101*/GlStateManager.func_179086_m(256);
        /*SL:102*/GlStateManager.func_179147_l();
        /*SL:103*/GlStateManager.func_179131_c(255.0f, 255.0f, 255.0f, 255.0f);
    }
    
    private static void postboxrender() {
        /*SL:107*/GlStateManager.func_179084_k();
        /*SL:108*/GlStateManager.func_179097_i();
        /*SL:109*/GlStateManager.func_179140_f();
        /*SL:110*/GlStateManager.func_179126_j();
        /*SL:111*/GlStateManager.func_179141_d();
        /*SL:112*/GlStateManager.func_179121_F();
        /*SL:113*/GL11.glPopMatrix();
    }
    
    private static void preitemrender() {
        /*SL:117*/GL11.glPushMatrix();
        /*SL:118*/GL11.glDepthMask(true);
        /*SL:119*/GlStateManager.func_179086_m(256);
        /*SL:120*/GlStateManager.func_179097_i();
        /*SL:121*/GlStateManager.func_179126_j();
        /*SL:122*/RenderHelper.func_74519_b();
        /*SL:123*/GlStateManager.func_179152_a(1.0f, 1.0f, 0.01f);
    }
    
    private static void postitemrender() {
        /*SL:127*/GlStateManager.func_179152_a(1.0f, 1.0f, 1.0f);
        /*SL:128*/RenderHelper.func_74518_a();
        /*SL:129*/GlStateManager.func_179141_d();
        /*SL:130*/GlStateManager.func_179084_k();
        /*SL:131*/GlStateManager.func_179140_f();
        /*SL:132*/GlStateManager.func_179139_a(0.5, 0.5, 0.5);
        /*SL:133*/GlStateManager.func_179097_i();
        /*SL:134*/GlStateManager.func_179126_j();
        /*SL:135*/GlStateManager.func_179152_a(2.0f, 2.0f, 2.0f);
        /*SL:136*/GL11.glPopMatrix();
    }
    
    public static void drawCompleteImage(final int a1, final int a2, final int a3, final int a4) {
        /*SL:140*/GL11.glPushMatrix();
        /*SL:141*/GL11.glTranslatef((float)a1, (float)a2, 0.0f);
        /*SL:142*/GL11.glBegin(7);
        /*SL:143*/GL11.glTexCoord2f(0.0f, 0.0f);
        /*SL:144*/GL11.glVertex3f(0.0f, 0.0f, 0.0f);
        /*SL:145*/GL11.glTexCoord2f(0.0f, 1.0f);
        /*SL:146*/GL11.glVertex3f(0.0f, (float)a4, 0.0f);
        /*SL:147*/GL11.glTexCoord2f(1.0f, 1.0f);
        /*SL:148*/GL11.glVertex3f((float)a3, (float)a4, 0.0f);
        /*SL:149*/GL11.glTexCoord2f(1.0f, 0.0f);
        /*SL:150*/GL11.glVertex3f((float)a3, 0.0f, 0.0f);
        /*SL:151*/GL11.glEnd();
        /*SL:152*/GL11.glPopMatrix();
    }
    
    @Override
    public void onRender2D(final Render2DEvent a1) {
        /*SL:157*/if (AbstractModule.fullNullCheck()) {
            /*SL:158*/return;
        }
        /*SL:160*/if (this.playerViewer.getValue()) {
            /*SL:161*/this.drawPlayer();
        }
        /*SL:163*/if (this.compass.getValue() != Compass.NONE) {
            /*SL:164*/this.drawCompass();
        }
        /*SL:166*/if (this.holeHud.getValue()) {
            /*SL:167*/this.drawOverlay(a1.partialTicks);
        }
        /*SL:169*/if (this.inventory.getValue()) {
            /*SL:170*/this.renderInventory();
        }
        /*SL:172*/if (this.imageLogo.getValue()) {
            /*SL:173*/this.drawImageLogo();
        }
        /*SL:175*/if (this.clock.getValue()) {
            /*SL:176*/RenderUtil.drawClock(this.clockX.getValue(), this.clockY.getValue(), this.clockRadius.getValue(), this.clockSlices.getValue(), this.clockLoops.getValue(), this.clockLineWidth.getValue(), this.clockFill.getValue(), new Color(255, 0, 0, 255));
        }
    }
    
    @SubscribeEvent
    public void onReceivePacket(final PacketEvent.Receive a1) {
    }
    
    public void drawImageLogo() {
        /*SL:185*/GlStateManager.func_179098_w();
        /*SL:186*/GlStateManager.func_179084_k();
        Components.mc.func_110434_K().func_110577_a(Components.logo);
        drawCompleteImage(/*EL:188*/this.imageX.getValue(), this.imageY.getValue(), this.imageWidth.getValue(), this.imageHeight.getValue());
        Components.mc.func_110434_K().func_147645_c(Components.logo);
        /*SL:190*/GlStateManager.func_179147_l();
        /*SL:191*/GlStateManager.func_179090_x();
    }
    
    public void drawCompass() {
        final ScaledResolution v0 = /*EL:195*/new ScaledResolution(Components.mc);
        /*SL:196*/if (this.compass.getValue() == Compass.LINE) {
            final float v = Components.mc.field_71439_g.field_70177_z;
            final float v2 = /*EL:198*/MathUtil.wrap(v);
            /*SL:199*/RenderUtil.drawRect(this.compassX.getValue(), this.compassY.getValue(), this.compassX.getValue() + 100, this.compassY.getValue() + this.renderer.getFontHeight(), 1963986960);
            /*SL:200*/RenderUtil.glScissor(this.compassX.getValue(), this.compassY.getValue(), this.compassX.getValue() + 100, this.compassY.getValue() + this.renderer.getFontHeight(), v0);
            /*SL:201*/GL11.glEnable(3089);
            final float v3 = /*EL:202*/MathUtil.wrap((float)(Math.atan2(0.0 - Components.mc.field_71439_g.field_70161_v, 0.0 - Components.mc.field_71439_g.field_70165_t) * 180.0 / 3.141592653589793) - 90.0f);
            /*SL:203*/RenderUtil.drawLine(this.compassX.getValue() - v2 + 50.0f + v3, this.compassY.getValue() + 2, this.compassX.getValue() - v2 + 50.0f + v3, this.compassY.getValue() + this.renderer.getFontHeight() - 2, 2.0f, -61424);
            /*SL:204*/RenderUtil.drawLine(this.compassX.getValue() - v2 + 50.0f + 45.0f, this.compassY.getValue() + 2, this.compassX.getValue() - v2 + 50.0f + 45.0f, this.compassY.getValue() + this.renderer.getFontHeight() - 2, 2.0f, -1);
            /*SL:205*/RenderUtil.drawLine(this.compassX.getValue() - v2 + 50.0f - 45.0f, this.compassY.getValue() + 2, this.compassX.getValue() - v2 + 50.0f - 45.0f, this.compassY.getValue() + this.renderer.getFontHeight() - 2, 2.0f, -1);
            /*SL:206*/RenderUtil.drawLine(this.compassX.getValue() - v2 + 50.0f + 135.0f, this.compassY.getValue() + 2, this.compassX.getValue() - v2 + 50.0f + 135.0f, this.compassY.getValue() + this.renderer.getFontHeight() - 2, 2.0f, -1);
            /*SL:207*/RenderUtil.drawLine(this.compassX.getValue() - v2 + 50.0f - 135.0f, this.compassY.getValue() + 2, this.compassX.getValue() - v2 + 50.0f - 135.0f, this.compassY.getValue() + this.renderer.getFontHeight() - 2, 2.0f, -1);
            /*SL:208*/this.renderer.drawStringWithShadow("n", this.compassX.getValue() - v2 + 50.0f + 180.0f - this.renderer.getStringWidth("n") / 2.0f, this.compassY.getValue(), -1);
            /*SL:209*/this.renderer.drawStringWithShadow("n", this.compassX.getValue() - v2 + 50.0f - 180.0f - this.renderer.getStringWidth("n") / 2.0f, this.compassY.getValue(), -1);
            /*SL:210*/this.renderer.drawStringWithShadow("e", this.compassX.getValue() - v2 + 50.0f - 90.0f - this.renderer.getStringWidth("e") / 2.0f, this.compassY.getValue(), -1);
            /*SL:211*/this.renderer.drawStringWithShadow("s", this.compassX.getValue() - v2 + 50.0f - this.renderer.getStringWidth("s") / 2.0f, this.compassY.getValue(), -1);
            /*SL:212*/this.renderer.drawStringWithShadow("w", this.compassX.getValue() - v2 + 50.0f + 90.0f - this.renderer.getStringWidth("w") / 2.0f, this.compassY.getValue(), -1);
            /*SL:213*/RenderUtil.drawLine(this.compassX.getValue() + 50, this.compassY.getValue() + 1, this.compassX.getValue() + 50, this.compassY.getValue() + this.renderer.getFontHeight() - 1, 2.0f, -7303024);
            /*SL:214*/GL11.glDisable(3089);
        }
        else {
            final double v4 = /*EL:216*/this.compassX.getValue();
            final double v5 = /*EL:217*/this.compassY.getValue();
            /*SL:218*/for (final Direction v6 : Direction.values()) {
                final double v7 = getPosOnCompass(/*EL:219*/v6);
                /*SL:220*/this.renderer.drawStringWithShadow(v6.name(), (float)(v4 + this.getX(v7)), (float)(v5 + this.getY(v7)), (v6 == Direction.N) ? -65536 : -1);
            }
        }
    }
    
    public void drawPlayer(final EntityPlayer a1, final int a2, final int a3) {
        /*SL:227*/GlStateManager.func_179094_E();
        /*SL:228*/GlStateManager.func_179124_c(1.0f, 1.0f, 1.0f);
        /*SL:229*/RenderHelper.func_74519_b();
        /*SL:230*/GlStateManager.func_179141_d();
        /*SL:231*/GlStateManager.func_179103_j(7424);
        /*SL:232*/GlStateManager.func_179141_d();
        /*SL:233*/GlStateManager.func_179126_j();
        /*SL:234*/GlStateManager.func_179114_b(0.0f, 0.0f, 5.0f, 0.0f);
        /*SL:235*/GlStateManager.func_179142_g();
        /*SL:236*/GlStateManager.func_179094_E();
        /*SL:237*/GlStateManager.func_179109_b((float)(this.playerViewerX.getValue() + 25), (float)(this.playerViewerY.getValue() + 25), 50.0f);
        /*SL:238*/GlStateManager.func_179152_a(-50.0f * this.playerScale.getValue(), 50.0f * this.playerScale.getValue(), 50.0f * this.playerScale.getValue());
        /*SL:239*/GlStateManager.func_179114_b(180.0f, 0.0f, 0.0f, 1.0f);
        /*SL:240*/GlStateManager.func_179114_b(135.0f, 0.0f, 1.0f, 0.0f);
        /*SL:241*/RenderHelper.func_74519_b();
        /*SL:242*/GlStateManager.func_179114_b(-135.0f, 0.0f, 1.0f, 0.0f);
        /*SL:243*/GlStateManager.func_179114_b(-(float)Math.atan(this.playerViewerY.getValue() / 40.0f) * 20.0f, 1.0f, 0.0f, 0.0f);
        /*SL:244*/GlStateManager.func_179109_b(0.0f, 0.0f, 0.0f);
        final RenderManager v2 = Components.mc.func_175598_ae();
        /*SL:246*/v2.func_178631_a(180.0f);
        /*SL:247*/v2.func_178633_a(false);
        try {
            /*SL:249*/v2.func_188391_a((Entity)a1, 0.0, 0.0, 0.0, 0.0f, 1.0f, false);
        }
        catch (Exception ex) {}
        /*SL:253*/v2.func_178633_a(true);
        /*SL:254*/GlStateManager.func_179121_F();
        /*SL:255*/RenderHelper.func_74518_a();
        /*SL:256*/GlStateManager.func_179101_C();
        /*SL:257*/GlStateManager.func_179138_g(OpenGlHelper.field_77476_b);
        /*SL:258*/GlStateManager.func_179090_x();
        /*SL:259*/GlStateManager.func_179138_g(OpenGlHelper.field_77478_a);
        /*SL:260*/GlStateManager.func_179143_c(515);
        /*SL:261*/GlStateManager.func_179117_G();
        /*SL:262*/GlStateManager.func_179097_i();
        /*SL:263*/GlStateManager.func_179121_F();
    }
    
    public void drawPlayer() {
        final EntityPlayerSP v1 = Components.mc.field_71439_g;
        /*SL:268*/GlStateManager.func_179094_E();
        /*SL:269*/GlStateManager.func_179124_c(1.0f, 1.0f, 1.0f);
        /*SL:270*/RenderHelper.func_74519_b();
        /*SL:271*/GlStateManager.func_179141_d();
        /*SL:272*/GlStateManager.func_179103_j(7424);
        /*SL:273*/GlStateManager.func_179141_d();
        /*SL:274*/GlStateManager.func_179126_j();
        /*SL:275*/GlStateManager.func_179114_b(0.0f, 0.0f, 5.0f, 0.0f);
        /*SL:276*/GlStateManager.func_179142_g();
        /*SL:277*/GlStateManager.func_179094_E();
        /*SL:278*/GlStateManager.func_179109_b((float)(this.playerViewerX.getValue() + 25), (float)(this.playerViewerY.getValue() + 25), 50.0f);
        /*SL:279*/GlStateManager.func_179152_a(-50.0f * this.playerScale.getValue(), 50.0f * this.playerScale.getValue(), 50.0f * this.playerScale.getValue());
        /*SL:280*/GlStateManager.func_179114_b(180.0f, 0.0f, 0.0f, 1.0f);
        /*SL:281*/GlStateManager.func_179114_b(135.0f, 0.0f, 1.0f, 0.0f);
        /*SL:282*/RenderHelper.func_74519_b();
        /*SL:283*/GlStateManager.func_179114_b(-135.0f, 0.0f, 1.0f, 0.0f);
        /*SL:284*/GlStateManager.func_179114_b(-(float)Math.atan(this.playerViewerY.getValue() / 40.0f) * 20.0f, 1.0f, 0.0f, 0.0f);
        /*SL:285*/GlStateManager.func_179109_b(0.0f, 0.0f, 0.0f);
        final RenderManager v2 = Components.mc.func_175598_ae();
        /*SL:287*/v2.func_178631_a(180.0f);
        /*SL:288*/v2.func_178633_a(false);
        try {
            /*SL:290*/v2.func_188391_a((Entity)v1, 0.0, 0.0, 0.0, 0.0f, 1.0f, false);
        }
        catch (Exception ex) {}
        /*SL:294*/v2.func_178633_a(true);
        /*SL:295*/GlStateManager.func_179121_F();
        /*SL:296*/RenderHelper.func_74518_a();
        /*SL:297*/GlStateManager.func_179101_C();
        /*SL:298*/GlStateManager.func_179138_g(OpenGlHelper.field_77476_b);
        /*SL:299*/GlStateManager.func_179090_x();
        /*SL:300*/GlStateManager.func_179138_g(OpenGlHelper.field_77478_a);
        /*SL:301*/GlStateManager.func_179143_c(515);
        /*SL:302*/GlStateManager.func_179117_G();
        /*SL:303*/GlStateManager.func_179097_i();
        /*SL:304*/GlStateManager.func_179121_F();
    }
    
    private double getX(final double a1) {
        /*SL:308*/return Math.sin(a1) * (this.scale.getValue() * 10);
    }
    
    private double getY(final double a1) {
        final double v1 = /*EL:312*/MathHelper.func_76131_a(Components.mc.field_71439_g.field_70125_A + 30.0f, -90.0f, 90.0f);
        final double v2 = /*EL:313*/Math.toRadians(v1);
        /*SL:314*/return Math.cos(a1) * Math.sin(v2) * (this.scale.getValue() * 10);
    }
    
    public void drawOverlay(final float v-10) {
        float a2 = /*EL:324*/0.0f;
        final int n = /*EL:325*/MathHelper.func_76128_c(Components.mc.field_71439_g.field_70177_z * 4.0f / 360.0f + 0.5) & 0x3;
        /*SL:326*/switch (n) {
            case 1: {
                /*SL:328*/a2 = 90.0f;
                /*SL:329*/break;
            }
            case 2: {
                /*SL:332*/a2 = -180.0f;
                /*SL:333*/break;
            }
            case 3: {
                /*SL:336*/a2 = -90.0f;
                break;
            }
        }
        final BlockPos traceToBlock = /*EL:340*/this.traceToBlock(v-10, a2);
        final Block v0 = /*EL:341*/this.getBlock(traceToBlock);
        /*SL:342*/if (v0 != null && v0 != Blocks.field_150350_a) {
            final int a1 = /*EL:343*/this.getBlockDamage(traceToBlock);
            /*SL:344*/if (a1 != 0) {
                /*SL:345*/RenderUtil.drawRect(this.holeX.getValue() + 16, this.holeY.getValue(), this.holeX.getValue() + 32, this.holeY.getValue() + 16, 1627324416);
            }
            /*SL:347*/this.drawBlock(v0, this.holeX.getValue() + 16, this.holeY.getValue());
        }
        final BlockPos traceToBlock2;
        final Block block;
        /*SL:349*/if ((block = this.getBlock(traceToBlock2 = this.traceToBlock(v-10, a2 - 180.0f))) != null && block != Blocks.field_150350_a) {
            final int v = /*EL:350*/this.getBlockDamage(traceToBlock2);
            /*SL:351*/if (v != 0) {
                /*SL:352*/RenderUtil.drawRect(this.holeX.getValue() + 16, this.holeY.getValue() + 32, this.holeX.getValue() + 32, this.holeY.getValue() + 48, 1627324416);
            }
            /*SL:354*/this.drawBlock(block, this.holeX.getValue() + 16, this.holeY.getValue() + 32);
        }
        final BlockPos traceToBlock3;
        final Block block2;
        /*SL:356*/if ((block2 = this.getBlock(traceToBlock3 = this.traceToBlock(v-10, a2 + 90.0f))) != null && block2 != Blocks.field_150350_a) {
            final int v = /*EL:357*/this.getBlockDamage(traceToBlock3);
            /*SL:358*/if (v != 0) {
                /*SL:359*/RenderUtil.drawRect(this.holeX.getValue() + 32, this.holeY.getValue() + 16, this.holeX.getValue() + 48, this.holeY.getValue() + 32, 1627324416);
            }
            /*SL:361*/this.drawBlock(block2, this.holeX.getValue() + 32, this.holeY.getValue() + 16);
        }
        final BlockPos traceToBlock4;
        final Block block3;
        /*SL:363*/if ((block3 = this.getBlock(traceToBlock4 = this.traceToBlock(v-10, a2 - 90.0f))) != null && block3 != Blocks.field_150350_a) {
            final int v = /*EL:364*/this.getBlockDamage(traceToBlock4);
            /*SL:365*/if (v != 0) {
                /*SL:366*/RenderUtil.drawRect(this.holeX.getValue(), this.holeY.getValue() + 16, this.holeX.getValue() + 16, this.holeY.getValue() + 32, 1627324416);
            }
            /*SL:368*/this.drawBlock(block3, this.holeX.getValue(), this.holeY.getValue() + 16);
        }
    }
    
    public void drawOverlay(final float v2, final Entity v3, final int v4, final int v5) {
        float v6 = /*EL:379*/0.0f;
        final int v7 = /*EL:380*/MathHelper.func_76128_c(v3.field_70177_z * 4.0f / 360.0f + 0.5) & 0x3;
        /*SL:381*/switch (v7) {
            case 1: {
                /*SL:383*/v6 = 90.0f;
                /*SL:384*/break;
            }
            case 2: {
                /*SL:387*/v6 = -180.0f;
                /*SL:388*/break;
            }
            case 3: {
                /*SL:391*/v6 = -90.0f;
                break;
            }
        }
        final BlockPos v8 = /*EL:395*/this.traceToBlock(v2, v6, v3);
        final Block v9 = /*EL:396*/this.getBlock(v8);
        /*SL:397*/if (v9 != null && v9 != Blocks.field_150350_a) {
            final int a1 = /*EL:398*/this.getBlockDamage(v8);
            /*SL:399*/if (a1 != 0) {
                /*SL:400*/RenderUtil.drawRect(v4 + 16, v5, v4 + 32, v5 + 16, 1627324416);
            }
            /*SL:402*/this.drawBlock(v9, v4 + 16, v5);
        }
        final BlockPos v11;
        final Block v10;
        /*SL:404*/if ((v10 = this.getBlock(v11 = this.traceToBlock(v2, v6 - 180.0f, v3))) != null && v10 != Blocks.field_150350_a) {
            final int a2 = /*EL:405*/this.getBlockDamage(v11);
            /*SL:406*/if (a2 != 0) {
                /*SL:407*/RenderUtil.drawRect(v4 + 16, v5 + 32, v4 + 32, v5 + 48, 1627324416);
            }
            /*SL:409*/this.drawBlock(v10, v4 + 16, v5 + 32);
        }
        final BlockPos v13;
        final Block v12;
        /*SL:411*/if ((v12 = this.getBlock(v13 = this.traceToBlock(v2, v6 + 90.0f, v3))) != null && v12 != Blocks.field_150350_a) {
            final int a3 = /*EL:412*/this.getBlockDamage(v13);
            /*SL:413*/if (a3 != 0) {
                /*SL:414*/RenderUtil.drawRect(v4 + 32, v5 + 16, v4 + 48, v5 + 32, 1627324416);
            }
            /*SL:416*/this.drawBlock(v12, v4 + 32, v5 + 16);
        }
        final BlockPos v15;
        final Block v14;
        /*SL:418*/if ((v14 = this.getBlock(v15 = this.traceToBlock(v2, v6 - 90.0f, v3))) != null && v14 != Blocks.field_150350_a) {
            final int a4 = /*EL:419*/this.getBlockDamage(v15);
            /*SL:420*/if (a4 != 0) {
                /*SL:421*/RenderUtil.drawRect(v4, v5 + 16, v4 + 16, v5 + 32, 1627324416);
            }
            /*SL:423*/this.drawBlock(v14, v4, v5 + 16);
        }
    }
    
    private int getBlockDamage(final BlockPos v2) {
        /*SL:428*/for (final DestroyBlockProgress a1 : Components.mc.field_71438_f.field_72738_E.values()) {
            /*SL:429*/if (a1.func_180246_b().func_177958_n() == v2.func_177958_n() && a1.func_180246_b().func_177956_o() == v2.func_177956_o()) {
                if (a1.func_180246_b().func_177952_p() != v2.func_177952_p()) {
                    /*SL:430*/continue;
                }
                /*SL:431*/return a1.func_73106_e();
            }
        }
        /*SL:433*/return 0;
    }
    
    private BlockPos traceToBlock(final float a1, final float a2) {
        final Vec3d v1 = /*EL:437*/EntityUtil.interpolateEntity((Entity)Components.mc.field_71439_g, a1);
        final Vec3d v2 = /*EL:438*/MathUtil.direction(a2);
        /*SL:439*/return new BlockPos(v1.field_72450_a + v2.field_72450_a, v1.field_72448_b, v1.field_72449_c + v2.field_72449_c);
    }
    
    private BlockPos traceToBlock(final float a1, final float a2, final Entity a3) {
        final Vec3d v1 = /*EL:443*/EntityUtil.interpolateEntity(a3, a1);
        final Vec3d v2 = /*EL:444*/MathUtil.direction(a2);
        /*SL:445*/return new BlockPos(v1.field_72450_a + v2.field_72450_a, v1.field_72448_b, v1.field_72449_c + v2.field_72449_c);
    }
    
    private Block getBlock(final BlockPos a1) {
        final Block v1 = Components.mc.field_71441_e.func_180495_p(/*EL:449*/a1).func_177230_c();
        /*SL:450*/if (v1 == Blocks.field_150357_h || v1 == Blocks.field_150343_Z) {
            /*SL:451*/return v1;
        }
        /*SL:453*/return Blocks.field_150350_a;
    }
    
    private void drawBlock(final Block a1, final float a2, final float a3) {
        final ItemStack v1 = /*EL:457*/new ItemStack(a1);
        /*SL:458*/GlStateManager.func_179094_E();
        /*SL:459*/GlStateManager.func_179147_l();
        /*SL:460*/GlStateManager.func_179120_a(770, 771, 1, 0);
        /*SL:461*/RenderHelper.func_74520_c();
        /*SL:462*/GlStateManager.func_179109_b(a2, a3, 0.0f);
        Components.mc.func_175599_af().field_77023_b = /*EL:463*/501.0f;
        Components.mc.func_175599_af().func_180450_b(/*EL:464*/v1, 0, 0);
        Components.mc.func_175599_af().field_77023_b = /*EL:465*/0.0f;
        /*SL:466*/RenderHelper.func_74518_a();
        /*SL:467*/GlStateManager.func_179084_k();
        /*SL:468*/GlStateManager.func_179131_c(1.0f, 1.0f, 1.0f, 1.0f);
        /*SL:469*/GlStateManager.func_179121_F();
    }
    
    public void renderInventory() {
        /*SL:473*/this.boxrender(this.invX.getValue() + this.fineinvX.getValue(), this.invY.getValue() + this.fineinvY.getValue());
        /*SL:474*/this.itemrender((NonNullList<ItemStack>)Components.mc.field_71439_g.field_71071_by.field_70462_a, this.invX.getValue() + this.fineinvX.getValue(), this.invY.getValue() + this.fineinvY.getValue());
    }
    
    private void boxrender(final int a1, final int a2) {
        preboxrender();
        Components.mc.field_71446_o.func_110577_a(Components.box);
        /*SL:480*/RenderUtil.drawTexturedRect(a1, a2, 0, 0, 176, 16, 500);
        /*SL:481*/RenderUtil.drawTexturedRect(a1, a2 + 16, 0, 16, 176, 54 + this.invH.getValue(), 500);
        /*SL:482*/RenderUtil.drawTexturedRect(a1, a2 + 16 + 54, 0, 160, 176, 8, 500);
        postboxrender();
    }
    
    private void itemrender(final NonNullList<ItemStack> v-4, final int v-3, final int v-2) {
        /*SL:489*/for (int v0 = 0; v0 < v-4.size() - 9; ++v0) {
            int a3 = /*EL:490*/v-3 + v0 % 9 * 18 + 8;
            final int a2 = /*EL:491*/v-2 + v0 / 9 * 18 + 18;
            /*SL:492*/a3 = (ItemStack)v-4.get(v0 + 9);
            preitemrender();
            Components.mc.func_175599_af().field_77023_b = /*EL:494*/501.0f;
            RenderUtil.itemRender.func_180450_b(/*EL:495*/a3, a3, a2);
            RenderUtil.itemRender.func_180453_a(Components.mc.field_71466_p, /*EL:496*/a3, a3, a2, (String)null);
            Components.mc.func_175599_af().field_77023_b = /*EL:497*/0.0f;
            postitemrender();
        }
        /*SL:500*/if (this.renderXCarry.getValue()) {
            /*SL:501*/for (int v0 = 1; v0 < 5; ++v0) {
                final int n = /*EL:502*/v-3 + (v0 + 4) % 9 * 18 + 8;
                final ItemStack v = Components.mc.field_71439_g.field_71069_bz.field_75151_b.get(/*EL:503*/v0).func_75211_c();
                /*SL:504*/if (v != null) {
                    if (!v.field_190928_g) {
                        preitemrender();
                        Components.mc.func_175599_af().field_77023_b = /*EL:506*/501.0f;
                        RenderUtil.itemRender.func_180450_b(/*EL:507*/v, n, v-2 + 1);
                        RenderUtil.itemRender.func_180453_a(Components.mc.field_71466_p, /*EL:508*/v, n, v-2 + 1, (String)null);
                        Components.mc.func_175599_af().field_77023_b = /*EL:509*/0.0f;
                        postitemrender();
                    }
                }
            }
        }
    }
    
    static {
        box = new ResourceLocation("textures/gui/container/shulker_box.png");
        Components.logo = new ResourceLocation("textures/legacy-logo.png");
    }
    
    public enum TargetHudDesign
    {
        NORMAL, 
        COMPACT;
    }
    
    public enum Compass
    {
        NONE, 
        CIRCLE, 
        LINE;
    }
    
    private enum Direction
    {
        N, 
        W, 
        S, 
        E;
    }
}
