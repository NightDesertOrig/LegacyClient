package me.dev.legacy.modules.client;

import me.dev.legacy.DiscordPresence;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class RPC extends Module
{
    public static RPC INSTANCE;
    public Setting<Boolean> showIP;
    public Setting<Boolean> users;
    
    public RPC() {
        super("RPC", "Discord rich presence", Category.CLIENT, false, false, false);
        this.showIP = (Setting<Boolean>)this.register(new Setting("IP", (T)false));
        this.users = (Setting<Boolean>)this.register(new Setting("Users", (T)false));
        RPC.INSTANCE = this;
    }
    
    @Override
    public void onEnable() {
        /*SL:20*/DiscordPresence.start();
    }
    
    @Override
    public void onDisable() {
        /*SL:25*/DiscordPresence.stop();
    }
}
