package me.dev.legacy.modules;

import me.dev.legacy.api.event.events.render.RenderEvent;
import me.dev.legacy.impl.command.Command;
import net.minecraftforge.fml.common.eventhandler.Event;
import me.dev.legacy.api.event.ClientEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import com.mojang.realmsclient.gui.ChatFormatting;
import me.dev.legacy.Legacy;
import me.dev.legacy.modules.client.HUD;
import me.dev.legacy.api.event.events.render.Render3DEvent;
import me.dev.legacy.api.event.events.render.Render2DEvent;
import me.dev.legacy.impl.setting.Bind;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.api.AbstractModule;

public abstract class Module extends AbstractModule
{
    private final String description;
    private final Category category;
    public Setting<Boolean> enabled;
    public Setting<Boolean> drawn;
    public Setting<Bind> bind;
    public Setting<String> displayName;
    public boolean hasListener;
    public boolean alwaysListening;
    public boolean hidden;
    public float arrayListOffset;
    public float arrayListVOffset;
    public float offset;
    public float vOffset;
    public boolean sliding;
    private String suffix;
    
    public Module(final String a1, final String a2, final Category a3, final boolean a4, final boolean a5, final boolean a6) {
        super(a1);
        this.enabled = (Setting<Boolean>)this.register(new Setting("Enabled", (T)false));
        this.drawn = (Setting<Boolean>)this.register(new Setting("Drawn", (T)true));
        this.bind = (Setting<Bind>)this.register(new Setting("Keybind", (T)new Bind(-1)));
        this.arrayListOffset = 0.0f;
        this.arrayListVOffset = 0.0f;
        this.suffix = "";
        this.displayName = (Setting<String>)this.register(new Setting("DisplayName", (T)a1));
        this.description = a2;
        this.category = a3;
        this.hasListener = a4;
        this.hidden = a5;
        this.alwaysListening = a6;
    }
    
    public boolean isSliding() {
        /*SL:46*/return this.sliding;
    }
    
    public void onEnable() {
    }
    
    public void onDisable() {
    }
    
    public void onToggle() {
    }
    
    public void onLoad() {
    }
    
    public void onTick() {
    }
    
    public void onLogin() {
    }
    
    public void onLogout() {
    }
    
    public void onUpdate() {
    }
    
    public void onRender2D(final Render2DEvent a1) {
    }
    
    public void onRender3D(final Render3DEvent a1) {
    }
    
    public void onRender3D() {
    }
    
    public void onUnload() {
    }
    
    public String getDisplayInfo() {
        /*SL:84*/return null;
    }
    
    public boolean isOn() {
        /*SL:88*/return this.enabled.getValue();
    }
    
    public boolean isOff() {
        /*SL:92*/return !this.enabled.getValue();
    }
    
    public void setEnabled(final boolean a1) {
        /*SL:96*/if (a1) {
            /*SL:97*/this.enable();
        }
        else {
            /*SL:99*/this.disable();
        }
    }
    
    public void setSuffix(final String a1) {
        /*SL:104*/this.suffix = "[" + a1 + "]";
    }
    
    public void enable() {
        /*SL:108*/this.enabled.setValue(Boolean.TRUE);
        /*SL:109*/this.onToggle();
        /*SL:110*/this.onEnable();
        /*SL:111*/if (HUD.getInstance().notifyToggles.getValue()) {
            final TextComponentString v1 = /*EL:112*/new TextComponentString(Legacy.commandManager.getClientMessage() + " " + ChatFormatting.BOLD + this.getDisplayName() + ChatFormatting.GREEN + " enabled.");
            Module.mc.field_71456_v.func_146158_b().func_146234_a(/*EL:113*/(ITextComponent)v1, 1);
        }
        /*SL:115*/if (this.isOn() && this.hasListener && !this.alwaysListening) {
            MinecraftForge.EVENT_BUS.register(/*EL:116*/(Object)this);
        }
    }
    
    public void disable() {
        /*SL:121*/if (this.hasListener && !this.alwaysListening) {
            MinecraftForge.EVENT_BUS.unregister(/*EL:122*/(Object)this);
        }
        /*SL:124*/this.enabled.setValue(false);
        /*SL:125*/if (HUD.getInstance().notifyToggles.getValue()) {
            final TextComponentString v1 = /*EL:126*/new TextComponentString(Legacy.commandManager.getClientMessage() + " " + ChatFormatting.BOLD + this.getDisplayName() + ChatFormatting.RED + " disabled.");
            Module.mc.field_71456_v.func_146158_b().func_146234_a(/*EL:127*/(ITextComponent)v1, 1);
        }
        /*SL:129*/this.onToggle();
        /*SL:130*/this.onDisable();
    }
    
    public void toggle() {
        final ClientEvent v1 = /*EL:134*/new ClientEvent(this.isEnabled() ? 0 : 1, this);
        MinecraftForge.EVENT_BUS.post(/*EL:135*/(Event)v1);
        /*SL:136*/if (!v1.isCanceled()) {
            /*SL:137*/this.setEnabled(!this.isEnabled());
        }
    }
    
    public String getDisplayName() {
        /*SL:142*/return this.displayName.getValue();
    }
    
    public void setDisplayName(final String a1) {
        final Module v1 = Legacy.moduleManager.getModuleByDisplayName(/*EL:146*/a1);
        final Module v2 = Legacy.moduleManager.getModuleByName(/*EL:147*/a1);
        /*SL:148*/if (v1 == null && v2 == null) {
            /*SL:149*/Command.sendMessage(this.getDisplayName() + ", name: " + this.getName() + ", has been renamed to: " + a1);
            /*SL:150*/this.displayName.setValue(a1);
            /*SL:151*/return;
        }
        /*SL:153*/Command.sendMessage(ChatFormatting.RED + "A module of this name already exists.");
    }
    
    public String getDescription() {
        /*SL:157*/return this.description;
    }
    
    public boolean isDrawn() {
        /*SL:161*/return this.drawn.getValue();
    }
    
    public void setDrawn(final boolean a1) {
        /*SL:165*/this.drawn.setValue(a1);
    }
    
    public Category getCategory() {
        /*SL:169*/return this.category;
    }
    
    public String getInfo() {
        /*SL:173*/return null;
    }
    
    public Bind getBind() {
        /*SL:178*/return this.bind.getValue();
    }
    
    public void setBind(final int a1) {
        /*SL:182*/this.bind.setValue(new Bind(a1));
    }
    
    public boolean listening() {
        /*SL:186*/return (this.hasListener && this.isOn()) || this.alwaysListening;
    }
    
    public String getFullArrayString() {
        /*SL:190*/return this.getDisplayName() + ChatFormatting.GRAY + ((this.getDisplayInfo() != null) ? (" [" + ChatFormatting.WHITE + this.getDisplayInfo() + ChatFormatting.GRAY + "]") : "");
    }
    
    public void onWorldRender(final RenderEvent a1) {
    }
    
    public enum Category
    {
        COMBAT(/*EL:194*/"Combat"), 
        MISC("Misc"), 
        RENDER("Render"), 
        MOVEMENT("Movement"), 
        PLAYER("Player"), 
        CLIENT("Client");
        
        private final String name;
        
        private Category(final String a1) {
            this.name = a1;
        }
        
        public String getName() {
            /*SL:211*/return this.name;
        }
    }
}
