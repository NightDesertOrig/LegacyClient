package me.dev.legacy.modules.render;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.client.GuiIngameForge;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import me.dev.legacy.modules.Module;

public class EntityHunger extends Module
{
    public EntityHunger() {
        super("EntityHunger", "Renders hunger while riding entities", Category.RENDER, true, false, false);
    }
    
    @SubscribeEvent
    public void onRenderGameOverlay(final RenderGameOverlayEvent a1) {
        GuiIngameForge.renderFood = /*EL:16*/true;
    }
}
