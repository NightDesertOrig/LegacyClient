package me.dev.legacy.modules.render;

import me.dev.legacy.api.util.RenderUtil;
import java.awt.Color;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraft.client.gui.ScaledResolution;
import me.dev.legacy.api.event.events.render.Render2DEvent;
import me.dev.legacy.impl.setting.Setting;
import net.minecraft.util.ResourceLocation;
import me.dev.legacy.modules.Module;

public final class HitMarkers extends Module
{
    public final ResourceLocation image;
    private int renderTicks;
    public Setting<Integer> red;
    public Setting<Integer> green;
    public Setting<Integer> blue;
    public Setting<Integer> alpha;
    public Setting<Integer> thickness;
    public Setting<Double> time;
    
    public HitMarkers() {
        super("HitMarkers", "hitmarker thingys", Category.RENDER, false, false, false);
        this.red = (Setting<Integer>)this.register(new Setting("Red", (T)255, (T)0, (T)255));
        this.green = (Setting<Integer>)this.register(new Setting("Green", (T)255, (T)0, (T)255));
        this.blue = (Setting<Integer>)this.register(new Setting("Blue", (T)255, (T)0, (T)255));
        this.alpha = (Setting<Integer>)this.register(new Setting("Alpha", (T)255, (T)0, (T)255));
        this.thickness = (Setting<Integer>)this.register(new Setting("Thickness", (T)2, (T)1, (T)6));
        this.time = (Setting<Double>)this.register(new Setting("Time", (T)20.0, (T)1.0, (T)50.0));
        this.image = new ResourceLocation("hitmarker.png");
        this.renderTicks = 100;
    }
    
    @Override
    public void onRender2D(final Render2DEvent v2) {
        /*SL:36*/if (this.renderTicks < this.time.getValue()) {
            final ScaledResolution a1 = /*EL:37*/new ScaledResolution(HitMarkers.mc);
            /*SL:38*/this.drawHitMarkers();
        }
    }
    
    @Override
    public void onEnable() {
        MinecraftForge.EVENT_BUS.register(/*EL:43*/(Object)this);
    }
    
    @Override
    public void onDisable() {
        MinecraftForge.EVENT_BUS.unregister(/*EL:47*/(Object)this);
    }
    
    @SubscribeEvent
    public void onAttackEntity(final AttackEntityEvent a1) {
        /*SL:52*/if (!a1.getEntity().equals((Object)HitMarkers.mc.field_71439_g)) {
            /*SL:53*/return;
        }
        /*SL:55*/this.renderTicks = 0;
    }
    
    @SubscribeEvent
    public void onTickClientTick(final TickEvent a1) {
        /*SL:60*/++this.renderTicks;
    }
    
    public void drawHitMarkers() {
        final ScaledResolution v1 = /*EL:64*/new ScaledResolution(HitMarkers.mc);
        /*SL:65*/RenderUtil.drawLine(v1.func_78326_a() / 2.0f - 4.0f, v1.func_78328_b() / 2.0f - 4.0f, v1.func_78326_a() / 2.0f - 8.0f, v1.func_78328_b() / 2.0f - 8.0f, this.thickness.getValue(), new Color(this.red.getValue(), this.green.getValue(), this.blue.getValue()).getRGB());
        /*SL:66*/RenderUtil.drawLine(v1.func_78326_a() / 2.0f + 4.0f, v1.func_78328_b() / 2.0f - 4.0f, v1.func_78326_a() / 2.0f + 8.0f, v1.func_78328_b() / 2.0f - 8.0f, this.thickness.getValue(), new Color(this.red.getValue(), this.green.getValue(), this.blue.getValue()).getRGB());
        /*SL:67*/RenderUtil.drawLine(v1.func_78326_a() / 2.0f - 4.0f, v1.func_78328_b() / 2.0f + 4.0f, v1.func_78326_a() / 2.0f - 8.0f, v1.func_78328_b() / 2.0f + 8.0f, this.thickness.getValue(), new Color(this.red.getValue(), this.green.getValue(), this.blue.getValue()).getRGB());
        /*SL:68*/RenderUtil.drawLine(v1.func_78326_a() / 2.0f + 4.0f, v1.func_78328_b() / 2.0f + 4.0f, v1.func_78326_a() / 2.0f + 8.0f, v1.func_78328_b() / 2.0f + 8.0f, this.thickness.getValue(), new Color(this.red.getValue(), this.green.getValue(), this.blue.getValue()).getRGB());
    }
}
