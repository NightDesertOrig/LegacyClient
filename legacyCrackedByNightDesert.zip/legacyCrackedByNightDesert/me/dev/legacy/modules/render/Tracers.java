package me.dev.legacy.modules.render;

import java.awt.Color;
import org.lwjgl.opengl.GL11;
import net.minecraft.util.math.Vec3d;
import net.minecraft.entity.Entity;
import me.dev.legacy.Legacy;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.client.renderer.GlStateManager;
import me.dev.legacy.api.AbstractModule;
import me.dev.legacy.api.event.events.render.Render3DEvent;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class Tracers extends Module
{
    Setting<Double> width;
    Setting<Double> range;
    Setting<Boolean> friends;
    
    public Tracers() {
        super("Tracers", "Draws Tracers.", Category.RENDER, false, false, false);
        this.width = (Setting<Double>)this.register(new Setting("Width", (T)2.0, (T)0.0, (T)10.0));
        this.range = (Setting<Double>)this.register(new Setting("Range", (T)100.0, (T)0.0, (T)500.0));
        this.friends = (Setting<Boolean>)this.register(new Setting("Friends", (T)true));
    }
    
    @Override
    public void onRender3D(final Render3DEvent a1) {
        /*SL:28*/if (AbstractModule.nullCheck()) {
            /*SL:29*/return;
        }
        /*SL:31*/GlStateManager.func_179094_E();
        final EntityPlayer v1;
        final float[] v2;
        Tracers.mc.field_71441_e.field_72996_f.forEach(/*EL:32*/a1 -> {
            if (!(a1 instanceof EntityPlayer) || a1 == Tracers.mc.field_71439_g) {
                return;
            }
            else {
                v1 = (EntityPlayer)a1;
                /*SL:41*/if (!this.friends.getValue() && Legacy.friendManager.isFriend(v1.func_70005_c_())) {
                    return;
                }
                else if (Tracers.mc.field_71439_g.func_70032_d((Entity)v1) > this.range.getValue()) {
                    return;
                }
                else {
                    v2 = this.getColorByDistance(a1);
                    this.drawLineToEntity(a1, v2[0], v2[1], v2[2], v2[3]);
                    return;
                }
            }
        });
        GlStateManager.func_179121_F();
    }
    
    public double interpolate(final double a1, final double a2) {
        /*SL:44*/return a2 + (a1 - a2) * Tracers.mc.func_184121_ak();
    }
    
    public double[] interpolate(final Entity a1) {
        final double v1 = /*EL:48*/this.interpolate(a1.field_70165_t, a1.field_70142_S) - Tracers.mc.func_175598_ae().field_78725_b;
        final double v2 = /*EL:49*/this.interpolate(a1.field_70163_u, a1.field_70137_T) - Tracers.mc.func_175598_ae().field_78726_c;
        final double v3 = /*EL:50*/this.interpolate(a1.field_70161_v, a1.field_70136_U) - Tracers.mc.func_175598_ae().field_78723_d;
        /*SL:51*/return new double[] { v1, v2, v3 };
    }
    
    public void drawLineToEntity(final Entity a1, final float a2, final float a3, final float a4, final float a5) {
        final double[] v1 = /*EL:55*/this.interpolate(a1);
        /*SL:56*/this.drawLine(v1[0], v1[1], v1[2], a1.field_70131_O, a2, a3, a4, a5);
    }
    
    public void drawLine(final double a1, final double a2, final double a3, final double a4, final float a5, final float a6, final float a7, final float a8) {
        final Vec3d v1 = /*EL:60*/new Vec3d(0.0, 0.0, 1.0).func_178789_a(-(float)Math.toRadians(Tracers.mc.field_71439_g.field_70125_A)).func_178785_b(-(float)Math.toRadians(Tracers.mc.field_71439_g.field_70177_z));
        /*SL:61*/this.drawLineFromPosToPos(v1.field_72450_a, v1.field_72448_b + Tracers.mc.field_71439_g.func_70047_e(), v1.field_72449_c, a1, a2, a3, a4, a5, a6, a7, a8);
    }
    
    public void drawLineFromPosToPos(final double a1, final double a2, final double a3, final double a4, final double a5, final double a6, final double a7, final float a8, final float a9, final float a10, final float a11) {
        /*SL:65*/GL11.glBlendFunc(770, 771);
        /*SL:66*/GL11.glEnable(3042);
        /*SL:67*/GL11.glLineWidth((float)(Object)this.width.getValue());
        /*SL:68*/GL11.glDisable(3553);
        /*SL:69*/GL11.glDisable(2929);
        /*SL:70*/GL11.glDepthMask(false);
        /*SL:71*/GL11.glColor4f(a8, a9, a10, a11);
        /*SL:72*/GL11.glEnable(2848);
        /*SL:73*/GL11.glHint(3154, 4354);
        /*SL:74*/GL11.glLoadIdentity();
        final boolean v1 = Tracers.mc.field_71474_y.field_74336_f;
        Tracers.mc.field_71474_y.field_74336_f = /*EL:76*/false;
        Tracers.mc.field_71460_t.func_78467_g(Tracers.mc.func_184121_ak());
        /*SL:78*/GL11.glBegin(1);
        /*SL:79*/GL11.glVertex3d(a1, a2, a3);
        /*SL:80*/GL11.glVertex3d(a4, a5, a6);
        /*SL:82*/GL11.glEnd();
        /*SL:83*/GL11.glEnable(3553);
        /*SL:84*/GL11.glEnable(2929);
        /*SL:85*/GL11.glDepthMask(true);
        /*SL:86*/GL11.glDisable(3042);
        /*SL:87*/GL11.glDisable(2848);
        /*SL:88*/GL11.glColor3d(1.0, 1.0, 1.0);
        Tracers.mc.field_71474_y.field_74336_f = /*EL:89*/v1;
    }
    
    public float[] getColorByDistance(final Entity a1) {
        /*SL:93*/if (a1 instanceof EntityPlayer && Legacy.friendManager.isFriend(a1.func_70005_c_())) {
            /*SL:94*/return new float[] { 0.0f, 0.5f, 1.0f, 1.0f };
        }
        final Color v1 = /*EL:96*/new Color(Color.HSBtoRGB((float)(Math.max(0.0, Math.min(Tracers.mc.field_71439_g.func_70068_e(a1), 2500.0) / 2500.0) / 3.0), 1.0f, 0.8f) | 0xFF000000);
        /*SL:97*/return new float[] { v1.getRed() / 255.0f, v1.getGreen() / 255.0f, v1.getBlue() / 255.0f, 1.0f };
    }
}
