package me.dev.legacy.modules.render;

import java.awt.Color;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.opengl.GL11;
import me.dev.legacy.api.util.EntityUtil;
import me.dev.legacy.modules.client.ClickGui;
import me.dev.legacy.api.event.events.render.RenderEntityModelEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.network.play.server.SPacketDestroyEntities;
import me.dev.legacy.api.event.events.other.PacketEvent;
import java.util.Iterator;
import net.minecraft.entity.Entity;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.entity.item.EntityEnderCrystal;
import java.util.Map;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class CrystalChams extends Module
{
    public Setting<Boolean> animateScale;
    public Setting<Boolean> chams;
    public Setting<Boolean> throughWalls;
    public Setting<Boolean> wireframeThroughWalls;
    public Setting<Boolean> glint;
    public Setting<Boolean> wireframe;
    public Setting<Float> scale;
    public Setting<Float> lineWidth;
    public Setting<Boolean> colorSync;
    public Setting<Boolean> rainbow;
    public Setting<Integer> saturation;
    public Setting<Integer> brightness;
    public Setting<Integer> speed;
    public Setting<Boolean> xqz;
    public Setting<Integer> red;
    public Setting<Integer> green;
    public Setting<Integer> blue;
    public Setting<Integer> alpha;
    public Setting<Integer> hiddenRed;
    public Setting<Integer> hiddenGreen;
    public Setting<Integer> hiddenBlue;
    public Setting<Integer> hiddenAlpha;
    public Map<EntityEnderCrystal, Float> scaleMap;
    public static CrystalChams INSTANCE;
    
    public CrystalChams() {
        super("CrystalChams", "Modifies crystal rendering in different ways", Category.RENDER, true, false, false);
        this.animateScale = (Setting<Boolean>)this.register(new Setting("AnimateScale", (T)false));
        this.chams = (Setting<Boolean>)this.register(new Setting("Chams", (T)false));
        this.throughWalls = (Setting<Boolean>)this.register(new Setting("ThroughWalls", (T)true));
        this.wireframeThroughWalls = (Setting<Boolean>)this.register(new Setting("WireThroughWalls", (T)true));
        this.glint = (Setting<Boolean>)this.register(new Setting("Glint", (T)false, a1 -> this.chams.getValue()));
        this.wireframe = (Setting<Boolean>)this.register(new Setting("Wireframe", (T)false));
        this.scale = (Setting<Float>)this.register(new Setting("Scale", (T)1.0f, (T)0.1f, (T)10.0f));
        this.lineWidth = (Setting<Float>)this.register(new Setting("LineWidth", (T)1.0f, (T)0.1f, (T)3.0f));
        this.colorSync = (Setting<Boolean>)this.register(new Setting("Sync", (T)false));
        this.rainbow = (Setting<Boolean>)this.register(new Setting("Rainbow", (T)false));
        this.saturation = (Setting<Integer>)this.register(new Setting("Saturation", (T)50, (T)0, (T)100, a1 -> this.rainbow.getValue()));
        this.brightness = (Setting<Integer>)this.register(new Setting("Brightness", (T)100, (T)0, (T)100, a1 -> this.rainbow.getValue()));
        this.speed = (Setting<Integer>)this.register(new Setting("Speed", (T)40, (T)1, (T)100, a1 -> this.rainbow.getValue()));
        this.xqz = (Setting<Boolean>)this.register(new Setting("XQZ", (T)false, a1 -> !this.rainbow.getValue() && this.throughWalls.getValue()));
        this.red = (Setting<Integer>)this.register(new Setting("Red", (T)0, (T)0, (T)255, a1 -> !this.rainbow.getValue()));
        this.green = (Setting<Integer>)this.register(new Setting("Green", (T)255, (T)0, (T)255, a1 -> !this.rainbow.getValue()));
        this.blue = (Setting<Integer>)this.register(new Setting("Blue", (T)0, (T)0, (T)255, a1 -> !this.rainbow.getValue()));
        this.alpha = (Setting<Integer>)this.register(new Setting("Alpha", (T)255, (T)0, (T)255));
        this.hiddenRed = (Setting<Integer>)this.register(new Setting("Hidden Red", (T)255, (T)0, (T)255, a1 -> this.xqz.getValue() && !this.rainbow.getValue()));
        this.hiddenGreen = (Setting<Integer>)this.register(new Setting("Hidden Green", (T)0, (T)0, (T)255, a1 -> this.xqz.getValue() && !this.rainbow.getValue()));
        this.hiddenBlue = (Setting<Integer>)this.register(new Setting("Hidden Blue", (T)255, (T)0, (T)255, a1 -> this.xqz.getValue() && !this.rainbow.getValue()));
        this.hiddenAlpha = (Setting<Integer>)this.register(new Setting("Hidden Alpha", (T)255, (T)0, (T)255, a1 -> this.xqz.getValue() && !this.rainbow.getValue()));
        this.scaleMap = new ConcurrentHashMap<EntityEnderCrystal, Float>();
        CrystalChams.INSTANCE = this;
    }
    
    @Override
    public void onUpdate() {
        /*SL:53*/for (final Entity v1 : CrystalChams.mc.field_71441_e.field_72996_f) {
            /*SL:54*/if (!(v1 instanceof EntityEnderCrystal)) {
                continue;
            }
            /*SL:55*/if (!this.scaleMap.containsKey(v1)) {
                /*SL:56*/this.scaleMap.put((EntityEnderCrystal)v1, 3.125E-4f);
            }
            else {
                /*SL:58*/this.scaleMap.put((EntityEnderCrystal)v1, this.scaleMap.get(v1) + 3.125E-4f);
            }
            /*SL:60*/if (this.scaleMap.get(v1) < 0.0625f * this.scale.getValue()) {
                continue;
            }
            /*SL:61*/this.scaleMap.remove(v1);
        }
    }
    
    @SubscribeEvent
    public void onReceivePacket(final PacketEvent.Receive v-4) {
        /*SL:67*/if (v-4.getPacket() instanceof SPacketDestroyEntities) {
            final SPacketDestroyEntities sPacketDestroyEntities = /*EL:68*/(SPacketDestroyEntities)v-4.getPacket();
            /*SL:69*/for (final int v1 : sPacketDestroyEntities.func_149098_c()) {
                final Entity a1 = CrystalChams.mc.field_71441_e.func_73045_a(/*EL:70*/v1);
                /*SL:71*/if (a1 instanceof EntityEnderCrystal) {
                    /*SL:72*/this.scaleMap.remove(a1);
                }
            }
        }
    }
    
    public void onRenderModel(final RenderEntityModelEvent a1) {
        /*SL:78*/if (a1.getStage() != 0 || !(a1.entity instanceof EntityEnderCrystal) || !this.wireframe.getValue()) {
            /*SL:79*/return;
        }
        final Color v1 = /*EL:81*/this.colorSync.getValue() ? ClickGui.getInstance().getCurrentColor() : EntityUtil.getColor(a1.entity, this.red.getValue(), this.green.getValue(), this.blue.getValue(), this.alpha.getValue(), false);
        final boolean v2 = CrystalChams.mc.field_71474_y.field_74347_j;
        CrystalChams.mc.field_71474_y.field_74347_j = /*EL:83*/false;
        final float v3 = CrystalChams.mc.field_71474_y.field_74333_Y;
        CrystalChams.mc.field_71474_y.field_74333_Y = /*EL:85*/10000.0f;
        /*SL:86*/GL11.glPushMatrix();
        /*SL:87*/GL11.glPushAttrib(1048575);
        /*SL:88*/GL11.glPolygonMode(1032, 6913);
        /*SL:89*/GL11.glDisable(3553);
        /*SL:90*/GL11.glDisable(2896);
        /*SL:91*/if (this.wireframeThroughWalls.getValue()) {
            /*SL:92*/GL11.glDisable(2929);
        }
        /*SL:94*/GL11.glEnable(2848);
        /*SL:95*/GL11.glEnable(3042);
        /*SL:96*/GlStateManager.func_179112_b(770, 771);
        /*SL:97*/GlStateManager.func_179131_c(v1.getRed() / 255.0f, v1.getGreen() / 255.0f, v1.getBlue() / 255.0f, v1.getAlpha() / 255.0f);
        /*SL:98*/GlStateManager.func_187441_d((float)this.lineWidth.getValue());
        /*SL:99*/a1.modelBase.func_78088_a(a1.entity, a1.limbSwing, a1.limbSwingAmount, a1.age, a1.headYaw, a1.headPitch, a1.scale);
        /*SL:100*/GL11.glPopAttrib();
        /*SL:101*/GL11.glPopMatrix();
    }
}
