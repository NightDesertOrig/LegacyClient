package me.dev.legacy.modules.render;

import net.minecraft.init.SoundEvents;
import net.minecraftforge.event.entity.PlaySoundAtEntityEvent;
import net.minecraft.entity.passive.EntityBat;
import net.minecraftforge.client.event.RenderLivingEvent;
import java.util.Iterator;
import java.util.HashMap;
import net.minecraft.world.BossInfo;
import net.minecraft.client.gui.GuiBossOverlay;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.opengl.GL11;
import net.minecraft.client.gui.BossInfoClient;
import java.util.UUID;
import java.util.Map;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.world.World;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.item.Item;
import net.minecraft.init.Blocks;
import net.minecraft.world.GameType;
import java.util.Random;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.network.play.server.SPacketTimeUpdate;
import me.dev.legacy.api.event.events.other.PacketEvent;
import java.util.function.Consumer;
import net.minecraft.entity.Entity;
import java.util.function.Function;
import java.util.function.Predicate;
import net.minecraft.entity.item.EntityItem;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.modules.Module;

public class NoRender extends Module
{
    private static NoRender INSTANCE;
    public Setting<Boolean> portal;
    public Setting<Boolean> pumpkin;
    public Setting<Boolean> totemPops;
    public Setting<Boolean> items;
    public Setting<Boolean> nausea;
    public Setting<Boolean> hurtcam;
    public Setting<Fog> fog;
    public Setting<Boolean> noWeather;
    public Setting<Boss> boss;
    public Setting<Float> scale;
    public Setting<Boolean> bats;
    public Setting<NoArmor> noArmor;
    public Setting<Skylight> skylight;
    public Setting<Boolean> barriers;
    public Setting<Boolean> blocks;
    public Setting<Boolean> pigmen;
    public Setting<Boolean> timeChange;
    public Setting<Integer> time;
    
    public NoRender() {
        super("NoRender", "Allows you to stop rendering stuff", Category.RENDER, true, false, false);
        this.portal = (Setting<Boolean>)this.register(new Setting("Portal", (T)false));
        this.pumpkin = (Setting<Boolean>)this.register(new Setting("Pumpkin", (T)false));
        this.totemPops = (Setting<Boolean>)this.register(new Setting("TotemPop", (T)false));
        this.items = (Setting<Boolean>)this.register(new Setting("Items", (T)false));
        this.nausea = (Setting<Boolean>)this.register(new Setting("Nausea", (T)false));
        this.hurtcam = (Setting<Boolean>)this.register(new Setting("HurtCam", (T)false));
        this.fog = (Setting<Fog>)this.register(new Setting("Fog", (T)Fog.NONE));
        this.noWeather = (Setting<Boolean>)this.register(new Setting("Weather", (T)false));
        this.boss = (Setting<Boss>)this.register(new Setting("BossBars", (T)Boss.NONE));
        this.scale = (Setting<Float>)this.register(new Setting("Scale", (T)0.0f, (T)0.5f, (T)1.0f, a1 -> this.boss.getValue() == Boss.MINIMIZE || this.boss.getValue() != Boss.STACK, "Scale of the bars."));
        this.bats = (Setting<Boolean>)this.register(new Setting("Bats", (T)false));
        this.noArmor = (Setting<NoArmor>)this.register(new Setting("NoArmor", (T)NoArmor.NONE));
        this.skylight = (Setting<Skylight>)this.register(new Setting("Skylight", (T)Skylight.NONE));
        this.barriers = (Setting<Boolean>)this.register(new Setting("Barriers", (T)false));
        this.blocks = (Setting<Boolean>)this.register(new Setting("Blocks", (T)false));
        this.pigmen = (Setting<Boolean>)this.register(new Setting("Pigmen", (T)false));
        this.timeChange = (Setting<Boolean>)this.register(new Setting("TimeChange", (T)false));
        this.time = (Setting<Integer>)this.register(new Setting("Time", (T)0, (T)0, (T)23000, a1 -> this.timeChange.getValue()));
        this.setInstance();
    }
    
    public static NoRender getInstance() {
        /*SL:98*/if (NoRender.INSTANCE == null) {
            NoRender.INSTANCE = /*EL:99*/new NoRender();
        }
        /*SL:101*/return NoRender.INSTANCE;
    }
    
    private void setInstance() {
        NoRender.INSTANCE = /*EL:105*/this;
    }
    
    @Override
    public void onUpdate() {
        /*SL:110*/if (this.items.getValue()) {
            NoRender.mc.field_71441_e.field_72996_f.stream().filter(/*EL:111*/EntityItem.class::isInstance).map(EntityItem.class::cast).forEach(Entity::func_70106_y);
        }
        /*SL:113*/if (this.noWeather.getValue() && NoRender.mc.field_71441_e.func_72896_J()) {
            NoRender.mc.field_71441_e.func_72894_k(/*EL:114*/0.0f);
        }
        /*SL:116*/if (this.timeChange.getValue()) {
            NoRender.mc.field_71441_e.func_72877_b(/*EL:117*/(long)this.time.getValue());
        }
    }
    
    @SubscribeEvent
    public void onPacketReceive(final PacketEvent.Receive a1) {
        /*SL:123*/if (a1.getPacket() instanceof SPacketTimeUpdate & this.timeChange.getValue()) {
            /*SL:124*/a1.setCanceled(true);
        }
    }
    
    public void doVoidFogParticles(final int a3, final int v1, final int v2) {
        final int v3 = /*EL:129*/32;
        final Random v4 = /*EL:130*/new Random();
        final ItemStack v5 = NoRender.mc.field_71439_g.func_184614_ca();
        final boolean v6 = /*EL:132*/!this.barriers.getValue() || (NoRender.mc.field_71442_b.func_178889_l() == GameType.CREATIVE && !v5.func_190926_b() && v5.func_77973_b() == Item.func_150898_a(Blocks.field_180401_cv));
        final BlockPos.MutableBlockPos v7 = /*EL:133*/new BlockPos.MutableBlockPos();
        /*SL:134*/for (int a4 = 0; a4 < 667; ++a4) {
            /*SL:135*/this.showBarrierParticles(a3, v1, v2, 16, v4, v6, v7);
            /*SL:136*/this.showBarrierParticles(a3, v1, v2, 32, v4, v6, v7);
        }
    }
    
    public void showBarrierParticles(final int a1, final int a2, final int a3, final int a4, final Random a5, final boolean a6, final BlockPos.MutableBlockPos a7) {
        final int v1 = /*EL:141*/a1 + NoRender.mc.field_71441_e.field_73012_v.nextInt(a4) - NoRender.mc.field_71441_e.field_73012_v.nextInt(a4);
        final int v2 = /*EL:142*/a2 + NoRender.mc.field_71441_e.field_73012_v.nextInt(a4) - NoRender.mc.field_71441_e.field_73012_v.nextInt(a4);
        final int v3 = /*EL:143*/a3 + NoRender.mc.field_71441_e.field_73012_v.nextInt(a4) - NoRender.mc.field_71441_e.field_73012_v.nextInt(a4);
        /*SL:144*/a7.func_181079_c(v1, v2, v3);
        final IBlockState v4 = NoRender.mc.field_71441_e.func_180495_p(/*EL:145*/(BlockPos)a7);
        /*SL:146*/v4.func_177230_c().func_180655_c(v4, (World)NoRender.mc.field_71441_e, (BlockPos)a7, a5);
        /*SL:147*/if (!a6 && v4.func_177230_c() == Blocks.field_180401_cv) {
            NoRender.mc.field_71441_e.func_175688_a(EnumParticleTypes.BARRIER, /*EL:148*/(double)(v1 + 0.5f), (double)(v2 + 0.5f), (double)(v3 + 0.5f), 0.0, 0.0, 0.0, new int[0]);
        }
    }
    
    @SubscribeEvent
    public void onRenderPre(final RenderGameOverlayEvent.Pre a1) {
        /*SL:154*/if (a1.getType() == RenderGameOverlayEvent.ElementType.BOSSINFO && this.boss.getValue() != Boss.NONE) {
            /*SL:155*/a1.setCanceled(true);
        }
    }
    
    @SubscribeEvent
    public void onRenderPost(final RenderGameOverlayEvent.Post v-7) {
        /*SL:161*/if (v-7.getType() == RenderGameOverlayEvent.ElementType.BOSSINFO && this.boss.getValue() != Boss.NONE) {
            /*SL:162*/if (this.boss.getValue() == Boss.MINIMIZE) {
                final Map<UUID, BossInfoClient> map = (Map<UUID, BossInfoClient>)NoRender.mc.field_71456_v.func_184046_j().field_184060_g;
                /*SL:164*/if (map == null) {
                    /*SL:165*/return;
                }
                final ScaledResolution scaledResolution = /*EL:167*/new ScaledResolution(NoRender.mc);
                final int func_78326_a = /*EL:168*/scaledResolution.func_78326_a();
                int func_78326_a2 = /*EL:169*/12;
                /*SL:170*/for (final Map.Entry<UUID, BossInfoClient> entry : map.entrySet()) {
                    final BossInfoClient a1 = /*EL:171*/entry.getValue();
                    final String v1 = /*EL:172*/a1.func_186744_e().func_150254_d();
                    final int v2 = /*EL:173*/(int)(func_78326_a / this.scale.getValue() / 2.0f - 91.0f);
                    /*SL:174*/GL11.glScaled((double)this.scale.getValue(), (double)this.scale.getValue(), 1.0);
                    /*SL:175*/if (!v-7.isCanceled()) {
                        /*SL:176*/GlStateManager.func_179131_c(1.0f, 1.0f, 1.0f, 1.0f);
                        NoRender.mc.func_110434_K().func_110577_a(GuiBossOverlay.field_184058_a);
                        NoRender.mc.field_71456_v.func_184046_j().func_184052_a(/*EL:178*/v2, func_78326_a2, (BossInfo)a1);
                        NoRender.mc.field_71466_p.func_175063_a(/*EL:179*/v1, func_78326_a / this.scale.getValue() / 2.0f - NoRender.mc.field_71466_p.func_78256_a(v1) / 2, (float)(func_78326_a2 - 9), 16777215);
                    }
                    /*SL:181*/GL11.glScaled(1.0 / this.scale.getValue(), 1.0 / this.scale.getValue(), 1.0);
                    /*SL:182*/func_78326_a2 += 10 + NoRender.mc.field_71466_p.field_78288_b;
                }
            }
            else/*SL:185*/ if (this.boss.getValue() == Boss.STACK) {
                final Map<UUID, BossInfoClient> map = (Map<UUID, BossInfoClient>)NoRender.mc.field_71456_v.func_184046_j().field_184060_g;
                final HashMap<String, Pair<BossInfoClient, Integer>> hashMap = /*EL:187*/new HashMap<String, Pair<BossInfoClient, Integer>>();
                /*SL:188*/for (final Map.Entry<UUID, BossInfoClient> entry2 : map.entrySet()) {
                    final String func_150254_d = /*EL:189*/entry2.getValue().func_186744_e().func_150254_d();
                    /*SL:190*/if (hashMap.containsKey(func_150254_d)) {
                        Pair<BossInfoClient, Integer> pair = /*EL:191*/hashMap.get(func_150254_d);
                        /*SL:192*/pair = new Pair<BossInfoClient, Integer>(pair.getKey(), pair.getValue() + 1);
                        /*SL:193*/hashMap.put(func_150254_d, pair);
                    }
                    else {
                        final Pair<BossInfoClient, Integer> pair = /*EL:196*/new Pair<BossInfoClient, Integer>(entry2.getValue(), 1);
                        /*SL:197*/hashMap.put(func_150254_d, pair);
                    }
                }
                final ScaledResolution scaledResolution2 = /*EL:200*/new ScaledResolution(NoRender.mc);
                final int func_78326_a2 = /*EL:201*/scaledResolution2.func_78326_a();
                int n = /*EL:202*/12;
                /*SL:203*/for (final Map.Entry<String, Pair<BossInfoClient, Integer>> a2 : hashMap.entrySet()) {
                    String v1 = /*EL:204*/a2.getKey();
                    final BossInfoClient v3 = /*EL:205*/a2.getValue().getKey();
                    final int v4 = /*EL:206*/a2.getValue().getValue();
                    /*SL:207*/v1 = v1 + " x" + v4;
                    final int v5 = /*EL:208*/(int)(func_78326_a2 / this.scale.getValue() / 2.0f - 91.0f);
                    /*SL:209*/GL11.glScaled((double)this.scale.getValue(), (double)this.scale.getValue(), 1.0);
                    /*SL:210*/if (!v-7.isCanceled()) {
                        /*SL:211*/GlStateManager.func_179131_c(1.0f, 1.0f, 1.0f, 1.0f);
                        NoRender.mc.func_110434_K().func_110577_a(GuiBossOverlay.field_184058_a);
                        NoRender.mc.field_71456_v.func_184046_j().func_184052_a(/*EL:213*/v5, n, (BossInfo)v3);
                        NoRender.mc.field_71466_p.func_175063_a(/*EL:214*/v1, func_78326_a2 / this.scale.getValue() / 2.0f - NoRender.mc.field_71466_p.func_78256_a(v1) / 2, (float)(n - 9), 16777215);
                    }
                    /*SL:216*/GL11.glScaled(1.0 / this.scale.getValue(), 1.0 / this.scale.getValue(), 1.0);
                    /*SL:217*/n += 10 + NoRender.mc.field_71466_p.field_78288_b;
                }
            }
        }
    }
    
    @SubscribeEvent
    public void onRenderLiving(final RenderLivingEvent.Pre<?> a1) {
        /*SL:225*/if (this.bats.getValue() && a1.getEntity() instanceof EntityBat) {
            /*SL:226*/a1.setCanceled(true);
        }
    }
    
    @SubscribeEvent
    public void onPlaySound(final PlaySoundAtEntityEvent a1) {
        /*SL:232*/if ((this.bats.getValue() && a1.getSound().equals(SoundEvents.field_187740_w)) || a1.getSound().equals(SoundEvents.field_187742_x) || a1.getSound().equals(SoundEvents.field_187743_y) || a1.getSound().equals(SoundEvents.field_189108_z) || a1.getSound().equals(SoundEvents.field_187744_z)) {
            /*SL:233*/a1.setVolume(0.0f);
            /*SL:234*/a1.setPitch(0.0f);
            /*SL:235*/a1.setCanceled(true);
        }
    }
    
    static {
        NoRender.INSTANCE = new NoRender();
        NoRender.INSTANCE = new NoRender();
    }
    
    public enum Skylight
    {
        NONE, 
        WORLD, 
        ENTITY, 
        ALL;
    }
    
    public enum Fog
    {
        NONE, 
        AIR, 
        NOFOG;
    }
    
    public enum Boss
    {
        NONE, 
        REMOVE, 
        STACK, 
        MINIMIZE;
    }
    
    public enum NoArmor
    {
        NONE, 
        ALL, 
        HELMET;
    }
    
    public static class Pair<T, S>
    {
        private T key;
        private S value;
        
        public Pair(final T a1, final S a2) {
            this.key = a1;
            this.value = a2;
        }
        
        public T getKey() {
            /*SL:250*/return this.key;
        }
        
        public void setKey(final T a1) {
            /*SL:254*/this.key = a1;
        }
        
        public S getValue() {
            /*SL:258*/return this.value;
        }
        
        public void setValue(final S a1) {
            /*SL:262*/this.value = a1;
        }
    }
}
