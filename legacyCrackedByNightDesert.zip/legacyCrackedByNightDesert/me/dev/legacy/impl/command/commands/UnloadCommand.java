package me.dev.legacy.impl.command.commands;

import me.dev.legacy.Legacy;
import me.dev.legacy.impl.command.Command;

public class UnloadCommand extends Command
{
    public UnloadCommand() {
        super("unload", new String[0]);
    }
    
    @Override
    public void execute(final String[] a1) {
        /*SL:14*/Legacy.unload(true);
    }
}
