package me.dev.legacy.impl.command.commands;

import java.util.Iterator;
import com.mojang.realmsclient.gui.ChatFormatting;
import me.dev.legacy.Legacy;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.Arrays;
import java.util.List;
import java.io.File;
import me.dev.legacy.impl.command.Command;

public class ConfigCommand extends Command
{
    public ConfigCommand() {
        super("config", new String[] { "<save/load>" });
    }
    
    @Override
    public void execute(final String[] v0) {
        /*SL:18*/if (v0.length == 1) {
            /*SL:19*/Command.sendMessage("You`ll find the config files in your gameProfile directory under legacy/config");
            /*SL:20*/return;
        }
        /*SL:22*/if (v0.length == 2) {
            /*SL:23*/if ("list".equals(v0[0])) {
                String v = /*EL:24*/"Configs: ";
                final File v2 = /*EL:25*/new File("legacy/");
                final List<File> v3 = /*EL:26*/Arrays.<File>stream(v2.listFiles()).filter(File::isDirectory).filter(a1 -> !a1.getName().equals("util")).<List<File>, ?>collect((Collector<? super File, ?, List<File>>)Collectors.<? super File>toList());
                final StringBuilder v4 = /*EL:27*/new StringBuilder(v);
                /*SL:28*/for (final File a2 : v3) {
                    /*SL:29*/v4.append(a2.getName() + ", ");
                }
                /*SL:30*/v = v4.toString();
                /*SL:31*/Command.sendMessage(v);
            }
            else {
                /*SL:33*/Command.sendMessage("Not a valid command... Possible usage: <list>");
            }
        }
        /*SL:35*/if (v0.length >= 3) {
            final String s = /*EL:36*/v0[0];
            switch (s) {
                case "save": {
                    Legacy.configManager.saveConfig(/*EL:38*/v0[1]);
                    /*SL:39*/Command.sendMessage(ChatFormatting.GREEN + "Config '" + v0[1] + "' has been saved.");
                }
                case "load": {
                    /*SL:42*/if (Legacy.configManager.configExists(v0[1])) {
                        Legacy.configManager.loadConfig(/*EL:43*/v0[1]);
                        /*SL:44*/Command.sendMessage(ChatFormatting.GREEN + "Config '" + v0[1] + "' has been loaded.");
                    }
                    else {
                        /*SL:46*/Command.sendMessage(ChatFormatting.RED + "Config '" + v0[1] + "' does not exist.");
                    }
                }
                default: {
                    /*SL:50*/Command.sendMessage("Not a valid command... Possible usage: <save/load>");
                    break;
                }
            }
        }
    }
}
