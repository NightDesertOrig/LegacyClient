package me.dev.legacy.impl.command.commands;

import com.mojang.realmsclient.gui.ChatFormatting;
import net.minecraftforge.fml.common.ObfuscationReflectionHelper;
import net.minecraft.client.audio.SoundHandler;
import net.minecraft.client.audio.SoundManager;
import me.dev.legacy.impl.command.Command;

public class ReloadSoundCommand extends Command
{
    public ReloadSoundCommand() {
        super("sound", new String[0]);
    }
    
    @Override
    public void execute(final String[] v0) {
        try {
            final SoundManager a1 = /*EL:21*/(SoundManager)ObfuscationReflectionHelper.getPrivateValue((Class)SoundHandler.class, (Object)ReloadSoundCommand.mc.func_147118_V(), new String[] { "sndManager", "sndManager" });
            /*SL:22*/a1.func_148596_a();
            /*SL:23*/Command.sendMessage(ChatFormatting.GREEN + "Reloaded Sound System.");
        }
        catch (Exception v) {
            System.out.println(ChatFormatting.RED + /*EL:25*/"Could not restart sound manager: " + v.toString());
            /*SL:26*/v.printStackTrace();
            /*SL:27*/Command.sendMessage(ChatFormatting.RED + "Couldnt Reload Sound System!");
        }
    }
}
