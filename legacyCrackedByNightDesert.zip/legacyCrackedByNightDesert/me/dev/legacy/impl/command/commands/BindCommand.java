package me.dev.legacy.impl.command.commands;

import me.dev.legacy.modules.Module;
import me.dev.legacy.impl.setting.Bind;
import org.lwjgl.input.Keyboard;
import com.mojang.realmsclient.gui.ChatFormatting;
import me.dev.legacy.Legacy;
import me.dev.legacy.impl.command.Command;

public class BindCommand extends Command
{
    public BindCommand() {
        super("bind", new String[] { "<module>", "<bind>" });
    }
    
    @Override
    public void execute(final String[] a1) {
        /*SL:18*/if (a1.length == 1) {
            /*SL:19*/Command.sendMessage("Please specify a module.");
            /*SL:20*/return;
        }
        final String v1 = /*EL:22*/a1[1];
        final String v2 = /*EL:23*/a1[0];
        final Module v3 = Legacy.moduleManager.getModuleByName(/*EL:24*/v2);
        /*SL:25*/if (v3 == null) {
            /*SL:26*/Command.sendMessage("Unknown module '" + v3 + "'!");
            /*SL:27*/return;
        }
        /*SL:29*/if (v1 == null) {
            /*SL:30*/Command.sendMessage(v3.getName() + " is bound to " + ChatFormatting.GRAY + v3.getBind().toString());
            /*SL:31*/return;
        }
        int v4 = /*EL:33*/Keyboard.getKeyIndex(v1.toUpperCase());
        /*SL:34*/if (v1.equalsIgnoreCase("none")) {
            /*SL:35*/v4 = -1;
        }
        /*SL:37*/if (v4 == 0) {
            /*SL:38*/Command.sendMessage("Unknown key '" + v1 + "'!");
            /*SL:39*/return;
        }
        /*SL:41*/v3.bind.setValue(new Bind(v4));
        /*SL:42*/Command.sendMessage("Bind for " + ChatFormatting.GREEN + v3.getName() + ChatFormatting.WHITE + " set to " + ChatFormatting.GRAY + v1.toUpperCase());
    }
}
