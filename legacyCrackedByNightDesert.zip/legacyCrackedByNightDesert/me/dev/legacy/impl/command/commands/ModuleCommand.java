package me.dev.legacy.impl.command.commands;

import java.util.Iterator;
import me.dev.legacy.api.AbstractModule;
import me.dev.legacy.api.manager.ConfigManager;
import com.google.gson.JsonParser;
import me.dev.legacy.impl.setting.Setting;
import com.mojang.realmsclient.gui.ChatFormatting;
import me.dev.legacy.modules.Module;
import me.dev.legacy.Legacy;
import me.dev.legacy.impl.command.Command;

public class ModuleCommand extends Command
{
    public ModuleCommand() {
        super("module", new String[] { "<module>", "<set/reset>", "<setting>", "<value>" });
    }
    
    @Override
    public void execute(final String[] v-3) {
        /*SL:20*/if (v-3.length == 1) {
            /*SL:21*/Command.sendMessage("Modules: ");
            /*SL:22*/for (final Module.Category v0 : Legacy.moduleManager.getCategories()) {
                String v = /*EL:23*/v0.getName() + ": ";
                /*SL:24*/for (final Module a1 : Legacy.moduleManager.getModulesByCategory(v0)) {
                    /*SL:25*/v = v + (a1.isEnabled() ? ChatFormatting.GREEN : ChatFormatting.RED) + a1.getName() + ChatFormatting.WHITE + ", ";
                }
                /*SL:27*/Command.sendMessage(v);
            }
            /*SL:29*/return;
        }
        Module v5 = Legacy.moduleManager.getModuleByDisplayName(/*EL:31*/v-3[0]);
        /*SL:32*/if (v5 == null) {
            /*SL:33*/v5 = Legacy.moduleManager.getModuleByName(v-3[0]);
            /*SL:34*/if (v5 == null) {
                /*SL:35*/Command.sendMessage("This module doesnt exist.");
                /*SL:36*/return;
            }
            /*SL:38*/Command.sendMessage(" This is the original name of the module. Its current name is: " + v5.getDisplayName());
        }
        else {
            /*SL:41*/if (v-3.length == 2) {
                /*SL:42*/Command.sendMessage(v5.getDisplayName() + " : " + v5.getDescription());
                /*SL:43*/for (final Setting v2 : v5.getSettings()) {
                    /*SL:44*/Command.sendMessage(v2.getName() + " : " + v2.getValue() + ", " + v2.getDescription());
                }
                /*SL:46*/return;
            }
            /*SL:48*/if (v-3.length == 3) {
                /*SL:49*/if (v-3[1].equalsIgnoreCase("set")) {
                    /*SL:50*/Command.sendMessage("Please specify a setting.");
                }
                else/*SL:51*/ if (v-3[1].equalsIgnoreCase("reset")) {
                    /*SL:52*/for (final Setting v2 : v5.getSettings()) {
                        /*SL:53*/v2.setValue(v2.getDefaultValue());
                    }
                }
                else {
                    /*SL:56*/Command.sendMessage("This command doesnt exist.");
                }
                /*SL:58*/return;
            }
            /*SL:60*/if (v-3.length == 4) {
                /*SL:61*/Command.sendMessage("Please specify a value.");
                /*SL:62*/return;
            }
            final Setting settingByName;
            /*SL:64*/if (v-3.length == 5 && (settingByName = v5.getSettingByName(v-3[2])) != null) {
                final JsonParser v3 = /*EL:65*/new JsonParser();
                /*SL:66*/if (settingByName.getType().equalsIgnoreCase("String")) {
                    /*SL:67*/settingByName.setValue(v-3[3]);
                    /*SL:68*/Command.sendMessage(ChatFormatting.DARK_GRAY + v5.getName() + " " + settingByName.getName() + " has been set to " + v-3[3] + ".");
                    /*SL:69*/return;
                }
                try {
                    /*SL:72*/if (settingByName.getName().equalsIgnoreCase("Enabled")) {
                        /*SL:73*/if (v-3[3].equalsIgnoreCase("true")) {
                            /*SL:74*/v5.enable();
                        }
                        /*SL:76*/if (v-3[3].equalsIgnoreCase("false")) {
                            /*SL:77*/v5.disable();
                        }
                    }
                    /*SL:80*/ConfigManager.setValueFromJson(v5, settingByName, v3.parse(v-3[3]));
                }
                catch (Exception v4) {
                    /*SL:82*/Command.sendMessage("Bad Value! This setting requires a: " + settingByName.getType() + " value.");
                    /*SL:83*/return;
                }
                /*SL:85*/Command.sendMessage(ChatFormatting.GRAY + v5.getName() + " " + settingByName.getName() + " has been set to " + v-3[3] + ".");
            }
        }
    }
}
