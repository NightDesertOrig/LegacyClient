package me.dev.legacy.impl.gui;

import java.io.IOException;
import org.lwjgl.input.Mouse;
import java.util.Iterator;
import java.util.function.Function;
import me.dev.legacy.impl.gui.components.items.Item;
import java.util.Comparator;
import me.dev.legacy.api.AbstractModule;
import me.dev.legacy.impl.gui.components.items.buttons.Button;
import me.dev.legacy.impl.gui.components.items.buttons.ModuleButton;
import me.dev.legacy.modules.Module;
import me.dev.legacy.Legacy;
import me.dev.legacy.impl.gui.components.Component;
import java.util.ArrayList;
import net.minecraft.client.gui.GuiScreen;

public class LegacyGui extends GuiScreen
{
    private static LegacyGui INSTANCE;
    private final ArrayList<Component> components;
    
    public LegacyGui() {
        this.components = new ArrayList<Component>();
        this.setInstance();
        this.load();
    }
    
    public static LegacyGui getInstance() {
        /*SL:32*/if (LegacyGui.INSTANCE == null) {
            LegacyGui.INSTANCE = /*EL:33*/new LegacyGui();
        }
        /*SL:35*/return LegacyGui.INSTANCE;
    }
    
    public static LegacyGui getClickGui() {
        /*SL:39*/return getInstance();
    }
    
    private void setInstance() {
        LegacyGui.INSTANCE = /*EL:43*/this;
    }
    
    private void load() {
        int a2 = /*EL:47*/-84;
        /*SL:48*/for (final Module.Category v1 : Legacy.moduleManager.getCategories()) {
            final ArrayList<Component> components = /*EL:49*/this.components;
            final String name = v1.getName();
            a2 += 110;
            components.add(new Component(name, a2, 4, true) {
                @Override
                public void setupItems() {
                    LegacyGui$1.counter1 = /*EL:53*/new int[] { 1 };
                    Legacy.moduleManager.getModulesByCategory(/*EL:59*/v1).forEach(a1 -> {
                        if (!a1.hidden) {
                            this.addButton(new ModuleButton(a1));
                        }
                    });
                }
            });
        }
        /*SL:62*/this.components.forEach(a1 -> a1.getItems().sort(Comparator.<? super Item, Comparable>comparing((Function<? super Item, ? extends Comparable>)AbstractModule::getName)));
    }
    
    public void updateModule(final Module v-5) {
        /*SL:66*/for (final Component component : this.components) {
            /*SL:67*/for (final Item item : component.getItems()) {
                /*SL:68*/if (!(item instanceof ModuleButton)) {
                    continue;
                }
                final ModuleButton a1 = /*EL:69*/(ModuleButton)item;
                final Module v1 = /*EL:70*/a1.getModule();
                /*SL:71*/if (v-5 == null) {
                    continue;
                }
                if (!v-5.equals(v1)) {
                    continue;
                }
                /*SL:72*/a1.initSettings();
            }
        }
    }
    
    public void func_73863_a(final int a1, final int a2, final float a3) {
        /*SL:78*/this.checkMouseWheel();
        /*SL:79*/this.func_146276_q_();
        /*SL:80*/this.components.forEach(a4 -> a4.drawScreen(a1, a2, a3));
    }
    
    public void func_73864_a(final int a1, final int a2, final int a3) {
        /*SL:84*/this.components.forEach(a4 -> a4.mouseClicked(a1, a2, a3));
    }
    
    public void func_146286_b(final int a1, final int a2, final int a3) {
        /*SL:88*/this.components.forEach(a4 -> a4.mouseReleased(a1, a2, a3));
    }
    
    public boolean func_73868_f() {
        /*SL:92*/return false;
    }
    
    public final ArrayList<Component> getComponents() {
        /*SL:96*/return this.components;
    }
    
    public void checkMouseWheel() {
        final int v1 = /*EL:100*/Mouse.getDWheel();
        /*SL:101*/if (v1 < 0) {
            /*SL:102*/this.components.forEach(a1 -> a1.setY(a1.getY() - 10));
        }
        else/*SL:103*/ if (v1 > 0) {
            /*SL:104*/this.components.forEach(a1 -> a1.setY(a1.getY() + 10));
        }
    }
    
    public int getTextOffset() {
        /*SL:109*/return -6;
    }
    
    public Component getComponentByName(final String v2) {
        /*SL:113*/for (final Component a1 : this.components) {
            /*SL:114*/if (!a1.getName().equalsIgnoreCase(v2)) {
                continue;
            }
            /*SL:115*/return a1;
        }
        /*SL:117*/return null;
    }
    
    public void func_73869_a(final char a1, final int a2) throws IOException {
        /*SL:121*/super.func_73869_a(a1, a2);
        /*SL:122*/this.components.forEach(a3 -> a3.onKeyTyped(a1, a2));
    }
    
    static {
        LegacyGui.INSTANCE = new LegacyGui();
    }
}
