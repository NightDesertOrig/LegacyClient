package me.dev.legacy.impl.gui.components.items.buttons;

import net.minecraft.client.audio.ISound;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.init.SoundEvents;
import me.dev.legacy.impl.gui.components.Component;
import me.dev.legacy.impl.gui.LegacyGui;
import me.dev.legacy.modules.client.ClickGui;
import java.util.Iterator;
import me.dev.legacy.impl.setting.Bind;
import me.dev.legacy.impl.setting.Setting;
import org.lwjgl.opengl.GL11;
import java.util.ArrayList;
import me.dev.legacy.impl.gui.components.items.Item;
import java.util.List;
import net.minecraft.util.ResourceLocation;
import me.dev.legacy.modules.Module;

public class ModuleButton extends Button
{
    private final Module module;
    private final ResourceLocation logo;
    private List<Item> items;
    private boolean subOpen;
    
    public ModuleButton(final Module a1) {
        super(a1.getName());
        this.logo = new ResourceLocation("textures/legacy.png");
        this.items = new ArrayList<Item>();
        this.module = a1;
        this.initSettings();
    }
    
    public static void drawCompleteImage(final float a1, final float a2, final int a3, final int a4) {
        /*SL:32*/GL11.glPushMatrix();
        /*SL:33*/GL11.glTranslatef(a1, a2, 0.0f);
        /*SL:34*/GL11.glBegin(7);
        /*SL:35*/GL11.glTexCoord2f(0.0f, 0.0f);
        /*SL:36*/GL11.glVertex3f(0.0f, 0.0f, 0.0f);
        /*SL:37*/GL11.glTexCoord2f(0.0f, 1.0f);
        /*SL:38*/GL11.glVertex3f(0.0f, (float)a4, 0.0f);
        /*SL:39*/GL11.glTexCoord2f(1.0f, 1.0f);
        /*SL:40*/GL11.glVertex3f((float)a3, (float)a4, 0.0f);
        /*SL:41*/GL11.glTexCoord2f(1.0f, 0.0f);
        /*SL:42*/GL11.glVertex3f((float)a3, 0.0f, 0.0f);
        /*SL:43*/GL11.glEnd();
        /*SL:44*/GL11.glPopMatrix();
    }
    
    public void initSettings() {
        final ArrayList<Item> items = /*EL:48*/new ArrayList<Item>();
        /*SL:49*/if (!this.module.getSettings().isEmpty()) {
            /*SL:50*/for (final Setting v1 : this.module.getSettings()) {
                /*SL:51*/if (v1.getValue() instanceof Boolean && !v1.getName().equals("Enabled")) {
                    /*SL:52*/items.add(new BooleanButton(v1));
                }
                /*SL:54*/if (v1.getValue() instanceof Bind && !v1.getName().equalsIgnoreCase("Keybind") && !this.module.getName().equalsIgnoreCase("Hud")) {
                    /*SL:55*/items.add(new BindButton(v1));
                }
                /*SL:57*/if ((v1.getValue() instanceof String || v1.getValue() instanceof Character) && !v1.getName().equalsIgnoreCase("displayName")) {
                    /*SL:58*/items.add(new StringButton(v1));
                }
                /*SL:60*/if (v1.isNumberSetting() && v1.hasRestriction()) {
                    /*SL:61*/items.add(new Slider(v1));
                }
                else {
                    /*SL:64*/if (!v1.isEnumSetting()) {
                        continue;
                    }
                    /*SL:65*/items.add(new EnumButton(v1));
                }
            }
        }
        /*SL:68*/items.add(new BindButton(this.module.getSettingByName("Keybind")));
        /*SL:69*/this.items = items;
    }
    
    @Override
    public void drawScreen(final int v1, final int v2, final float v3) {
        /*SL:74*/super.drawScreen(v1, v2, v3);
        /*SL:75*/if (!this.items.isEmpty()) {
            /*SL:76*/if (ClickGui.getInstance().gears.getValue()) {
                ModuleButton.mc.func_110434_K().func_110577_a(/*EL:77*/this.logo);
                drawCompleteImage(/*EL:78*/this.x - 1.5f + this.width - 7.4f + 16.0f, this.y - 2.2f - LegacyGui.getClickGui().getTextOffset() - 2.0f, 12, 12);
            }
            /*SL:80*/if (this.subOpen) {
                float a2 = /*EL:81*/1.0f;
                final Iterator<Item> iterator = /*EL:82*/this.items.iterator();
                while (iterator.hasNext()) {
                    a2 = iterator.next();
                    /*SL:83*/++Component.counter1[0];
                    /*SL:84*/if (!a2.isHidden()) {
                        /*SL:85*/a2.setLocation(this.x + 1.0f, this.y + (a2 += 15.0f));
                        /*SL:86*/a2.setHeight(15);
                        /*SL:87*/a2.setWidth(this.width - 9);
                        /*SL:88*/a2.drawScreen(v1, v2, v3);
                    }
                    /*SL:90*/a2.update();
                }
            }
        }
    }
    
    @Override
    public void mouseClicked(final int a3, final int v1, final int v2) {
        /*SL:98*/super.mouseClicked(a3, v1, v2);
        /*SL:99*/if (!this.items.isEmpty()) {
            /*SL:100*/if (v2 == 1 && this.isHovering(a3, v1)) {
                /*SL:101*/this.subOpen = !this.subOpen;
                ModuleButton.mc.func_147118_V().func_147682_a(/*EL:102*/(ISound)PositionedSoundRecord.func_184371_a(SoundEvents.field_187909_gi, 1.0f));
            }
            /*SL:104*/if (this.subOpen) {
                /*SL:105*/for (final Item a4 : this.items) {
                    /*SL:106*/if (a4.isHidden()) {
                        continue;
                    }
                    /*SL:107*/a4.mouseClicked(a3, v1, v2);
                }
            }
        }
    }
    
    @Override
    public void onKeyTyped(final char v1, final int v2) {
        /*SL:115*/super.onKeyTyped(v1, v2);
        /*SL:116*/if (!this.items.isEmpty() && this.subOpen) {
            /*SL:117*/for (final Item a1 : this.items) {
                /*SL:118*/if (a1.isHidden()) {
                    continue;
                }
                /*SL:119*/a1.onKeyTyped(v1, v2);
            }
        }
    }
    
    @Override
    public int getHeight() {
        /*SL:126*/if (this.subOpen) {
            int n = /*EL:127*/14;
            /*SL:128*/for (final Item v1 : this.items) {
                /*SL:129*/if (v1.isHidden()) {
                    continue;
                }
                /*SL:130*/n += v1.getHeight() + 1;
            }
            /*SL:132*/return n + 2;
        }
        /*SL:134*/return 14;
    }
    
    public Module getModule() {
        /*SL:138*/return this.module;
    }
    
    @Override
    public void toggle() {
        /*SL:143*/this.module.toggle();
    }
    
    @Override
    public boolean getState() {
        /*SL:148*/return this.module.isEnabled();
    }
}
