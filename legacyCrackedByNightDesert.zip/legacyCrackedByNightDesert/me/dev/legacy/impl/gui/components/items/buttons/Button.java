package me.dev.legacy.impl.gui.components.items.buttons;

import java.util.Iterator;
import me.dev.legacy.impl.gui.components.Component;
import net.minecraft.client.audio.ISound;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.init.SoundEvents;
import me.dev.legacy.impl.gui.LegacyGui;
import me.dev.legacy.api.util.RenderUtil;
import me.dev.legacy.Legacy;
import me.dev.legacy.api.util.ColorUtil;
import me.dev.legacy.modules.client.ClickGui;
import me.dev.legacy.impl.gui.components.items.Item;

public class Button extends Item
{
    private boolean state;
    
    public Button(final String a1) {
        super(a1);
        this.height = 15;
    }
    
    @Override
    public void drawScreen(final int a1, final int a2, final float a3) {
        final int v1 = /*EL:24*/ColorUtil.toARGB(ClickGui.getInstance().fontcolorr.getValue(), ClickGui.getInstance().fontcolorb.getValue(), ClickGui.getInstance().fontcolorb.getValue(), 255);
        /*SL:26*/RenderUtil.drawRect(this.x, this.y, this.x + this.width + 20.0f, this.y + this.height - 0.5f, this.getState() ? (this.isHovering(a1, a2) ? Legacy.colorManager.getColorWithAlpha(Legacy.moduleManager.<ClickGui>getModuleByClass(ClickGui.class).alpha.getValue()) : Legacy.colorManager.getColorWithAlpha(Legacy.moduleManager.<ClickGui>getModuleByClass(ClickGui.class).hoverAlpha.getValue())) : (this.isHovering(a1, a2) ? -2007673515 : 290805077));
        Legacy.textManager.drawStringWithShadow(/*EL:27*/this.getName(), this.x + 2.3f, this.y - 2.0f - LegacyGui.getClickGui().getTextOffset(), this.getState() ? -2 : v1);
    }
    
    @Override
    public void mouseClicked(final int a1, final int a2, final int a3) {
        /*SL:33*/if (a3 == 0 && this.isHovering(a1, a2)) {
            /*SL:34*/this.onMouseClick();
        }
    }
    
    public void onMouseClick() {
        /*SL:39*/this.state = !this.state;
        /*SL:40*/this.toggle();
        Button.mc.func_147118_V().func_147682_a(/*EL:41*/(ISound)PositionedSoundRecord.func_184371_a(SoundEvents.field_187909_gi, 1.0f));
    }
    
    public void toggle() {
    }
    
    public boolean getState() {
        /*SL:48*/return this.state;
    }
    
    @Override
    public int getHeight() {
        /*SL:53*/return 14;
    }
    
    public boolean isHovering(final int v1, final int v2) {
        /*SL:57*/for (final Component a1 : LegacyGui.getClickGui().getComponents()) {
            /*SL:58*/if (!a1.drag) {
                continue;
            }
            /*SL:59*/return false;
        }
        /*SL:61*/return v1 >= this.getX() && v1 <= this.getX() + this.getWidth() && v2 >= this.getY() && v2 <= this.getY() + this.height;
    }
}
