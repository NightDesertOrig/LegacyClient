package me.dev.legacy.impl.gui.components.items.buttons;

import me.dev.legacy.impl.setting.Bind;
import net.minecraft.client.audio.ISound;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.init.SoundEvents;
import com.mojang.realmsclient.gui.ChatFormatting;
import me.dev.legacy.impl.gui.LegacyGui;
import me.dev.legacy.api.util.RenderUtil;
import me.dev.legacy.Legacy;
import me.dev.legacy.api.util.ColorUtil;
import me.dev.legacy.modules.client.ClickGui;
import me.dev.legacy.impl.setting.Setting;

public class BindButton extends Button
{
    private final Setting setting;
    public boolean isListening;
    
    public BindButton(final Setting a1) {
        super(a1.getName());
        this.setting = a1;
        this.width = 15;
    }
    
    @Override
    public void drawScreen(final int a1, final int a2, final float a3) {
        final int v1 = /*EL:27*/ColorUtil.toARGB(ClickGui.getInstance().fontcolorr.getValue(), ClickGui.getInstance().fontcolorb.getValue(), ClickGui.getInstance().fontcolorb.getValue(), 255);
        final int v2 = /*EL:29*/ColorUtil.toARGB(ClickGui.getInstance().red.getValue(), ClickGui.getInstance().green.getValue(), ClickGui.getInstance().blue.getValue(), 255);
        /*SL:30*/RenderUtil.drawRect(this.x, this.y, this.x + this.width + 7.4f + 20.0f, this.y + this.height - 0.5f, this.getState() ? (this.isHovering(a1, a2) ? -2007673515 : 290805077) : (this.isHovering(a1, a2) ? Legacy.colorManager.getColorWithAlpha(Legacy.moduleManager.<ClickGui>getModuleByClass(ClickGui.class).alpha.getValue()) : Legacy.colorManager.getColorWithAlpha(Legacy.moduleManager.<ClickGui>getModuleByClass(ClickGui.class).hoverAlpha.getValue())));
        /*SL:31*/if (this.isListening) {
            Legacy.textManager.drawStringWithShadow(/*EL:32*/"Press a Key...", this.x + 2.3f, this.y - 1.7f - LegacyGui.getClickGui().getTextOffset(), v1);
        }
        else {
            Legacy.textManager.drawStringWithShadow(/*EL:34*/this.setting.getName() + " " + ChatFormatting.GRAY + this.setting.getValue().toString().toUpperCase(), this.x + 2.3f, this.y - 1.7f - LegacyGui.getClickGui().getTextOffset(), this.getState() ? -1 : v1);
        }
    }
    
    @Override
    public void update() {
        /*SL:40*/this.setHidden(!this.setting.isVisible());
    }
    
    @Override
    public void mouseClicked(final int a1, final int a2, final int a3) {
        /*SL:45*/super.mouseClicked(a1, a2, a3);
        /*SL:46*/if (this.isHovering(a1, a2)) {
            BindButton.mc.func_147118_V().func_147682_a(/*EL:47*/(ISound)PositionedSoundRecord.func_184371_a(SoundEvents.field_187909_gi, 1.0f));
        }
    }
    
    @Override
    public void onKeyTyped(final char v1, final int v2) {
        /*SL:53*/if (this.isListening) {
            Bind a1 = /*EL:54*/new Bind(v2);
            /*SL:55*/if (a1.toString().equalsIgnoreCase("Escape")) {
                /*SL:56*/return;
            }
            /*SL:58*/if (a1.toString().equalsIgnoreCase("Delete")) {
                /*SL:59*/a1 = new Bind(-1);
            }
            /*SL:61*/this.setting.setValue(a1);
            /*SL:62*/this.onMouseClick();
        }
    }
    
    @Override
    public int getHeight() {
        /*SL:68*/return 14;
    }
    
    @Override
    public void toggle() {
        /*SL:73*/this.isListening = !this.isListening;
    }
    
    @Override
    public boolean getState() {
        /*SL:78*/return !this.isListening;
    }
}
