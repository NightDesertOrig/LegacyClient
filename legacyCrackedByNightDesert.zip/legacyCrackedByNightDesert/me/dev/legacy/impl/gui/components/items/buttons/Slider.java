package me.dev.legacy.impl.gui.components.items.buttons;

import org.lwjgl.input.Mouse;
import java.util.Iterator;
import me.dev.legacy.impl.gui.components.Component;
import me.dev.legacy.impl.gui.LegacyGui;
import com.mojang.realmsclient.gui.ChatFormatting;
import me.dev.legacy.Legacy;
import me.dev.legacy.api.util.RenderUtil;
import me.dev.legacy.api.util.ColorUtil;
import me.dev.legacy.modules.client.ClickGui;
import me.dev.legacy.impl.setting.Setting;

public class Slider extends Button
{
    private final Number min;
    private final Number max;
    private final int difference;
    public Setting setting;
    
    public Slider(final Setting a1) {
        super(a1.getName());
        this.setting = a1;
        this.min = a1.getMin();
        this.max = a1.getMax();
        this.difference = this.max.intValue() - this.min.intValue();
        this.width = 15;
    }
    
    @Override
    public void drawScreen(final int a1, final int a2, final float a3) {
        final int v1 = /*EL:31*/ColorUtil.toARGB(ClickGui.getInstance().fontcolorr.getValue(), ClickGui.getInstance().fontcolorb.getValue(), ClickGui.getInstance().fontcolorb.getValue(), 255);
        /*SL:33*/this.dragSetting(a1, a2);
        /*SL:34*/RenderUtil.drawRect(this.x + 20.0f, this.y, this.x + this.width + 7.4f + 20.0f, this.y + this.height - 0.5f, this.isHovering(a1, a2) ? -2007673515 : 290805077);
        /*SL:35*/RenderUtil.drawRect(this.x, this.y, (this.setting.getValue().floatValue() <= this.min.floatValue()) ? this.x : (this.x + (this.width + 7.4f + 20.0f) * this.partialMultiplier()), this.y + this.height - 0.5f, this.isHovering(a1, a2) ? Legacy.colorManager.getColorWithAlpha(Legacy.moduleManager.<ClickGui>getModuleByClass(ClickGui.class).alpha.getValue()) : Legacy.colorManager.getColorWithAlpha(Legacy.moduleManager.<ClickGui>getModuleByClass(ClickGui.class).hoverAlpha.getValue()));
        Legacy.textManager.drawStringWithShadow(/*EL:36*/this.getName() + " " + ChatFormatting.GRAY + ((this.setting.getValue() instanceof Float) ? this.setting.getValue() : this.setting.getValue().doubleValue()), this.x + 2.3f, this.y - 1.7f - LegacyGui.getClickGui().getTextOffset(), v1);
    }
    
    @Override
    public void mouseClicked(final int a1, final int a2, final int a3) {
        /*SL:41*/super.mouseClicked(a1, a2, a3);
        /*SL:42*/if (this.isHovering(a1, a2)) {
            /*SL:43*/this.setSettingFromX(a1);
        }
    }
    
    @Override
    public boolean isHovering(final int v1, final int v2) {
        /*SL:49*/for (final Component a1 : LegacyGui.getClickGui().getComponents()) {
            /*SL:50*/if (!a1.drag) {
                continue;
            }
            /*SL:51*/return false;
        }
        /*SL:53*/return v1 >= this.getX() && v1 <= this.getX() + this.getWidth() + 8.0f && v2 >= this.getY() && v2 <= this.getY() + this.height;
    }
    
    @Override
    public void update() {
        /*SL:58*/this.setHidden(!this.setting.isVisible());
    }
    
    private void dragSetting(final int a1, final int a2) {
        /*SL:62*/if (this.isHovering(a1, a2) && Mouse.isButtonDown(0)) {
            /*SL:63*/this.setSettingFromX(a1);
        }
    }
    
    @Override
    public int getHeight() {
        /*SL:69*/return 14;
    }
    
    private void setSettingFromX(final int v-1) {
        final float v0 = /*EL:73*/(v-1 - this.x) / (this.width + 7.4f);
        /*SL:74*/if (this.setting.getValue() instanceof Double) {
            final double a1 = /*EL:75*/this.setting.getMin() + this.difference * v0;
            /*SL:76*/this.setting.setValue(Math.round(10.0 * a1) / 10.0);
        }
        else/*SL:77*/ if (this.setting.getValue() instanceof Float) {
            final float v = /*EL:78*/this.setting.getMin() + this.difference * v0;
            /*SL:79*/this.setting.setValue(Math.round(10.0f * v) / 10.0f);
        }
        else/*SL:80*/ if (this.setting.getValue() instanceof Integer) {
            /*SL:81*/this.setting.setValue(this.setting.getMin() + (int)(this.difference * v0));
        }
    }
    
    private float middle() {
        /*SL:86*/return this.max.floatValue() - this.min.floatValue();
    }
    
    private float part() {
        /*SL:90*/return this.setting.getValue().floatValue() - this.min.floatValue();
    }
    
    private float partialMultiplier() {
        /*SL:94*/return this.part() / this.middle();
    }
}
