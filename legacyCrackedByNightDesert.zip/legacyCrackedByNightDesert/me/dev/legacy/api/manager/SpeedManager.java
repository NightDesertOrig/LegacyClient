package me.dev.legacy.api.manager;

import net.minecraft.util.math.MathHelper;
import java.util.Iterator;
import net.minecraft.entity.Entity;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import java.util.HashMap;
import me.dev.legacy.api.AbstractModule;

public class SpeedManager extends AbstractModule
{
    public static final double LAST_JUMP_INFO_DURATION_DEFAULT = 3.0;
    public static boolean didJumpThisTick;
    public static boolean isJumping;
    private final int distancer = 20;
    public double firstJumpSpeed;
    public double lastJumpSpeed;
    public double percentJumpSpeedChanged;
    public double jumpSpeedChanged;
    public boolean didJumpLastTick;
    public long jumpInfoStartTime;
    public boolean wasFirstJump;
    public double speedometerCurrentSpeed;
    public HashMap<EntityPlayer, Double> playerSpeeds;
    
    public SpeedManager() {
        this.firstJumpSpeed = 0.0;
        this.lastJumpSpeed = 0.0;
        this.percentJumpSpeedChanged = 0.0;
        this.jumpSpeedChanged = 0.0;
        this.didJumpLastTick = false;
        this.jumpInfoStartTime = 0L;
        this.wasFirstJump = true;
        this.speedometerCurrentSpeed = 0.0;
        this.playerSpeeds = new HashMap<EntityPlayer, Double>();
    }
    
    public static void setDidJumpThisTick(final boolean a1) {
        SpeedManager.didJumpThisTick = /*EL:27*/a1;
    }
    
    public static void setIsJumping(final boolean a1) {
        SpeedManager.isJumping = /*EL:31*/a1;
    }
    
    public float lastJumpInfoTimeRemaining() {
        /*SL:35*/return (Minecraft.func_71386_F() - this.jumpInfoStartTime) / 1000.0f;
    }
    
    public void updateValues() {
        final double v1 = SpeedManager.mc.field_71439_g.field_70165_t - SpeedManager.mc.field_71439_g.field_70169_q;
        final double v2 = SpeedManager.mc.field_71439_g.field_70161_v - SpeedManager.mc.field_71439_g.field_70166_s;
        /*SL:41*/this.speedometerCurrentSpeed = v1 * v1 + v2 * v2;
        /*SL:42*/if (SpeedManager.didJumpThisTick && (!SpeedManager.mc.field_71439_g.field_70122_E || SpeedManager.isJumping)) {
            /*SL:43*/if (SpeedManager.didJumpThisTick && !this.didJumpLastTick) {
                /*SL:44*/this.wasFirstJump = (this.lastJumpSpeed == 0.0);
                /*SL:45*/this.percentJumpSpeedChanged = ((this.speedometerCurrentSpeed != 0.0) ? (this.speedometerCurrentSpeed / this.lastJumpSpeed - 1.0) : -1.0);
                /*SL:46*/this.jumpSpeedChanged = this.speedometerCurrentSpeed - this.lastJumpSpeed;
                /*SL:47*/this.jumpInfoStartTime = Minecraft.func_71386_F();
                /*SL:48*/this.lastJumpSpeed = this.speedometerCurrentSpeed;
                /*SL:49*/this.firstJumpSpeed = (this.wasFirstJump ? this.lastJumpSpeed : 0.0);
            }
            /*SL:51*/this.didJumpLastTick = SpeedManager.didJumpThisTick;
        }
        else {
            /*SL:53*/this.didJumpLastTick = false;
            /*SL:54*/this.lastJumpSpeed = 0.0;
        }
        /*SL:56*/this.updatePlayers();
    }
    
    public void updatePlayers() {
        /*SL:60*/for (final EntityPlayer v0 : SpeedManager.mc.field_71441_e.field_73010_i) {
            final double func_70068_e = SpeedManager.mc.field_71439_g.func_70068_e(/*EL:61*/(Entity)v0);
            this.getClass();
            final int n = 20;
            this.getClass();
            if (func_70068_e >= n * 20) {
                /*SL:62*/continue;
            }
            final double v = /*EL:63*/v0.field_70165_t - v0.field_70169_q;
            final double v2 = /*EL:64*/v0.field_70161_v - v0.field_70166_s;
            final double v3 = /*EL:65*/v * v + v2 * v2;
            /*SL:66*/this.playerSpeeds.put(v0, v3);
        }
    }
    
    public double getPlayerSpeed(final EntityPlayer a1) {
        /*SL:71*/if (this.playerSpeeds.get(a1) == null) {
            /*SL:72*/return 0.0;
        }
        /*SL:74*/return this.turnIntoKpH(this.playerSpeeds.get(a1));
    }
    
    public double turnIntoKpH(final double a1) {
        /*SL:78*/return MathHelper.func_76133_a(a1) * 71.2729367892;
    }
    
    public double getSpeedKpH() {
        double v1 = /*EL:82*/this.turnIntoKpH(this.speedometerCurrentSpeed);
        /*SL:83*/v1 = Math.round(10.0 * v1) / 10.0;
        /*SL:84*/return v1;
    }
    
    public double getSpeedMpS() {
        double v1 = /*EL:88*/this.turnIntoKpH(this.speedometerCurrentSpeed) / 3.6;
        /*SL:89*/v1 = Math.round(10.0 * v1) / 10.0;
        /*SL:90*/return v1;
    }
    
    static {
        SpeedManager.didJumpThisTick = false;
        SpeedManager.isJumping = false;
    }
}
