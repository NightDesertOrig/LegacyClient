package me.dev.legacy.api.manager;

import me.dev.legacy.modules.Module;
import java.io.InputStream;
import java.io.Reader;
import java.io.InputStreamReader;
import com.google.gson.JsonParser;
import java.util.Collection;
import com.google.gson.Gson;
import java.nio.file.Path;
import java.io.Writer;
import java.io.BufferedWriter;
import java.io.OutputStreamWriter;
import java.nio.file.OpenOption;
import com.google.gson.GsonBuilder;
import java.nio.file.attribute.FileAttribute;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Paths;
import java.util.Scanner;
import java.io.FileWriter;
import java.io.IOException;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.Arrays;
import java.util.Objects;
import java.io.File;
import java.util.List;
import java.util.Iterator;
import java.util.UUID;
import java.util.Map;
import com.google.gson.JsonObject;
import me.dev.legacy.Legacy;
import me.dev.legacy.impl.setting.EnumConverter;
import me.dev.legacy.impl.setting.Bind;
import com.google.gson.JsonElement;
import me.dev.legacy.impl.setting.Setting;
import me.dev.legacy.api.AbstractModule;
import java.util.ArrayList;
import me.dev.legacy.api.util.Util;

public class ConfigManager implements Util
{
    public ArrayList<AbstractModule> features;
    public String config;
    
    public ConfigManager() {
        this.features = new ArrayList<AbstractModule>();
        this.config = "legacy/config/";
    }
    
    public static void setValueFromJson(final AbstractModule v1, final Setting v2, final JsonElement v3) {
        final String type = /*EL:26*/v2.getType();
        switch (type) {
            case "Boolean": {
                /*SL:28*/v2.setValue(v3.getAsBoolean());
            }
            case "Double": {
                /*SL:31*/v2.setValue(v3.getAsDouble());
            }
            case "Float": {
                /*SL:34*/v2.setValue(v3.getAsFloat());
            }
            case "Integer": {
                /*SL:37*/v2.setValue(v3.getAsInt());
            }
            case "String": {
                final String a1 = /*EL:40*/v3.getAsString();
                /*SL:41*/v2.setValue(a1.replace("_", " "));
            }
            case "Bind": {
                /*SL:44*/v2.setValue(new Bind.BindConverter().doBackward(v3));
            }
            case "Enum": {
                try {
                    final EnumConverter a2 = /*EL:48*/new EnumConverter(((Enum)v2.getValue()).getClass());
                    final Enum a3 = /*EL:49*/a2.doBackward(v3);
                    /*SL:50*/v2.setValue((a3 == null) ? v2.getDefaultValue() : a3);
                }
                catch (Exception ex) {}
            }
            default: {
                Legacy.LOGGER.error(/*EL:55*/"Unknown Setting type for: " + v1.getName() + " : " + v2.getName());
            }
        }
    }
    
    private static void loadFile(final JsonObject v-7, final AbstractModule v-6) {
        /*SL:59*/for (final Map.Entry<String, JsonElement> entry : v-7.entrySet()) {
            final String s = /*EL:60*/entry.getKey();
            final JsonElement v2 = /*EL:61*/entry.getValue();
            /*SL:62*/if (v-6 instanceof FriendManager) {
                try {
                    Legacy.friendManager.addFriend(/*EL:64*/new FriendManager.Friend(v2.getAsString(), UUID.fromString(s)));
                }
                catch (Exception a1) {
                    /*SL:66*/a1.printStackTrace();
                }
            }
            else {
                boolean b = /*EL:70*/false;
                /*SL:71*/for (final Setting v1 : v-6.getSettings()) {
                    /*SL:72*/if (s.equals(v1.getName())) {
                        try {
                            setValueFromJson(/*EL:74*/v-6, v1, v2);
                        }
                        catch (Exception a2) {
                            /*SL:76*/a2.printStackTrace();
                        }
                        /*SL:78*/b = true;
                    }
                }
                /*SL:81*/if (!b) {
                    continue;
                }
            }
        }
    }
    
    public void loadConfig(final String v-2) {
        final List<File> list = /*EL:86*/Arrays.<Object>stream((Object[])Objects.<T[]>requireNonNull((T[])new File("legacy").listFiles())).filter(File::isDirectory).<List<File>, ?>collect((Collector<? super Object, ?, List<File>>)Collectors.<? super Object>toList());
        /*SL:87*/if (list.contains(new File("legacy/" + v-2 + "/"))) {
            /*SL:88*/this.config = "legacy/" + v-2 + "/";
        }
        else {
            /*SL:90*/this.config = "legacy/config/";
        }
        Legacy.friendManager.onLoad();
        /*SL:93*/for (final AbstractModule v1 : this.features) {
            try {
                /*SL:95*/this.loadSettings(v1);
            }
            catch (IOException a1) {
                /*SL:97*/a1.printStackTrace();
            }
        }
        /*SL:100*/this.saveCurrentConfig();
    }
    
    public boolean configExists(final String a1) {
        final List<File> v1 = /*EL:104*/Arrays.<Object>stream((Object[])Objects.<T[]>requireNonNull((T[])new File("legacy").listFiles())).filter(File::isDirectory).<List<File>, ?>collect((Collector<? super Object, ?, List<File>>)Collectors.<? super Object>toList());
        /*SL:105*/return v1.contains(new File("legacy/" + a1 + "/"));
    }
    
    public void saveConfig(final String v-2) {
        /*SL:109*/this.config = "legacy/" + v-2 + "/";
        final File file = /*EL:110*/new File(this.config);
        /*SL:111*/if (!file.exists()) {
            /*SL:112*/file.mkdir();
        }
        Legacy.friendManager.saveFriends();
        /*SL:114*/for (final AbstractModule v1 : this.features) {
            try {
                /*SL:116*/this.saveSettings(v1);
            }
            catch (IOException a1) {
                /*SL:118*/a1.printStackTrace();
            }
        }
        /*SL:121*/this.saveCurrentConfig();
    }
    
    public void saveCurrentConfig() {
        final File v0 = /*EL:125*/new File("legacy/currentconfig.txt");
        try {
            /*SL:127*/if (v0.exists()) {
                final FileWriter v = /*EL:128*/new FileWriter(v0);
                final String v2 = /*EL:129*/this.config.replaceAll("/", "");
                /*SL:130*/v.write(v2.replaceAll("legacy", ""));
                /*SL:131*/v.close();
            }
            else {
                /*SL:133*/v0.createNewFile();
                final FileWriter v = /*EL:134*/new FileWriter(v0);
                final String v2 = /*EL:135*/this.config.replaceAll("/", "");
                /*SL:136*/v.write(v2.replaceAll("legacy", ""));
                /*SL:137*/v.close();
            }
        }
        catch (Exception v3) {
            /*SL:140*/v3.printStackTrace();
        }
    }
    
    public String loadCurrentConfig() {
        final File file = /*EL:145*/new File("legacy/currentconfig.txt");
        String v0 = /*EL:146*/"config";
        try {
            /*SL:148*/if (file.exists()) {
                final Scanner v = /*EL:149*/new Scanner(file);
                /*SL:150*/while (v.hasNextLine()) {
                    /*SL:151*/v0 = v.nextLine();
                }
                /*SL:152*/v.close();
            }
        }
        catch (Exception v2) {
            /*SL:155*/v2.printStackTrace();
        }
        /*SL:157*/return v0;
    }
    
    public void resetConfig(final boolean v1, final String v2) {
        /*SL:161*/for (final AbstractModule a1 : this.features) {
            /*SL:162*/a1.reset();
        }
        /*SL:163*/if (v1) {
            /*SL:164*/this.saveConfig(v2);
        }
    }
    
    public void saveSettings(final AbstractModule a1) throws IOException {
        final JsonObject v1 = /*EL:168*/new JsonObject();
        final File v2 = /*EL:169*/new File(this.config + this.getDirectory(a1));
        /*SL:170*/if (!v2.exists()) {
            /*SL:171*/v2.mkdir();
        }
        final String v3 = /*EL:172*/this.config + this.getDirectory(a1) + a1.getName() + ".json";
        final Path v4 = /*EL:173*/Paths.get(v3, new String[0]);
        /*SL:174*/if (!Files.exists(v4, new LinkOption[0])) {
            /*SL:175*/Files.createFile(v4, (FileAttribute<?>[])new FileAttribute[0]);
        }
        final Gson v5 = /*EL:176*/new GsonBuilder().setPrettyPrinting().create();
        final String v6 = /*EL:177*/v5.toJson((JsonElement)this.writeSettings(a1));
        final BufferedWriter v7 = /*EL:178*/new BufferedWriter(new OutputStreamWriter(Files.newOutputStream(v4, new OpenOption[0])));
        /*SL:179*/v7.write(v6);
        /*SL:180*/v7.close();
    }
    
    public void init() {
        /*SL:184*/this.features.addAll(Legacy.moduleManager.modules);
        /*SL:185*/this.features.add(Legacy.friendManager);
        final String v1 = /*EL:186*/this.loadCurrentConfig();
        /*SL:187*/this.loadConfig(v1);
        Legacy.LOGGER.info(/*EL:188*/"Config loaded.");
    }
    
    private void loadSettings(final AbstractModule a1) throws IOException {
        final String v1 = /*EL:192*/this.config + this.getDirectory(a1) + a1.getName() + ".json";
        final Path v2 = /*EL:193*/Paths.get(v1, new String[0]);
        /*SL:194*/if (!Files.exists(v2, new LinkOption[0])) {
            /*SL:195*/return;
        }
        /*SL:196*/this.loadPath(v2, a1);
    }
    
    private void loadPath(final Path v1, final AbstractModule v2) throws IOException {
        final InputStream v3 = /*EL:200*/Files.newInputStream(v1, new OpenOption[0]);
        try {
            loadFile(/*EL:202*/new JsonParser().parse((Reader)new InputStreamReader(v3)).getAsJsonObject(), v2);
        }
        catch (IllegalStateException a1) {
            Legacy.LOGGER.error(/*EL:204*/"Bad Config File for: " + v2.getName() + ". Resetting...");
            loadFile(/*EL:205*/new JsonObject(), v2);
        }
        /*SL:207*/v3.close();
    }
    
    public JsonObject writeSettings(final AbstractModule v-4) {
        final JsonObject jsonObject = /*EL:211*/new JsonObject();
        final JsonParser jsonParser = /*EL:212*/new JsonParser();
        /*SL:213*/for (final Setting v0 : v-4.getSettings()) {
            /*SL:214*/if (v0.isEnumSetting()) {
                final EnumConverter a1 = /*EL:215*/new EnumConverter(v0.getValue().getClass());
                /*SL:216*/jsonObject.add(v0.getName(), a1.doForward(v0.getValue()));
            }
            else {
                /*SL:219*/if (v0.isStringSetting()) {
                    final String v = /*EL:220*/v0.getValue();
                    /*SL:221*/v0.setValue(v.replace(" ", "_"));
                }
                try {
                    /*SL:224*/jsonObject.add(v0.getName(), jsonParser.parse(v0.getValueAsString()));
                }
                catch (Exception v2) {
                    /*SL:226*/v2.printStackTrace();
                }
            }
        }
        /*SL:229*/return jsonObject;
    }
    
    public String getDirectory(final AbstractModule a1) {
        String v1 = /*EL:233*/"";
        /*SL:234*/if (a1 instanceof Module) {
            /*SL:235*/v1 = v1 + ((Module)a1).getCategory().getName() + "/";
        }
        /*SL:236*/return v1;
    }
}
