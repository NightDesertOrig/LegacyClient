package me.dev.legacy.api.manager;

import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.io.File;
import java.nio.file.attribute.FileAttribute;
import java.util.function.Function;
import java.util.Arrays;
import java.util.stream.Stream;
import java.util.List;
import java.io.IOException;
import java.nio.file.StandardOpenOption;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.nio.file.Paths;
import java.nio.file.Path;
import me.dev.legacy.api.AbstractModule;

public class FileManager extends AbstractModule
{
    private final Path base;
    private final Path config;
    
    public FileManager() {
        this.base = this.getMkDirectory(this.getRoot(), "legacy");
        this.config = this.getMkDirectory(this.base, "config");
    }
    
    public static boolean appendTextFile(final String v1, final String v2) {
        try {
            final Path a1 = /*EL:25*/Paths.get(v2, new String[0]);
            /*SL:26*/Files.write(a1, Collections.<String>singletonList(v1), StandardCharsets.UTF_8, Files.exists(a1, new LinkOption[0]) ? StandardOpenOption.APPEND : StandardOpenOption.CREATE);
        }
        catch (IOException a2) {
            System.out.println(/*EL:28*/"WARNING: Unable to write file: " + v2);
            /*SL:29*/return false;
        }
        /*SL:31*/return true;
    }
    
    public static List<String> readTextFileAllLines(final String v0) {
        try {
            final Path a1 = /*EL:36*/Paths.get(v0, new String[0]);
            /*SL:37*/return Files.readAllLines(a1, StandardCharsets.UTF_8);
        }
        catch (IOException v) {
            System.out.println(/*EL:39*/"WARNING: Unable to read file, creating new file: " + v0);
            appendTextFile(/*EL:40*/"", v0);
            /*SL:41*/return Collections.<String>emptyList();
        }
    }
    
    private String[] expandPath(final String a1) {
        /*SL:46*/return a1.split(":?\\\\\\\\|\\/");
    }
    
    private Stream<String> expandPaths(final String... a1) {
        /*SL:50*/return Arrays.<String>stream(a1).<Object>map((Function<? super String, ?>)this::expandPath).<String>flatMap((Function<? super Object, ? extends Stream<? extends String>>)Arrays::stream);
    }
    
    private Path lookupPath(final Path a1, final String... a2) {
        /*SL:54*/return Paths.get(a1.toString(), a2);
    }
    
    private Path getRoot() {
        /*SL:58*/return Paths.get("", new String[0]);
    }
    
    private void createDirectory(final Path v2) {
        try {
            /*SL:63*/if (!Files.isDirectory(v2, new LinkOption[0])) {
                /*SL:64*/if (Files.exists(v2, new LinkOption[0])) {
                    /*SL:65*/Files.delete(v2);
                }
                /*SL:67*/Files.createDirectories(v2, (FileAttribute<?>[])new FileAttribute[0]);
            }
        }
        catch (IOException a1) {
            /*SL:70*/a1.printStackTrace();
        }
    }
    
    private Path getMkDirectory(final Path a1, final String... a2) {
        /*SL:75*/if (a2.length < 1) {
            /*SL:76*/return a1;
        }
        final Path v1 = /*EL:78*/this.lookupPath(a1, a2);
        /*SL:79*/this.createDirectory(v1);
        /*SL:80*/return v1;
    }
    
    public Path getBasePath() {
        /*SL:84*/return this.base;
    }
    
    public Path getBaseResolve(final String... a1) {
        final String[] v1 = /*EL:88*/this.expandPaths(a1).<String>toArray(String[]::new);
        /*SL:89*/if (v1.length < 1) {
            /*SL:90*/throw new IllegalArgumentException("missing path");
        }
        /*SL:92*/return this.lookupPath(this.getBasePath(), v1);
    }
    
    public Path getMkBaseResolve(final String... a1) {
        final Path v1 = /*EL:96*/this.getBaseResolve(a1);
        /*SL:97*/this.createDirectory(v1.getParent());
        /*SL:98*/return v1;
    }
    
    public Path getConfig() {
        /*SL:102*/return this.getBasePath().resolve("config");
    }
    
    public Path getCache() {
        /*SL:106*/return this.getBasePath().resolve("cache");
    }
    
    public Path getMkBaseDirectory(final String... a1) {
        /*SL:110*/return this.getMkDirectory(this.getBasePath(), this.expandPaths(a1).<String, ?>collect(Collectors.joining(File.separator)));
    }
    
    public Path getMkConfigDirectory(final String... a1) {
        /*SL:114*/return this.getMkDirectory(this.getConfig(), this.expandPaths(a1).<String, ?>collect(Collectors.joining(File.separator)));
    }
}
