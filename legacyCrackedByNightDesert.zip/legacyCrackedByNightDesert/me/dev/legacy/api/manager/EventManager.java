package me.dev.legacy.api.manager;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.dev.legacy.impl.command.Command;
import net.minecraftforge.client.event.ClientChatEvent;
import org.lwjgl.input.Keyboard;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import me.dev.legacy.api.event.events.render.Render2DEvent;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import me.dev.legacy.api.event.events.render.Render3DEvent;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import java.util.UUID;
import net.minecraft.network.play.server.SPacketTimeUpdate;
import me.dev.legacy.api.event.events.other.ConnectionEvent;
import com.google.common.base.Strings;
import java.util.function.Predicate;
import java.util.Objects;
import net.minecraft.network.play.server.SPacketPlayerListItem;
import me.dev.legacy.api.event.events.misc.TotemPopEvent;
import net.minecraft.world.World;
import net.minecraft.network.play.server.SPacketEntityStatus;
import me.dev.legacy.api.event.events.other.PacketEvent;
import me.dev.legacy.api.event.events.move.UpdateWalkingPlayerEvent;
import java.util.Iterator;
import me.dev.legacy.modules.misc.PopCounter;
import net.minecraftforge.fml.common.eventhandler.Event;
import me.dev.legacy.api.event.events.event.DeathEvent;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.common.network.FMLNetworkEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import me.dev.legacy.modules.client.HUD;
import me.dev.legacy.Legacy;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.common.MinecraftForge;
import java.util.concurrent.atomic.AtomicBoolean;
import me.dev.legacy.api.util.Timer;
import me.dev.legacy.api.AbstractModule;

public class EventManager extends AbstractModule
{
    private final Timer logoutTimer;
    private final AtomicBoolean tickOngoing;
    
    public EventManager() {
        this.logoutTimer = new Timer();
        this.tickOngoing = new AtomicBoolean(false);
    }
    
    public void init() {
        MinecraftForge.EVENT_BUS.register(/*EL:48*/(Object)this);
    }
    
    public boolean ticksOngoing() {
        /*SL:52*/return this.tickOngoing.get();
    }
    
    public void onUnload() {
        MinecraftForge.EVENT_BUS.unregister(/*EL:56*/(Object)this);
    }
    
    @SubscribeEvent
    public void onUpdate(final LivingEvent.LivingUpdateEvent a1) {
        /*SL:61*/if (!AbstractModule.fullNullCheck() && a1.getEntity().func_130014_f_().field_72995_K && a1.getEntityLiving().equals((Object)EventManager.mc.field_71439_g)) {
            Legacy.inventoryManager.update();
            Legacy.moduleManager.onUpdate();
            /*SL:64*/if (HUD.getInstance().renderingMode.getValue() == HUD.RenderingMode.Length) {
                Legacy.moduleManager.sortModules(/*EL:65*/true);
            }
            else {
                Legacy.moduleManager.sortModulesABC();
            }
        }
    }
    
    @SubscribeEvent
    public void onClientConnect(final FMLNetworkEvent.ClientConnectedToServerEvent a1) {
        /*SL:74*/this.logoutTimer.reset();
        Legacy.moduleManager.onLogin();
    }
    
    @SubscribeEvent
    public void onClientDisconnect(final FMLNetworkEvent.ClientDisconnectionFromServerEvent a1) {
        Legacy.moduleManager.onLogout();
    }
    
    @SubscribeEvent
    public void onTick(final TickEvent.ClientTickEvent v2) {
        /*SL:85*/if (AbstractModule.fullNullCheck()) {
            /*SL:86*/return;
        }
        Legacy.moduleManager.onTick();
        /*SL:88*/for (final EntityPlayer a1 : EventManager.mc.field_71441_e.field_73010_i) {
            /*SL:89*/if (a1 != null) {
                if (a1.func_110143_aJ() > 0.0f) {
                    /*SL:90*/continue;
                }
                MinecraftForge.EVENT_BUS.post(/*EL:91*/(Event)new DeathEvent(a1));
                /*SL:92*/PopCounter.getInstance().onDeath(a1);
            }
        }
    }
    
    @SubscribeEvent
    public void onUpdateWalkingPlayer(final UpdateWalkingPlayerEvent a1) {
        /*SL:98*/if (AbstractModule.fullNullCheck()) {
            /*SL:99*/return;
        }
        /*SL:100*/if (a1.getStage() == 0) {
            Legacy.speedManager.updateValues();
            Legacy.rotationManager.updateRotations();
            Legacy.positionManager.updatePosition();
        }
        /*SL:105*/if (a1.getStage() == 1) {
            Legacy.rotationManager.restoreRotations();
            Legacy.positionManager.restorePosition();
        }
    }
    
    @SubscribeEvent
    public void onPacketReceive(final PacketEvent.Receive v0) {
        /*SL:113*/if (v0.getStage() != 0) {
            /*SL:114*/return;
        }
        Legacy.serverManager.onPacketReceived();
        /*SL:116*/if (v0.getPacket() instanceof SPacketEntityStatus) {
            final SPacketEntityStatus v = /*EL:117*/(SPacketEntityStatus)v0.getPacket();
            /*SL:118*/if (v.func_149160_c() == 35 && v.func_149161_a((World)EventManager.mc.field_71441_e) instanceof EntityPlayer) {
                final EntityPlayer a2 = /*EL:119*/(EntityPlayer)v.func_149161_a((World)EventManager.mc.field_71441_e);
                MinecraftForge.EVENT_BUS.post(/*EL:120*/(Event)new TotemPopEvent(a2));
                /*SL:121*/PopCounter.getInstance().onTotemPop(a2);
            }
        }
        /*SL:124*/if (v0.getPacket() instanceof SPacketPlayerListItem && !AbstractModule.fullNullCheck() && this.logoutTimer.passedS(1.0)) {
            final SPacketPlayerListItem v2 = /*EL:125*/(SPacketPlayerListItem)v0.getPacket();
            /*SL:126*/if (!SPacketPlayerListItem.Action.ADD_PLAYER.equals((Object)v2.func_179768_b()) && !SPacketPlayerListItem.Action.REMOVE_PLAYER.equals((Object)v2.func_179768_b())) {
                /*SL:127*/return;
            }
            final UUID v3;
            final SPacketPlayerListItem sPacketPlayerListItem;
            final String a3;
            final EntityPlayer v4;
            final String a4;
            /*SL:128*/v2.func_179767_a().stream().filter(Objects::nonNull).filter(a1 -> !Strings.isNullOrEmpty(a1.func_179962_a().getName()) || a1.func_179962_a().getId() != null).forEach(v-1 -> {
                v3 = v-1.func_179962_a().getId();
                switch (sPacketPlayerListItem.func_179768_b()) {
                    case ADD_PLAYER: {
                        a3 = v-1.func_179962_a().getName();
                        MinecraftForge.EVENT_BUS.post((Event)new ConnectionEvent(0, v3, a3));
                        break;
                    }
                    case REMOVE_PLAYER: {
                        v4 = EventManager.mc.field_71441_e.func_152378_a(v3);
                        if (v4 != null) {
                            a4 = v4.func_70005_c_();
                            MinecraftForge.EVENT_BUS.post((Event)new ConnectionEvent(1, v4, v3, a4));
                            break;
                        }
                        else {
                            MinecraftForge.EVENT_BUS.post((Event)new ConnectionEvent(2, v3, null));
                            break;
                        }
                        break;
                    }
                }
                return;
            });
        }
        /*SL:150*/if (v0.getPacket() instanceof SPacketTimeUpdate) {
            Legacy.serverManager.update();
        }
    }
    
    @SubscribeEvent
    public void onWorldRender(final RenderWorldLastEvent a1) {
        /*SL:156*/if (a1.isCanceled()) {
            /*SL:157*/return;
        }
        EventManager.mc.field_71424_I.func_76320_a(/*EL:158*/"oyvey");
        /*SL:159*/GlStateManager.func_179090_x();
        /*SL:160*/GlStateManager.func_179147_l();
        /*SL:161*/GlStateManager.func_179118_c();
        /*SL:162*/GlStateManager.func_179120_a(770, 771, 1, 0);
        /*SL:163*/GlStateManager.func_179103_j(7425);
        /*SL:164*/GlStateManager.func_179097_i();
        /*SL:165*/GlStateManager.func_187441_d(1.0f);
        final Render3DEvent v1 = /*EL:166*/new Render3DEvent(a1.getPartialTicks());
        Legacy.moduleManager.onRender3D(/*EL:167*/v1);
        /*SL:168*/GlStateManager.func_187441_d(1.0f);
        /*SL:169*/GlStateManager.func_179103_j(7424);
        /*SL:170*/GlStateManager.func_179084_k();
        /*SL:171*/GlStateManager.func_179141_d();
        /*SL:172*/GlStateManager.func_179098_w();
        /*SL:173*/GlStateManager.func_179126_j();
        /*SL:174*/GlStateManager.func_179089_o();
        /*SL:175*/GlStateManager.func_179089_o();
        /*SL:176*/GlStateManager.func_179132_a(true);
        /*SL:177*/GlStateManager.func_179098_w();
        /*SL:178*/GlStateManager.func_179147_l();
        /*SL:179*/GlStateManager.func_179126_j();
        EventManager.mc.field_71424_I.func_76319_b();
    }
    
    @SubscribeEvent
    public void renderHUD(final RenderGameOverlayEvent.Post a1) {
        /*SL:185*/if (a1.getType() == RenderGameOverlayEvent.ElementType.HOTBAR) {
            Legacy.textManager.updateResolution();
        }
    }
    
    @SubscribeEvent(priority = EventPriority.LOW)
    public void onRenderGameOverlayEvent(final RenderGameOverlayEvent.Text v-1) {
        /*SL:191*/if (v-1.getType().equals((Object)RenderGameOverlayEvent.ElementType.TEXT)) {
            final ScaledResolution a1 = /*EL:192*/new ScaledResolution(EventManager.mc);
            final Render2DEvent v1 = /*EL:193*/new Render2DEvent(v-1.getPartialTicks(), a1);
            Legacy.moduleManager.onRender2D(/*EL:194*/v1);
            /*SL:195*/GlStateManager.func_179131_c(1.0f, 1.0f, 1.0f, 1.0f);
        }
    }
    
    @SubscribeEvent(priority = EventPriority.NORMAL, receiveCanceled = true)
    public void onKeyInput(final InputEvent.KeyInputEvent a1) {
        /*SL:201*/if (Keyboard.getEventKeyState()) {
            Legacy.moduleManager.onKeyPressed(/*EL:202*/Keyboard.getEventKey());
        }
    }
    
    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public void onChatSent(final ClientChatEvent v2) {
        /*SL:207*/if (v2.getMessage().startsWith(Command.getCommandPrefix())) {
            /*SL:208*/v2.setCanceled(true);
            try {
                EventManager.mc.field_71456_v.func_146158_b().func_146239_a(/*EL:210*/v2.getMessage());
                /*SL:211*/if (v2.getMessage().length() > 1) {
                    Legacy.commandManager.executeCommand(/*EL:212*/v2.getMessage().substring(Command.getCommandPrefix().length() - 1));
                }
                else {
                    /*SL:214*/Command.sendMessage("Please enter a command.");
                }
            }
            catch (Exception a1) {
                /*SL:217*/a1.printStackTrace();
                /*SL:218*/Command.sendMessage(ChatFormatting.RED + "An error occurred while running this command. Check the log!");
            }
        }
    }
}
