package me.dev.legacy.api.manager;

import java.util.Objects;
import net.minecraft.client.network.NetHandlerPlayClient;
import java.util.Arrays;
import me.dev.legacy.api.util.Timer;
import java.text.DecimalFormat;
import me.dev.legacy.api.AbstractModule;

public class ServerManager extends AbstractModule
{
    private final float[] tpsCounts;
    private final DecimalFormat format;
    private final Timer timer;
    private float TPS;
    private long lastUpdate;
    private String serverBrand;
    
    public ServerManager() {
        this.tpsCounts = new float[10];
        this.format = new DecimalFormat("##.00#");
        this.timer = new Timer();
        this.TPS = 20.0f;
        this.lastUpdate = -1L;
        this.serverBrand = "";
    }
    
    public void onPacketReceived() {
        /*SL:20*/this.timer.reset();
    }
    
    public long serverRespondingTime() {
        /*SL:24*/return this.timer.getPassedTimeMs();
    }
    
    public void update() {
        final long currentTimeMillis = /*EL:29*/System.currentTimeMillis();
        /*SL:30*/if (this.lastUpdate == -1L) {
            /*SL:31*/this.lastUpdate = currentTimeMillis;
            /*SL:32*/return;
        }
        final long n = /*EL:34*/currentTimeMillis - this.lastUpdate;
        float n2 = /*EL:35*/n / 20.0f;
        /*SL:36*/if (n2 == 0.0f) {
            /*SL:37*/n2 = 50.0f;
        }
        float n3;
        /*SL:39*/if ((n3 = 1000.0f / n2) > 20.0f) {
            /*SL:40*/n3 = 20.0f;
        }
        /*SL:42*/System.arraycopy(this.tpsCounts, 0, this.tpsCounts, 1, this.tpsCounts.length - 1);
        /*SL:43*/this.tpsCounts[0] = n3;
        double n4 = /*EL:44*/0.0;
        /*SL:45*/for (final float v1 : this.tpsCounts) {
            /*SL:46*/n4 += v1;
        }
        /*SL:48*/if ((n4 /= this.tpsCounts.length) > 20.0) {
            /*SL:49*/n4 = 20.0;
        }
        /*SL:51*/this.TPS = Float.parseFloat(this.format.format(n4));
        /*SL:52*/this.lastUpdate = currentTimeMillis;
    }
    
    @Override
    public void reset() {
        /*SL:57*/Arrays.fill(this.tpsCounts, 20.0f);
        /*SL:58*/this.TPS = 20.0f;
    }
    
    public float getTpsFactor() {
        /*SL:62*/return 20.0f / this.TPS;
    }
    
    public float getTPS() {
        /*SL:66*/return this.TPS;
    }
    
    public String getServerBrand() {
        /*SL:70*/return this.serverBrand;
    }
    
    public void setServerBrand(final String a1) {
        /*SL:74*/this.serverBrand = a1;
    }
    
    public int getPing() {
        /*SL:78*/if (AbstractModule.fullNullCheck()) {
            /*SL:79*/return 0;
        }
        try {
            /*SL:82*/return Objects.<NetHandlerPlayClient>requireNonNull(ServerManager.mc.func_147114_u()).func_175102_a(ServerManager.mc.func_147114_u().func_175105_e().getId()).func_178853_c();
        }
        catch (Exception v1) {
            /*SL:84*/return 0;
        }
    }
}
