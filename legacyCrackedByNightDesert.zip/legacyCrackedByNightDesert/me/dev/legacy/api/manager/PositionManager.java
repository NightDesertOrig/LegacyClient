package me.dev.legacy.api.manager;

import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import me.dev.legacy.api.AbstractModule;

public class PositionManager extends AbstractModule
{
    private double x;
    private double y;
    private double z;
    private boolean onground;
    
    public void updatePosition() {
        /*SL:14*/this.x = PositionManager.mc.field_71439_g.field_70165_t;
        /*SL:15*/this.y = PositionManager.mc.field_71439_g.field_70163_u;
        /*SL:16*/this.z = PositionManager.mc.field_71439_g.field_70161_v;
        /*SL:17*/this.onground = PositionManager.mc.field_71439_g.field_70122_E;
    }
    
    public void restorePosition() {
        PositionManager.mc.field_71439_g.field_70165_t = /*EL:21*/this.x;
        PositionManager.mc.field_71439_g.field_70163_u = /*EL:22*/this.y;
        PositionManager.mc.field_71439_g.field_70161_v = /*EL:23*/this.z;
        PositionManager.mc.field_71439_g.field_70122_E = /*EL:24*/this.onground;
    }
    
    public void setPlayerPosition(final double a1, final double a2, final double a3) {
        PositionManager.mc.field_71439_g.field_70165_t = /*EL:28*/a1;
        PositionManager.mc.field_71439_g.field_70163_u = /*EL:29*/a2;
        PositionManager.mc.field_71439_g.field_70161_v = /*EL:30*/a3;
    }
    
    public void setPlayerPosition(final double a1, final double a2, final double a3, final boolean a4) {
        PositionManager.mc.field_71439_g.field_70165_t = /*EL:34*/a1;
        PositionManager.mc.field_71439_g.field_70163_u = /*EL:35*/a2;
        PositionManager.mc.field_71439_g.field_70161_v = /*EL:36*/a3;
        PositionManager.mc.field_71439_g.field_70122_E = /*EL:37*/a4;
    }
    
    public void setPositionPacket(final double a1, final double a2, final double a3, final boolean a4, final boolean a5, final boolean a6) {
        PositionManager.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:41*/(Packet)new CPacketPlayer.Position(a1, a2, a3, a4));
        /*SL:42*/if (a5) {
            PositionManager.mc.field_71439_g.func_70107_b(/*EL:43*/a1, a2, a3);
            /*SL:44*/if (a6) {
                /*SL:45*/this.updatePosition();
            }
        }
    }
    
    public double getX() {
        /*SL:51*/return this.x;
    }
    
    public void setX(final double a1) {
        /*SL:55*/this.x = a1;
    }
    
    public double getY() {
        /*SL:59*/return this.y;
    }
    
    public void setY(final double a1) {
        /*SL:63*/this.y = a1;
    }
    
    public double getZ() {
        /*SL:67*/return this.z;
    }
    
    public void setZ(final double a1) {
        /*SL:71*/this.z = a1;
    }
}
