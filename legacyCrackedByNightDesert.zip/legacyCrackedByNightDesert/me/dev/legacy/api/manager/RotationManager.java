package me.dev.legacy.api.manager;

import me.dev.legacy.api.util.RotationUtil;
import net.minecraft.entity.Entity;
import me.dev.legacy.api.util.MathUtil;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.BlockPos;
import me.dev.legacy.api.AbstractModule;

public class RotationManager extends AbstractModule
{
    private float yaw;
    private float pitch;
    
    public void updateRotations() {
        /*SL:20*/this.yaw = RotationManager.mc.field_71439_g.field_70177_z;
        /*SL:21*/this.pitch = RotationManager.mc.field_71439_g.field_70125_A;
    }
    
    public void restoreRotations() {
        RotationManager.mc.field_71439_g.field_70177_z = /*EL:25*/this.yaw;
        RotationManager.mc.field_71439_g.field_70759_as = /*EL:26*/this.yaw;
        RotationManager.mc.field_71439_g.field_70125_A = /*EL:27*/this.pitch;
    }
    
    public void setPlayerRotations(final float a1, final float a2) {
        RotationManager.mc.field_71439_g.field_70177_z = /*EL:31*/a1;
        RotationManager.mc.field_71439_g.field_70759_as = /*EL:32*/a1;
        RotationManager.mc.field_71439_g.field_70125_A = /*EL:33*/a2;
    }
    
    public void setPlayerYaw(final float a1) {
        RotationManager.mc.field_71439_g.field_70177_z = /*EL:37*/a1;
        RotationManager.mc.field_71439_g.field_70759_as = /*EL:38*/a1;
    }
    
    public void lookAtPos(final BlockPos a1) {
        final float[] v1 = /*EL:42*/MathUtil.calcAngle(RotationManager.mc.field_71439_g.func_174824_e(RotationManager.mc.func_184121_ak()), new Vec3d((double)(a1.func_177958_n() + 0.5f), (double)(a1.func_177956_o() + 0.5f), (double)(a1.func_177952_p() + 0.5f)));
        /*SL:43*/this.setPlayerRotations(v1[0], v1[1]);
    }
    
    public void lookAtVec3d(final Vec3d a1) {
        final float[] v1 = /*EL:47*/MathUtil.calcAngle(RotationManager.mc.field_71439_g.func_174824_e(RotationManager.mc.func_184121_ak()), new Vec3d(a1.field_72450_a, a1.field_72448_b, a1.field_72449_c));
        /*SL:48*/this.setPlayerRotations(v1[0], v1[1]);
    }
    
    public void lookAtVec3d(final double a1, final double a2, final double a3) {
        final Vec3d v1 = /*EL:52*/new Vec3d(a1, a2, a3);
        /*SL:53*/this.lookAtVec3d(v1);
    }
    
    public void lookAtEntity(final Entity a1) {
        final float[] v1 = /*EL:57*/MathUtil.calcAngle(RotationManager.mc.field_71439_g.func_174824_e(RotationManager.mc.func_184121_ak()), a1.func_174824_e(RotationManager.mc.func_184121_ak()));
        /*SL:58*/this.setPlayerRotations(v1[0], v1[1]);
    }
    
    public void setPlayerPitch(final float a1) {
        RotationManager.mc.field_71439_g.field_70125_A = /*EL:62*/a1;
    }
    
    public float getYaw() {
        /*SL:66*/return this.yaw;
    }
    
    public void setYaw(final float a1) {
        /*SL:70*/this.yaw = a1;
    }
    
    public float getPitch() {
        /*SL:74*/return this.pitch;
    }
    
    public void setPitch(final float a1) {
        /*SL:78*/this.pitch = a1;
    }
    
    public int getDirection4D() {
        /*SL:82*/return RotationUtil.getDirection4D();
    }
    
    public String getDirection4D(final boolean a1) {
        /*SL:86*/return RotationUtil.getDirection4D(a1);
    }
    
    public enum Rotation
    {
        SEND, 
        REL, 
        MANUAL, 
        NONE;
    }
}
