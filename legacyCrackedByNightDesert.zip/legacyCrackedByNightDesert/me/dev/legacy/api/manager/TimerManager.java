package me.dev.legacy.api.manager;

import me.dev.legacy.api.AbstractModule;

public class TimerManager extends AbstractModule
{
    private float timer;
    
    public TimerManager() {
        this.timer = 1.0f;
    }
    
    public void unload() {
        /*SL:10*/this.timer = 1.0f;
        TimerManager.mc.field_71428_T.field_194149_e = /*EL:11*/50.0f;
    }
    
    public void update() {
        TimerManager.mc.field_71428_T.field_194149_e = /*EL:15*/50.0f / ((this.timer <= 0.0f) ? 0.1f : this.timer);
    }
    
    public void setTimer(final float a1) {
        /*SL:19*/if (a1 > 0.0f) {
            /*SL:20*/this.timer = a1;
        }
    }
    
    public float getTimer() {
        /*SL:25*/return this.timer;
    }
    
    @Override
    public void reset() {
        /*SL:30*/this.timer = 1.0f;
    }
}
