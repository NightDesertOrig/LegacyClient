package me.dev.legacy.api.mixin.mixins;

import org.spongepowered.asm.mixin.injection.Redirect;
import net.minecraft.client.Minecraft;
import me.dev.legacy.modules.client.Media;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import me.dev.legacy.Legacy;
import me.dev.legacy.modules.client.Font;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.Shadow;
import net.minecraft.client.gui.FontRenderer;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({ FontRenderer.class })
public abstract class MixinFontRenderer
{
    @Shadow
    protected abstract int func_180455_b(final String p0, final float p1, final float p2, final int p3, final boolean p4);
    
    @Shadow
    protected abstract void func_78255_a(final String p0, final boolean p1);
    
    @Inject(method = { "drawString(Ljava/lang/String;FFIZ)I" }, at = { @At("HEAD") }, cancellable = true)
    public void renderStringHook(final String a3, final float a4, final float a5, final int a6, final boolean v1, final CallbackInfoReturnable<Integer> v2) {
        /*SL:26*/if (Font.getInstance().isOn() && Font.getInstance().full.getValue() && Legacy.textManager != null) {
            final float a7 = Legacy.textManager.drawString(/*EL:27*/a3, a4, a5, a6, v1);
            /*SL:28*/v2.setReturnValue((int)a7);
        }
    }
    
    @Redirect(method = { "renderString(Ljava/lang/String;FFIZ)I" }, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/FontRenderer;renderStringAtPos(Ljava/lang/String;Z)V"))
    public void renderStringAtPosHook(final FontRenderer a1, final String a2, final boolean a3) {
        /*SL:34*/if (Media.getInstance().isOn()) {
            /*SL:35*/this.func_78255_a(a2.replace(Minecraft.func_71410_x().func_110432_I().func_111285_a(), Media.getInstance().NameString.getValueAsString()), a3);
        }
        else {
            /*SL:38*/this.func_78255_a(a2, a3);
        }
    }
}
