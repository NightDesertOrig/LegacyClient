package me.dev.legacy.api.mixin.mixins;

import me.dev.legacy.api.event.events.block.ProcessRightClickBlockEvent;
import net.minecraft.client.Minecraft;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.block.material.Material;
import net.minecraft.entity.Entity;
import net.minecraft.block.Block;
import net.minecraft.world.IBlockAccess;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemBlock;
import me.dev.legacy.modules.player.Reach;
import org.spongepowered.asm.mixin.injection.Inject;
import net.minecraftforge.fml.common.eventhandler.Event;
import net.minecraftforge.common.MinecraftForge;
import me.dev.legacy.api.event.events.block.BlockEvent;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import net.minecraft.util.EnumFacing;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import me.dev.legacy.Legacy;
import me.dev.legacy.modules.player.TpsSync;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({ PlayerControllerMP.class })
public class MixinPlayerControllerMP
{
    @Redirect(method = { "onPlayerDamageBlock" }, at = @At(value = "INVOKE", target = "Lnet/minecraft/block/state/IBlockState;getPlayerRelativeBlockHardness(Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;)F"))
    public float getPlayerRelativeBlockHardnessHook(final IBlockState a1, final EntityPlayer a2, final World a3, final BlockPos a4) {
        /*SL:39*/return a1.func_185903_a(a2, a3, a4) * ((TpsSync.getInstance().isOn() && TpsSync.getInstance().mining.getValue()) ? (1.0f / Legacy.serverManager.getTpsFactor()) : 1.0f);
    }
    
    @Inject(method = { "clickBlock" }, at = { @At("HEAD") }, cancellable = true)
    private void clickBlockHook(final BlockPos a1, final EnumFacing a2, final CallbackInfoReturnable<Boolean> a3) {
        final BlockEvent v1 = /*EL:44*/new BlockEvent(3, a1, a2);
        MinecraftForge.EVENT_BUS.post(/*EL:45*/(Event)v1);
    }
    
    @Inject(method = { "onPlayerDamageBlock" }, at = { @At("HEAD") }, cancellable = true)
    private void onPlayerDamageBlockHook(final BlockPos a1, final EnumFacing a2, final CallbackInfoReturnable<Boolean> a3) {
        final BlockEvent v1 = /*EL:50*/new BlockEvent(4, a1, a2);
        MinecraftForge.EVENT_BUS.post(/*EL:51*/(Event)v1);
    }
    
    @Inject(method = { "getBlockReachDistance" }, at = { @At("RETURN") }, cancellable = true)
    private void getReachDistanceHook(final CallbackInfoReturnable<Float> v2) {
        /*SL:56*/if (Reach.getInstance().isOn()) {
            final float a1 = /*EL:57*/v2.getReturnValue();
            /*SL:58*/v2.setReturnValue(((boolean)Reach.getInstance().override.getValue()) ? ((Float)Reach.getInstance().reach.getValue()) : (a1 + Reach.getInstance().add.getValue()));
        }
    }
    
    @Redirect(method = { "processRightClickBlock" }, at = @At(value = "INVOKE", target = "Lnet/minecraft/item/ItemBlock;canPlaceBlockOnSide(Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/util/EnumFacing;Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/item/ItemStack;)Z"))
    public boolean canPlaceBlockOnSideHook(final ItemBlock a1, final World a2, BlockPos a3, EnumFacing a4, final EntityPlayer a5, final ItemStack a6) {
        final Block v1 = /*EL:64*/a2.func_180495_p(a3).func_177230_c();
        /*SL:65*/if (v1 == Blocks.field_150431_aC && v1.func_176200_f((IBlockAccess)a2, a3)) {
            /*SL:66*/a4 = EnumFacing.UP;
        }
        else/*SL:67*/ if (!v1.func_176200_f((IBlockAccess)a2, a3)) {
            /*SL:68*/a3 = a3.func_177972_a(a4);
        }
        final IBlockState v2 = /*EL:70*/a2.func_180495_p(a3);
        final AxisAlignedBB v3 = /*EL:71*/a1.field_150939_a.func_176223_P().func_185890_d((IBlockAccess)a2, a3);
        /*SL:72*/if (v3 == Block.field_185506_k || a2.func_72917_a(v3.func_186670_a(a3), (Entity)null)) {
            /*SL:73*/if (v2.func_185904_a() == Material.field_151594_q && a1.field_150939_a == Blocks.field_150467_bQ) {
                /*SL:74*/return true;
            }
        }
        /*SL:76*/return v2.func_177230_c().func_176200_f((IBlockAccess)a2, a3) && a1.field_150939_a.func_176198_a(a2, a3, a4);
    }
    
    @Inject(method = { "processRightClickBlock" }, at = { @At("HEAD") }, cancellable = true)
    public void processRightClickBlock(final EntityPlayerSP a1, final WorldClient a2, final BlockPos a3, final EnumFacing a4, final Vec3d a5, final EnumHand a6, final CallbackInfoReturnable<EnumActionResult> a7) {
        final ProcessRightClickBlockEvent v1 = /*EL:81*/new ProcessRightClickBlockEvent(a3, a6, Minecraft.func_71410_x().field_71439_g.func_184586_b(a6));
        MinecraftForge.EVENT_BUS.post(/*EL:82*/(Event)v1);
        /*SL:83*/if (v1.isCanceled()) {
            /*SL:84*/a7.cancel();
        }
    }
}
