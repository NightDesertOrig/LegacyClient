package me.dev.legacy.api.mixin.mixins;

import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import me.dev.legacy.modules.player.LiquidInteract;
import net.minecraft.block.properties.IProperty;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import net.minecraft.block.state.IBlockState;
import net.minecraft.block.material.Material;
import net.minecraft.block.BlockLiquid;
import org.spongepowered.asm.mixin.Mixin;
import net.minecraft.block.Block;

@Mixin({ BlockLiquid.class })
public class MixinBlockLiquid extends Block
{
    protected MixinBlockLiquid(final Material a1) {
        super(a1);
    }
    
    @Inject(method = { "canCollideCheck" }, at = { @At("HEAD") }, cancellable = true)
    public void canCollideCheckHook(final IBlockState a1, final boolean a2, final CallbackInfoReturnable<Boolean> a3) {
        /*SL:23*/a3.setReturnValue((a2 && (int)a1.func_177229_b((IProperty)BlockLiquid.field_176367_b) == 0) || LiquidInteract.getInstance().isOn());
    }
}
