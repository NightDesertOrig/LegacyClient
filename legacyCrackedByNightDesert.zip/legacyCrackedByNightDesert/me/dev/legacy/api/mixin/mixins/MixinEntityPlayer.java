package me.dev.legacy.api.mixin.mixins;

import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import net.minecraftforge.fml.common.eventhandler.Event;
import me.dev.legacy.api.event.events.move.PlayerJumpEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.mojang.authlib.GameProfile;
import net.minecraft.world.World;
import net.minecraft.entity.player.EntityPlayer;
import org.spongepowered.asm.mixin.Mixin;
import net.minecraft.entity.EntityLivingBase;

@Mixin({ EntityPlayer.class })
public abstract class MixinEntityPlayer extends EntityLivingBase
{
    EntityPlayer player;
    
    public MixinEntityPlayer(final World a1, final GameProfile a2) {
        super(a1);
    }
    
    @Inject(method = { "jump" }, at = { @At("HEAD") }, cancellable = true)
    public void onJump(final CallbackInfo a1) {
        /*SL:24*/if (Minecraft.func_71410_x().field_71439_g.func_70005_c_() == this.func_70005_c_()) {
            MinecraftForge.EVENT_BUS.post(/*EL:25*/(Event)new PlayerJumpEvent(this.field_70159_w, this.field_70181_x));
        }
    }
}
