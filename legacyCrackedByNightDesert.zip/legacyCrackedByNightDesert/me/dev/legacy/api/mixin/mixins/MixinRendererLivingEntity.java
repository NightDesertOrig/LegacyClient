package me.dev.legacy.api.mixin.mixins;

import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.lwjgl.opengl.GL11;
import me.dev.legacy.modules.ModuleManager;
import me.dev.legacy.Legacy;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.entity.RenderLivingBase;
import org.spongepowered.asm.mixin.Mixin;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.entity.EntityLivingBase;

@Mixin({ RenderLivingBase.class })
public abstract class MixinRendererLivingEntity<T extends EntityLivingBase> extends Render<T>
{
    protected ModelBase entityModel;
    
    protected MixinRendererLivingEntity() {
        super((RenderManager)null);
    }
    
    @Inject(method = { "doRender" }, at = { @At("HEAD") })
    public void doRenderPre(final T a1, final double a2, final double a3, final double a4, final float a5, final float a6, final CallbackInfo a7) {
        final ModuleManager moduleManager = Legacy.moduleManager;
        /*SL:25*/if (ModuleManager.isModuleEnabled("TexturedChams") && a1 != null) {
            /*SL:26*/GL11.glEnable(32823);
            /*SL:27*/GL11.glPolygonOffset(1.0f, -1100000.0f);
        }
    }
    
    @Inject(method = { "doRender" }, at = { @At("RETURN") })
    public void doRenderPost(final T a1, final double a2, final double a3, final double a4, final float a5, final float a6, final CallbackInfo a7) {
        final ModuleManager moduleManager = Legacy.moduleManager;
        /*SL:33*/if (ModuleManager.isModuleEnabled("TexturedChams") && a1 != null) {
            /*SL:34*/GL11.glPolygonOffset(1.0f, 1000000.0f);
            /*SL:35*/GL11.glDisable(32823);
        }
    }
}
