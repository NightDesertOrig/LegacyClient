package me.dev.legacy.api.mixin.mixins;

import me.dev.legacy.api.event.events.move.MoveEvent;
import net.minecraft.entity.MoverType;
import net.minecraft.util.math.AxisAlignedBB;
import me.dev.legacy.api.event.events.move.PushEvent;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.Redirect;
import me.dev.legacy.api.event.events.move.UpdateWalkingPlayerEvent;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import net.minecraftforge.fml.common.eventhandler.Event;
import net.minecraftforge.common.MinecraftForge;
import me.dev.legacy.api.event.events.chat.ChatEvent;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.stats.RecipeBook;
import net.minecraft.stats.StatisticsManager;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.world.World;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import org.spongepowered.asm.mixin.Mixin;
import net.minecraft.client.entity.AbstractClientPlayer;

@Mixin(value = { EntityPlayerSP.class }, priority = 9998)
public abstract class MixinEntityPlayerSP extends AbstractClientPlayer
{
    public MixinEntityPlayerSP(final Minecraft a1, final World a2, final NetHandlerPlayClient a3, final StatisticsManager a4, final RecipeBook a5) {
        super(a2, a3.func_175105_e());
    }
    
    @Inject(method = { "sendChatMessage" }, at = { @At("HEAD") }, cancellable = true)
    public void sendChatMessage(final String a1, final CallbackInfo a2) {
        final ChatEvent v1 = /*EL:35*/new ChatEvent(a1);
        MinecraftForge.EVENT_BUS.post(/*EL:36*/(Event)v1);
    }
    
    @Inject(method = { "onUpdateWalkingPlayer" }, at = { @At("HEAD") })
    private void preMotion(final CallbackInfo a1) {
        final UpdateWalkingPlayerEvent v1 = /*EL:41*/new UpdateWalkingPlayerEvent(0);
        MinecraftForge.EVENT_BUS.post(/*EL:42*/(Event)v1);
    }
    
    @Inject(method = { "onUpdateWalkingPlayer" }, at = { @At("RETURN") })
    private void postMotion(final CallbackInfo a1) {
        final UpdateWalkingPlayerEvent v1 = /*EL:47*/new UpdateWalkingPlayerEvent(1);
        MinecraftForge.EVENT_BUS.post(/*EL:48*/(Event)v1);
    }
    
    @Redirect(method = { "onLivingUpdate" }, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/entity/EntityPlayerSP;setSprinting(Z)V", ordinal = 2))
    public void onLivingUpdate(final EntityPlayerSP a1, final boolean a2) {
        /*SL:53*/a1.func_70031_b(a2);
    }
    
    @Inject(method = { "pushOutOfBlocks" }, at = { @At("HEAD") }, cancellable = true)
    private void pushOutOfBlocksHook(final double a1, final double a2, final double a3, final CallbackInfoReturnable<Boolean> a4) {
        final PushEvent v1 = /*EL:58*/new PushEvent(1);
        MinecraftForge.EVENT_BUS.post(/*EL:59*/(Event)v1);
        /*SL:60*/if (v1.isCanceled()) {
            /*SL:61*/a4.setReturnValue(false);
        }
    }
    
    @Redirect(method = { "onUpdateWalkingPlayer" }, at = @At(value = "FIELD", target = "net/minecraft/util/math/AxisAlignedBB.minY:D"))
    private double minYHook(final AxisAlignedBB a1) {
        /*SL:67*/return a1.field_72338_b;
    }
    
    @Inject(method = { "move" }, at = { @At("HEAD") }, cancellable = true)
    public void move(final MoverType a1, final double a2, final double a3, final double a4, final CallbackInfo a5) {
        final MoveEvent v1 = /*EL:72*/new MoveEvent(0, a1, a2, a3, a4);
        MinecraftForge.EVENT_BUS.post(/*EL:73*/(Event)v1);
        /*SL:74*/if (v1.getX() != a2 || v1.getY() != a3 || v1.getZ() != a4) {
            /*SL:75*/super.func_70091_d(a1, v1.getX(), v1.getY(), v1.getZ());
            /*SL:76*/a5.cancel();
        }
    }
}
