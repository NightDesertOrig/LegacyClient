package me.dev.legacy.api.util;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.util.math.MathHelper;
import java.util.Iterator;
import net.minecraft.block.state.IBlockState;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.util.EnumFacing;
import net.minecraft.network.Packet;
import net.minecraft.entity.Entity;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.util.math.Vec3i;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.client.Minecraft;

public class ItemUtil
{
    public static final Minecraft mc;
    
    public static boolean placeBlock(final BlockPos a1, final EnumHand a2, final boolean a3, final boolean a4, final boolean a5) {
        boolean v1 = /*EL:28*/false;
        final EnumFacing v2 = getFirstFacing(/*EL:29*/a1);
        /*SL:30*/if (v2 == null) {
            /*SL:31*/return a5;
        }
        final BlockPos v3 = /*EL:34*/a1.func_177972_a(v2);
        final EnumFacing v4 = /*EL:35*/v2.func_176734_d();
        final Vec3d v5 = /*EL:37*/new Vec3d((Vec3i)v3).func_72441_c(0.5, 0.5, 0.5).func_178787_e(new Vec3d(v4.func_176730_m()).func_186678_a(0.5));
        final Block v6 = ItemUtil.mc.field_71441_e.func_180495_p(/*EL:38*/v3).func_177230_c();
        /*SL:40*/if (!ItemUtil.mc.field_71439_g.func_70093_af()) {
            ItemUtil.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:41*/(Packet)new CPacketEntityAction((Entity)ItemUtil.mc.field_71439_g, CPacketEntityAction.Action.START_SNEAKING));
            ItemUtil.mc.field_71439_g.func_70095_a(/*EL:42*/true);
            /*SL:43*/v1 = true;
        }
        /*SL:46*/if (a3) {
            faceVector(/*EL:47*/v5, true);
        }
        rightClickBlock(/*EL:50*/v3, v5, a2, v4, a4);
        ItemUtil.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
        ItemUtil.mc.field_71467_ac = /*EL:52*/4;
        /*SL:53*/return v1 || a5;
    }
    
    public static List<EnumFacing> getPossibleSides(final BlockPos v-5) {
        final List<EnumFacing> list = /*EL:57*/new ArrayList<EnumFacing>();
        /*SL:58*/for (final EnumFacing v0 : EnumFacing.values()) {
            final BlockPos v = /*EL:59*/v-5.func_177972_a(v0);
            /*SL:60*/if (ItemUtil.mc.field_71441_e.func_180495_p(v).func_177230_c().func_176209_a(ItemUtil.mc.field_71441_e.func_180495_p(v), false)) {
                final IBlockState a1 = ItemUtil.mc.field_71441_e.func_180495_p(/*EL:61*/v);
                /*SL:62*/if (!a1.func_185904_a().func_76222_j()) {
                    /*SL:63*/list.add(v0);
                }
            }
        }
        /*SL:67*/return list;
    }
    
    public static EnumFacing getFirstFacing(final BlockPos v1) {
        final Iterator<EnumFacing> iterator = getPossibleSides(/*EL:71*/v1).iterator();
        if (iterator.hasNext()) {
            final EnumFacing a1 = iterator.next();
            /*SL:72*/return a1;
        }
        /*SL:74*/return null;
    }
    
    public static Vec3d getEyesPos() {
        /*SL:78*/return new Vec3d(ItemUtil.mc.field_71439_g.field_70165_t, ItemUtil.mc.field_71439_g.field_70163_u + ItemUtil.mc.field_71439_g.func_70047_e(), ItemUtil.mc.field_71439_g.field_70161_v);
    }
    
    public static float[] getLegitRotations(final Vec3d a1) {
        final Vec3d v1 = getEyesPos();
        final double v2 = /*EL:83*/a1.field_72450_a - v1.field_72450_a;
        final double v3 = /*EL:84*/a1.field_72448_b - v1.field_72448_b;
        final double v4 = /*EL:85*/a1.field_72449_c - v1.field_72449_c;
        final double v5 = /*EL:86*/Math.sqrt(v2 * v2 + v4 * v4);
        final float v6 = /*EL:88*/(float)Math.toDegrees(Math.atan2(v4, v2)) - 90.0f;
        final float v7 = /*EL:89*/(float)(-Math.toDegrees(Math.atan2(v3, v5)));
        /*SL:91*/return new float[] { ItemUtil.mc.field_71439_g.field_70177_z + /*EL:92*/MathHelper.func_76142_g(v6 - ItemUtil.mc.field_71439_g.field_70177_z), ItemUtil.mc.field_71439_g.field_70125_A + /*EL:93*/MathHelper.func_76142_g(v7 - ItemUtil.mc.field_71439_g.field_70125_A) };
    }
    
    public static void faceVector(final Vec3d a1, final boolean a2) {
        final float[] v1 = getLegitRotations(/*EL:98*/a1);
        ItemUtil.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:99*/(Packet)new CPacketPlayer.Rotation(v1[0], a2 ? ((float)MathHelper.func_180184_b((int)v1[1], 360)) : v1[1], ItemUtil.mc.field_71439_g.field_70122_E));
    }
    
    public static void rightClickBlock(final BlockPos a4, final Vec3d a5, final EnumHand v1, final EnumFacing v2, final boolean v3) {
        /*SL:103*/if (v3) {
            final float a6 = /*EL:104*/(float)(a5.field_72450_a - a4.func_177958_n());
            final float a7 = /*EL:105*/(float)(a5.field_72448_b - a4.func_177956_o());
            final float a8 = /*EL:106*/(float)(a5.field_72449_c - a4.func_177952_p());
            ItemUtil.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:107*/(Packet)new CPacketPlayerTryUseItemOnBlock(a4, v2, v1, a6, a7, a8));
        }
        else {
            ItemUtil.mc.field_71442_b.func_187099_a(ItemUtil.mc.field_71439_g, ItemUtil.mc.field_71441_e, /*EL:109*/a4, v2, a5, v1);
        }
        ItemUtil.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
        ItemUtil.mc.field_71467_ac = /*EL:112*/4;
    }
    
    public static int findHotbarBlock(final Class v-1) {
        /*SL:116*/for (int v0 = 0; v0 < 9; ++v0) {
            final ItemStack v = ItemUtil.mc.field_71439_g.field_71071_by.func_70301_a(/*EL:117*/v0);
            /*SL:118*/if (v != ItemStack.field_190927_a) {
                /*SL:122*/if (v-1.isInstance(v.func_77973_b())) {
                    /*SL:123*/return v0;
                }
                /*SL:126*/if (v.func_77973_b() instanceof ItemBlock) {
                    final Block a1 = /*EL:127*/((ItemBlock)v.func_77973_b()).func_179223_d();
                    /*SL:128*/if (v-1.isInstance(a1)) {
                        /*SL:129*/return v0;
                    }
                }
            }
        }
        /*SL:133*/return -1;
    }
    
    public static void switchToSlot(final int a1) {
        ItemUtil.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:137*/(Packet)new CPacketHeldItemChange(a1));
        ItemUtil.mc.field_71439_g.field_71071_by.field_70461_c = /*EL:138*/a1;
        ItemUtil.mc.field_71442_b.func_78765_e();
    }
    
    public static int getBlockFromHotbar(final Block v1) {
        int v2 = /*EL:143*/-1;
        /*SL:145*/for (int a1 = 8; a1 >= 0; --a1) {
            /*SL:146*/if (ItemUtil.mc.field_71439_g.field_71071_by.func_70301_a(a1).func_77973_b() == Item.func_150898_a(v1)) {
                /*SL:147*/v2 = a1;
                /*SL:148*/break;
            }
        }
        /*SL:152*/return v2;
    }
    
    public static int getItemFromHotbar(final Class<?> v1) {
        int v2 = /*EL:156*/-1;
        /*SL:158*/for (int a1 = 8; a1 >= 0; --a1) {
            /*SL:159*/if (ItemUtil.mc.field_71439_g.field_71071_by.func_70301_a(a1).func_77973_b().getClass() == v1) {
                /*SL:160*/v2 = a1;
                /*SL:161*/break;
            }
        }
        /*SL:165*/return v2;
    }
    
    public static int getItemFromHotbar(final Item v1) {
        int v2 = /*EL:169*/-1;
        /*SL:171*/for (int a1 = 8; a1 >= 0; --a1) {
            /*SL:172*/if (ItemUtil.mc.field_71439_g.field_71071_by.func_70301_a(a1).func_77973_b() == v1) {
                /*SL:173*/v2 = a1;
                /*SL:174*/break;
            }
        }
        /*SL:178*/return v2;
    }
    
    public static boolean isArmorUnderPercent(final EntityPlayer v1, final float v2) {
        /*SL:182*/for (ItemStack a2 = (ItemStack)3; a2 >= 0; --a2) {
            /*SL:183*/a2 = (ItemStack)v1.field_71071_by.field_70460_b.get(a2);
            /*SL:184*/if (getDamageInPercent(a2) < v2) {
                /*SL:185*/return true;
            }
        }
        /*SL:188*/return false;
    }
    
    public static int getRoundedDamage(final ItemStack a1) {
        /*SL:192*/return (int)getDamageInPercent(a1);
    }
    
    public static float getDamageInPercent(final ItemStack a1) {
        final float v1 = /*EL:196*/(a1.func_77958_k() - a1.func_77952_i()) / a1.func_77958_k();
        final float v2 = /*EL:197*/1.0f - v1;
        /*SL:198*/return 100 - (int)(v2 * 100.0f);
    }
    
    static {
        mc = Minecraft.func_71410_x();
    }
}
