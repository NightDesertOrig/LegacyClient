package me.dev.legacy.api.util;

import me.dev.legacy.HWIDAuthMod;

public class NoStackTraceThrowable extends RuntimeException
{
    public NoStackTraceThrowable(final String a1) {
        super(a1);
        this.setStackTrace(new StackTraceElement[0]);
    }
    
    @Override
    public String toString() {
        /*SL:14*/return "" + HWIDAuthMod.getVersion();
    }
    
    @Override
    public synchronized Throwable fillInStackTrace() {
        /*SL:19*/return this;
    }
}
