package me.dev.legacy.api.util;

import net.minecraft.client.renderer.GlStateManager;
import java.awt.Color;

public class Colour extends Color
{
    public Colour(final int a1, final int a2, final int a3) {
        super(a1, a2, a3);
    }
    
    public Colour(final int a1) {
        super(a1);
    }
    
    public Colour(final int a1, final boolean a2) {
        super(a1, a2);
    }
    
    public Colour(final int a1, final int a2, final int a3, final int a4) {
        super(a1, a2, a3, a4);
    }
    
    public Colour(final Color a1) {
        super(a1.getRed(), a1.getGreen(), a1.getBlue(), a1.getAlpha());
    }
    
    public Colour(final Colour a1, final int a2) {
        super(a1.getRed(), a1.getGreen(), a1.getBlue(), a2);
    }
    
    public static Colour fromHSB(final float a1, final float a2, final float a3) {
        /*SL:34*/return new Colour(Color.getHSBColor(a1, a2, a3));
    }
    
    public float getHue() {
        /*SL:38*/return Color.RGBtoHSB(this.getRed(), this.getGreen(), this.getBlue(), null)[0];
    }
    
    public float getSaturation() {
        /*SL:42*/return Color.RGBtoHSB(this.getRed(), this.getGreen(), this.getBlue(), null)[1];
    }
    
    public float getBrightness() {
        /*SL:46*/return Color.RGBtoHSB(this.getRed(), this.getGreen(), this.getBlue(), null)[2];
    }
    
    public void glColor() {
        /*SL:50*/GlStateManager.func_179131_c(this.getRed() / 255.0f, this.getGreen() / 255.0f, this.getBlue() / 255.0f, this.getAlpha() / 255.0f);
    }
}
