package me.dev.legacy.api.util;

public interface INameable
{
    String getName();
    
    String getDisplayName();
    
    void setName(String p0);
    
    void setDisplayName(String p0);
}
