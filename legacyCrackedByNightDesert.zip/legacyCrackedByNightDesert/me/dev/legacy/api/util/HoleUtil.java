package me.dev.legacy.api.util;

import java.util.Arrays;
import java.util.Map;
import java.util.HashMap;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.init.Blocks;
import net.minecraft.block.Block;
import java.util.Iterator;
import net.minecraft.util.math.Vec3i;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.Minecraft;
import net.minecraft.util.math.BlockPos;
import java.util.List;

public class HoleUtil
{
    public static final List<BlockPos> holeBlocks;
    private static Minecraft mc;
    public static final Vec3d[] cityOffsets;
    
    public static boolean isInHole() {
        final Vec3d interpolateEntity = /*EL:29*/CombatUtil.interpolateEntity((Entity)HoleUtil.mc.field_71439_g);
        final BlockPos blockPos = /*EL:30*/new BlockPos(interpolateEntity.field_72450_a, interpolateEntity.field_72448_b, interpolateEntity.field_72449_c);
        int n = /*EL:31*/0;
        /*SL:32*/for (final BlockPos v1 : HoleUtil.holeBlocks) {
            /*SL:33*/if (CombatUtil.isHard(HoleUtil.mc.field_71441_e.func_180495_p(blockPos.func_177971_a((Vec3i)v1)).func_177230_c())) {
                /*SL:34*/++n;
            }
        }
        /*SL:37*/return n == 5;
    }
    
    public static BlockSafety isBlockSafe(final Block a1) {
        /*SL:41*/if (a1 == Blocks.field_150357_h) {
            /*SL:42*/return BlockSafety.UNBREAKABLE;
        }
        /*SL:44*/if (a1 == Blocks.field_150343_Z || a1 == Blocks.field_150477_bB || a1 == Blocks.field_150467_bQ) {
            /*SL:45*/return BlockSafety.RESISTANT;
        }
        /*SL:47*/return BlockSafety.BREAKABLE;
    }
    
    public static HoleInfo isHole(final BlockPos a1, final boolean a2, final boolean a3) {
        final HoleInfo v1 = /*EL:51*/new HoleInfo();
        final HashMap<BlockOffset, BlockSafety> v2 = getUnsafeSides(/*EL:52*/a1);
        /*SL:55*/if (v2.containsKey(BlockOffset.DOWN) && v2.remove(BlockOffset.DOWN, BlockSafety.BREAKABLE) && /*EL:56*/!a3) {
            /*SL:57*/v1.setSafety(BlockSafety.BREAKABLE);
            /*SL:58*/return v1;
        }
        int v3 = /*EL:63*/v2.size();
        /*SL:65*/v2.entrySet().removeIf(a1 -> a1.getValue() == BlockSafety.RESISTANT);
        /*SL:68*/if (v2.size() != v3) {
            /*SL:69*/v1.setSafety(BlockSafety.RESISTANT);
        }
        /*SL:72*/v3 = v2.size();
        /*SL:75*/if (v3 == 0) {
            /*SL:76*/v1.setType(HoleType.SINGLE);
            /*SL:77*/v1.setCentre(new AxisAlignedBB(a1));
            /*SL:78*/return v1;
        }
        /*SL:81*/if (v3 == 1 && !a2) {
            /*SL:82*/return isDoubleHole(v1, a1, v2.keySet().stream().findFirst().get());
        }
        /*SL:84*/v1.setSafety(BlockSafety.BREAKABLE);
        /*SL:85*/return v1;
    }
    
    private static HoleInfo isDoubleHole(final HoleInfo a1, final BlockPos a2, final BlockOffset a3) {
        final BlockPos v1 = /*EL:90*/a3.offset(a2);
        final HashMap<BlockOffset, BlockSafety> v2 = getUnsafeSides(/*EL:92*/v1);
        final int v3 = /*EL:94*/v2.size();
        /*SL:96*/v2.entrySet().removeIf(a1 -> a1.getValue() == BlockSafety.RESISTANT);
        /*SL:99*/if (v2.size() != v3) {
            /*SL:100*/a1.setSafety(BlockSafety.RESISTANT);
        }
        /*SL:103*/if (v2.containsKey(BlockOffset.DOWN)) {
            /*SL:104*/a1.setType(HoleType.CUSTOM);
            /*SL:105*/v2.remove(BlockOffset.DOWN);
        }
        /*SL:109*/if (v2.size() > 1) {
            /*SL:110*/a1.setType(HoleType.NONE);
            /*SL:111*/return a1;
        }
        final double v4 = /*EL:115*/Math.min(a2.func_177958_n(), v1.func_177958_n());
        final double v5 = /*EL:116*/Math.max(a2.func_177958_n(), v1.func_177958_n()) + 1;
        final double v6 = /*EL:117*/Math.min(a2.func_177952_p(), v1.func_177952_p());
        final double v7 = /*EL:118*/Math.max(a2.func_177952_p(), v1.func_177952_p()) + 1;
        /*SL:120*/a1.setCentre(new AxisAlignedBB(v4, (double)a2.func_177956_o(), v6, v5, (double)(a2.func_177956_o() + 1), v7));
        /*SL:122*/if (a1.getType() != HoleType.CUSTOM) {
            /*SL:123*/a1.setType(HoleType.DOUBLE);
        }
        /*SL:125*/return a1;
    }
    
    public static HashMap<BlockOffset, BlockSafety> getUnsafeSides(final BlockPos a1) {
        final HashMap<BlockOffset, BlockSafety> v1 = /*EL:129*/new HashMap<BlockOffset, BlockSafety>();
        BlockSafety v2 = isBlockSafe(HoleUtil.mc.field_71441_e.func_180495_p(BlockOffset.DOWN.offset(/*EL:132*/a1)).func_177230_c());
        /*SL:133*/if (v2 != BlockSafety.UNBREAKABLE) {
            /*SL:134*/v1.put(BlockOffset.DOWN, v2);
        }
        /*SL:136*/v2 = isBlockSafe(HoleUtil.mc.field_71441_e.func_180495_p(BlockOffset.NORTH.offset(a1)).func_177230_c());
        /*SL:137*/if (v2 != BlockSafety.UNBREAKABLE) {
            /*SL:138*/v1.put(BlockOffset.NORTH, v2);
        }
        /*SL:140*/v2 = isBlockSafe(HoleUtil.mc.field_71441_e.func_180495_p(BlockOffset.SOUTH.offset(a1)).func_177230_c());
        /*SL:141*/if (v2 != BlockSafety.UNBREAKABLE) {
            /*SL:142*/v1.put(BlockOffset.SOUTH, v2);
        }
        /*SL:144*/v2 = isBlockSafe(HoleUtil.mc.field_71441_e.func_180495_p(BlockOffset.EAST.offset(a1)).func_177230_c());
        /*SL:145*/if (v2 != BlockSafety.UNBREAKABLE) {
            /*SL:146*/v1.put(BlockOffset.EAST, v2);
        }
        /*SL:148*/v2 = isBlockSafe(HoleUtil.mc.field_71441_e.func_180495_p(BlockOffset.WEST.offset(a1)).func_177230_c());
        /*SL:149*/if (v2 != BlockSafety.UNBREAKABLE) {
            /*SL:150*/v1.put(BlockOffset.WEST, v2);
        }
        /*SL:152*/return v1;
    }
    
    static {
        holeBlocks = Arrays.<BlockPos>asList(new BlockPos(0, -1, 0), new BlockPos(0, 0, -1), new BlockPos(-1, 0, 0), new BlockPos(1, 0, 0), new BlockPos(0, 0, 1));
        HoleUtil.mc = Minecraft.func_71410_x();
        cityOffsets = new Vec3d[] { new Vec3d(1.0, 0.0, 0.0), new Vec3d(0.0, 0.0, 1.0), new Vec3d(-1.0, 0.0, 0.0), new Vec3d(0.0, 0.0, -1.0) };
    }
    
    public enum BlockSafety
    {
        UNBREAKABLE, 
        RESISTANT, 
        BREAKABLE;
    }
    
    public enum HoleType
    {
        SINGLE, 
        DOUBLE, 
        CUSTOM, 
        NONE;
    }
    
    public static class HoleInfo
    {
        private HoleType type;
        private BlockSafety safety;
        private AxisAlignedBB centre;
        
        public HoleInfo() {
            this(BlockSafety.UNBREAKABLE, HoleType.NONE);
        }
        
        public HoleInfo(final BlockSafety a1, final HoleType a2) {
            this.type = a2;
            this.safety = a1;
        }
        
        public void setType(final HoleType a1) {
            /*SL:184*/this.type = a1;
        }
        
        public void setSafety(final BlockSafety a1) {
            /*SL:188*/this.safety = a1;
        }
        
        public void setCentre(final AxisAlignedBB a1) {
            /*SL:192*/this.centre = a1;
        }
        
        public HoleType getType() {
            /*SL:196*/return this.type;
        }
        
        public BlockSafety getSafety() {
            /*SL:200*/return this.safety;
        }
        
        public AxisAlignedBB getCentre() {
            /*SL:204*/return this.centre;
        }
    }
    
    public enum BlockOffset
    {
        DOWN(0, -1, 0), 
        UP(0, 1, 0), 
        NORTH(0, 0, -1), 
        EAST(1, 0, 0), 
        SOUTH(0, 0, 1), 
        WEST(-1, 0, 0);
        
        private final int x;
        private final int y;
        private final int z;
        
        private BlockOffset(final int a1, final int a2, final int a3) {
            this.x = a1;
            this.y = a2;
            this.z = a3;
        }
        
        public BlockPos offset(final BlockPos a1) {
            /*SL:227*/return a1.func_177982_a(this.x, this.y, this.z);
        }
        
        public BlockPos forward(final BlockPos a1, final int a2) {
            /*SL:231*/return a1.func_177982_a(this.x * a2, 0, this.z * a2);
        }
        
        public BlockPos backward(final BlockPos a1, final int a2) {
            /*SL:235*/return a1.func_177982_a(-this.x * a2, 0, -this.z * a2);
        }
        
        public BlockPos left(final BlockPos a1, final int a2) {
            /*SL:241*/return a1.func_177982_a(this.z * a2, 0, -this.x * a2);
        }
        
        public BlockPos right(final BlockPos a1, final int a2) {
            /*SL:245*/return a1.func_177982_a(-this.z * a2, 0, this.x * a2);
        }
    }
}
