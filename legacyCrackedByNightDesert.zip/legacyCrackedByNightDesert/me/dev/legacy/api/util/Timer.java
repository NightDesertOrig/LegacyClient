package me.dev.legacy.api.util;

public class Timer
{
    private long current;
    private long time;
    
    public Timer() {
        this.current = -1L;
        this.time = -1L;
    }
    
    public boolean passedS(final double a1) {
        /*SL:9*/return this.getMs(System.nanoTime() - this.time) >= (long)(a1 * 1000.0);
    }
    
    public boolean passedM(final double a1) {
        /*SL:13*/return this.getMs(System.nanoTime() - this.time) >= (long)(a1 * 1000.0 * 60.0);
    }
    
    public boolean passedDms(final double a1) {
        /*SL:17*/return this.getMs(System.nanoTime() - this.time) >= (long)(a1 * 10.0);
    }
    
    public boolean passedDs(final double a1) {
        /*SL:21*/return this.getMs(System.nanoTime() - this.time) >= (long)(a1 * 100.0);
    }
    
    public boolean passedMs(final long a1) {
        /*SL:25*/return this.getMs(System.nanoTime() - this.time) >= a1;
    }
    
    public boolean passedNS(final long a1) {
        /*SL:29*/return System.nanoTime() - this.time >= a1;
    }
    
    public void setMs(final long a1) {
        /*SL:33*/this.time = System.nanoTime() - a1 * 1000000L;
    }
    
    public long getPassedTimeMs() {
        /*SL:37*/return this.getMs(System.nanoTime() - this.time);
    }
    
    public boolean passed(final long a1) {
        /*SL:41*/return System.currentTimeMillis() - this.current >= a1;
    }
    
    public Timer reset() {
        /*SL:45*/this.time = System.nanoTime();
        /*SL:46*/return this;
    }
    
    public long getMs(final long a1) {
        /*SL:50*/return a1 / 1000000L;
    }
    
    public boolean hasReached(final long a1) {
        /*SL:54*/return System.currentTimeMillis() - this.current >= a1;
    }
    
    public boolean hasReached(final long a1, final boolean a2) {
        /*SL:58*/if (a2) {
            /*SL:59*/this.reset();
        }
        /*SL:60*/return System.currentTimeMillis() - this.current >= a1;
    }
    
    public boolean sleep(final long a1) {
        /*SL:64*/if (System.nanoTime() / 1000000L - a1 >= a1) {
            /*SL:65*/this.reset();
            /*SL:66*/return true;
        }
        /*SL:68*/return false;
    }
    
    public final boolean hasReachedRealth(final long a1) {
        /*SL:72*/return System.currentTimeMillis() - this.current >= a1;
    }
    
    public boolean hasReachedRealth(final long a1, final boolean a2) {
        /*SL:76*/if (a2) {
            /*SL:77*/this.reset();
        }
        /*SL:78*/return System.currentTimeMillis() - this.current >= a1;
    }
    
    public final void resetRealth() {
        /*SL:82*/this.current = System.currentTimeMillis();
    }
    
    public void resetTimeSkipTo(final long a1) {
        /*SL:87*/this.time = System.currentTimeMillis() + a1;
    }
}
