package me.dev.legacy.api.util;

import java.util.Arrays;
import java.util.ArrayList;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.util.math.MathHelper;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.EnumActionResult;
import net.minecraft.network.Packet;
import net.minecraft.entity.Entity;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.Vec3i;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.Vec3d;
import net.minecraft.block.BlockSlab;
import net.minecraft.util.math.BlockPos;
import net.minecraft.client.Minecraft;
import net.minecraft.block.Block;
import java.util.List;

public class BlockInteractionUtil
{
    public static final List<Block> blackList;
    public static final List<Block> shulkerList;
    private static final Minecraft mc;
    
    public static PlaceResult place(final BlockPos v-11, final float v-10, final boolean v-9, final boolean v-8) {
        final IBlockState func_180495_p = BlockInteractionUtil.mc.field_71441_e.func_180495_p(/*EL:46*/v-11);
        final boolean func_76222_j = /*EL:48*/func_180495_p.func_185904_a().func_76222_j();
        final boolean b = /*EL:50*/func_180495_p.func_177230_c() instanceof BlockSlab;
        /*SL:52*/if (!func_76222_j && !b) {
            /*SL:53*/return PlaceResult.NotReplaceable;
        }
        /*SL:54*/if (!checkForNeighbours(v-11)) {
            /*SL:55*/return PlaceResult.Neighbors;
        }
        /*SL:59*/if (v-8 && b && !func_180495_p.func_185917_h()) {
            /*SL:60*/return PlaceResult.CantPlace;
        }
        final Vec3d vec3d = /*EL:63*/new Vec3d(BlockInteractionUtil.mc.field_71439_g.field_70165_t, BlockInteractionUtil.mc.field_71439_g.field_70163_u + BlockInteractionUtil.mc.field_71439_g.func_70047_e(), BlockInteractionUtil.mc.field_71439_g.field_70161_v);
        /*SL:65*/for (final EnumFacing v0 : EnumFacing.values()) {
            final BlockPos v = /*EL:66*/v-11.func_177972_a(v0);
            final EnumFacing v2 = /*EL:67*/v0.func_176734_d();
            /*SL:69*/if (BlockInteractionUtil.mc.field_71441_e.func_180495_p(v).func_177230_c().func_176209_a(BlockInteractionUtil.mc.field_71441_e.func_180495_p(v), false)) {
                Vec3d a4 = /*EL:70*/new Vec3d((Vec3i)v).func_72441_c(0.5, 0.5, 0.5).func_178787_e(new Vec3d(v2.func_176730_m()).func_186678_a(0.5));
                /*SL:71*/if (vec3d.func_72438_d(a4) <= v-10) {
                    final Block a2 = BlockInteractionUtil.mc.field_71441_e.func_180495_p(/*EL:73*/v).func_177230_c();
                    final boolean a3 = /*EL:75*/a2.func_180639_a((World)BlockInteractionUtil.mc.field_71441_e, v-11, BlockInteractionUtil.mc.field_71441_e.func_180495_p(v-11), (EntityPlayer)BlockInteractionUtil.mc.field_71439_g, EnumHand.MAIN_HAND, v0, 0.0f, 0.0f, 0.0f);
                    /*SL:77*/if (BlockInteractionUtil.blackList.contains(a2) || BlockInteractionUtil.shulkerList.contains(a2) || a3) {
                        BlockInteractionUtil.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:79*/(Packet)new CPacketEntityAction((Entity)BlockInteractionUtil.mc.field_71439_g, CPacketEntityAction.Action.START_SNEAKING));
                    }
                    /*SL:81*/if (v-9) {
                        faceVectorPacketInstant(/*EL:83*/a4);
                    }
                    /*SL:85*/a4 = BlockInteractionUtil.mc.field_71442_b.func_187099_a(BlockInteractionUtil.mc.field_71439_g, BlockInteractionUtil.mc.field_71441_e, v, v2, a4, EnumHand.MAIN_HAND);
                    /*SL:87*/if (a4 != EnumActionResult.FAIL) {
                        BlockInteractionUtil.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
                        /*SL:90*/if (a3) {
                            BlockInteractionUtil.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:92*/(Packet)new CPacketEntityAction((Entity)BlockInteractionUtil.mc.field_71439_g, CPacketEntityAction.Action.STOP_SNEAKING));
                        }
                        /*SL:94*/return PlaceResult.Placed;
                    }
                }
            }
        }
        /*SL:99*/return PlaceResult.CantPlace;
    }
    
    public static ValidResult valid(final BlockPos v-10) {
        /*SL:105*/if (!BlockInteractionUtil.mc.field_71441_e.func_72855_b(new AxisAlignedBB(v-10))) {
            /*SL:106*/return ValidResult.NoEntityCollision;
        }
        /*SL:108*/if (!checkForNeighbours(v-10)) {
            /*SL:109*/return ValidResult.NoNeighbors;
        }
        final IBlockState func_180495_p = BlockInteractionUtil.mc.field_71441_e.func_180495_p(/*EL:111*/v-10);
        /*SL:113*/if (func_180495_p.func_177230_c() == Blocks.field_150350_a) {
            final BlockPos[] array2;
            final BlockPos[] array = /*EL:118*/array2 = new BlockPos[] { v-10.func_177978_c(), v-10.func_177968_d(), v-10.func_177974_f(), v-10.func_177976_e(), v-10.func_177984_a(), v-10.func_177977_b() };
            for (final BlockPos blockPos : array2) {
                final IBlockState func_180495_p2 = BlockInteractionUtil.mc.field_71441_e.func_180495_p(/*EL:120*/blockPos);
                /*SL:122*/if (func_180495_p2.func_177230_c() != Blocks.field_150350_a) {
                    /*SL:125*/for (final EnumFacing v1 : EnumFacing.values()) {
                        final BlockPos a1 = /*EL:127*/v-10.func_177972_a(v1);
                        /*SL:129*/if (BlockInteractionUtil.mc.field_71441_e.func_180495_p(a1).func_177230_c().func_176209_a(BlockInteractionUtil.mc.field_71441_e.func_180495_p(a1), false)) {
                            /*SL:131*/return ValidResult.Ok;
                        }
                    }
                }
            }
            /*SL:136*/return ValidResult.NoNeighbors;
        }
        /*SL:139*/return ValidResult.AlreadyBlockThere;
    }
    
    public static float[] getLegitRotations(final Vec3d a1) {
        final Vec3d v1 = getEyesPos();
        final double v2 = /*EL:144*/a1.field_72450_a - v1.field_72450_a;
        final double v3 = /*EL:145*/a1.field_72448_b - v1.field_72448_b;
        final double v4 = /*EL:146*/a1.field_72449_c - v1.field_72449_c;
        final double v5 = /*EL:147*/Math.sqrt(v2 * v2 + v4 * v4);
        final float v6 = /*EL:148*/(float)Math.toDegrees(Math.atan2(v4, v2)) - 90.0f;
        final float v7 = /*EL:149*/(float)(-Math.toDegrees(Math.atan2(v3, v5)));
        /*SL:150*/return new float[] { BlockInteractionUtil.mc.field_71439_g.field_70177_z + MathHelper.func_76142_g(v6 - BlockInteractionUtil.mc.field_71439_g.field_70177_z), BlockInteractionUtil.mc.field_71439_g.field_70125_A + MathHelper.func_76142_g(v7 - BlockInteractionUtil.mc.field_71439_g.field_70125_A) };
    }
    
    private static Vec3d getEyesPos() {
        /*SL:154*/return new Vec3d(BlockInteractionUtil.mc.field_71439_g.field_70165_t, BlockInteractionUtil.mc.field_71439_g.field_70163_u + BlockInteractionUtil.mc.field_71439_g.func_70047_e(), BlockInteractionUtil.mc.field_71439_g.field_70161_v);
    }
    
    public static void faceVectorPacketInstant(final Vec3d a1) {
        final float[] v1 = getLegitRotations(/*EL:158*/a1);
        BlockInteractionUtil.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:160*/(Packet)new CPacketPlayer.Rotation(v1[0], v1[1], BlockInteractionUtil.mc.field_71439_g.field_70122_E));
    }
    
    public static boolean canBeClicked(final BlockPos a1) {
        /*SL:164*/return getBlock(a1).func_176209_a(getState(a1), false);
    }
    
    private static Block getBlock(final BlockPos a1) {
        /*SL:168*/return getState(a1).func_177230_c();
    }
    
    private static IBlockState getState(final BlockPos a1) {
        /*SL:172*/return BlockInteractionUtil.mc.field_71441_e.func_180495_p(a1);
    }
    
    public static boolean checkForNeighbours(final BlockPos v-3) {
        /*SL:176*/if (!hasNeighbour(v-3)) {
            /*SL:177*/for (final EnumFacing v1 : EnumFacing.values()) {
                final BlockPos a1 = /*EL:178*/v-3.func_177972_a(v1);
                /*SL:179*/if (hasNeighbour(a1)) {
                    /*SL:180*/return true;
                }
            }
            /*SL:183*/return false;
        }
        /*SL:185*/return true;
    }
    
    private static boolean hasNeighbour(final BlockPos v-3) {
        /*SL:189*/for (final EnumFacing v1 : EnumFacing.values()) {
            final BlockPos a1 = /*EL:190*/v-3.func_177972_a(v1);
            /*SL:191*/if (!BlockInteractionUtil.mc.field_71441_e.func_180495_p(a1).func_185904_a().func_76222_j()) {
                /*SL:192*/return true;
            }
        }
        /*SL:195*/return false;
    }
    
    public static List<BlockPos> getSphere(final BlockPos a6, final float v1, final int v2, final boolean v3, final boolean v4, final int v5) {
        final ArrayList<BlockPos> v6 = /*EL:199*/new ArrayList<BlockPos>();
        final int v7 = /*EL:200*/a6.func_177958_n();
        final int v8 = /*EL:201*/a6.func_177956_o();
        final int v9 = /*EL:202*/a6.func_177952_p();
        /*SL:204*/for (int v10 = v7 - (int)v1; v10 <= v7 + v1; /*SL:220*/++v10) {
            for (int a7 = v9 - (int)v1; a7 <= v9 + v1; ++a7) {
                int a8 = v4 ? (v8 - (int)v1) : v8;
                while (true) {
                    final float a9 = v4 ? (v8 + v1) : (v8 + v2);
                    if (a8 >= a9) {
                        break;
                    }
                    final double a10 = (v7 - v10) * (v7 - v10) + (v9 - a7) * (v9 - a7) + (v4 ? ((v8 - a8) * (v8 - a8)) : 0);
                    if (a10 < v1 * v1 && (!v3 || a10 >= (v1 - 1.0f) * (v1 - 1.0f))) {
                        final BlockPos a11 = new BlockPos(v10, a8 + v5, a7);
                        v6.add(a11);
                    }
                    ++a8;
                }
            }
        }
        /*SL:222*/return v6;
    }
    
    static {
        blackList = Arrays.<Block>asList(Blocks.field_150477_bB, Blocks.field_150486_ae, Blocks.field_150447_bR, Blocks.field_150462_ai, Blocks.field_150467_bQ, Blocks.field_150382_bo, Blocks.field_150438_bZ, Blocks.field_150409_cd, Blocks.field_150367_z);
        shulkerList = Arrays.<Block>asList(Blocks.field_190977_dl, Blocks.field_190978_dm, Blocks.field_190979_dn, Blocks.field_190980_do, Blocks.field_190981_dp, Blocks.field_190982_dq, Blocks.field_190983_dr, Blocks.field_190984_ds, Blocks.field_190985_dt, Blocks.field_190986_du, Blocks.field_190987_dv, Blocks.field_190988_dw, Blocks.field_190989_dx, Blocks.field_190990_dy, Blocks.field_190991_dz, Blocks.field_190975_dA);
        mc = Minecraft.func_71410_x();
    }
    
    public enum ValidResult
    {
        NoEntityCollision, 
        AlreadyBlockThere, 
        NoNeighbors, 
        Ok;
    }
    
    public enum PlaceResult
    {
        NotReplaceable, 
        Neighbors, 
        CantPlace, 
        Placed;
    }
}
