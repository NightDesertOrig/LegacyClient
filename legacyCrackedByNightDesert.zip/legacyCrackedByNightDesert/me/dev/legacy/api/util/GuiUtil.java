package me.dev.legacy.api.util;

import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.Minecraft;
import me.dev.legacy.Legacy;

public class GuiUtil
{
    public static void drawString(final String a1, final float a2, final float a3, final int a4) {
        /*SL:12*/if (Legacy.moduleManager.getModuleByName("CustomFont").isEnabled()) {
            Legacy.fontRenderer.drawStringWithShadow(/*EL:13*/a1, a2, a3, a4);
        }
        else {
            /*SL:15*/Minecraft.func_71410_x().field_71466_p.func_175063_a(a1, a2, a3, a4);
        }
    }
    
    public static int getStringWidth(final String a1) {
        /*SL:20*/return Minecraft.func_71410_x().field_71466_p.func_78256_a(a1);
    }
    
    public static void drawHorizontalLine(int a2, int a3, final int a4, final int v1) {
        /*SL:24*/if (a3 < a2) {
            final int a5 = /*EL:25*/a2;
            /*SL:26*/a2 = a3;
            /*SL:27*/a3 = a5;
        }
        drawRect(/*EL:29*/a2, a4, a3 + 1, a4 + 1, v1);
    }
    
    public static void drawString(final String a1, final int a2, final int a3, final int a4) {
        /*SL:33*/if (Legacy.moduleManager.getModuleByName("CustomFont").isEnabled()) {
            Legacy.fontRenderer.drawStringWithShadow(/*EL:34*/a1, a2, a3, a4);
        }
        else {
            /*SL:36*/Minecraft.func_71410_x().field_71466_p.func_175063_a(a1, (float)a2, (float)a3, a4);
        }
    }
    
    public static String getCFont() {
        /*SL:41*/return Legacy.fontRenderer.getFont().getFamily();
    }
    
    public static void drawRect(int a3, int a4, int a5, int v1, final int v2) {
        /*SL:45*/if (a3 < a5) {
            final int a6 = /*EL:46*/a3;
            /*SL:47*/a3 = a5;
            /*SL:48*/a5 = a6;
        }
        /*SL:50*/if (a4 < v1) {
            final int a7 = /*EL:51*/a4;
            /*SL:52*/a4 = v1;
            /*SL:53*/v1 = a7;
        }
        final float v3 = /*EL:55*/(v2 >> 24 & 0xFF) / 255.0f;
        final float v4 = /*EL:56*/(v2 >> 16 & 0xFF) / 255.0f;
        final float v5 = /*EL:57*/(v2 >> 8 & 0xFF) / 255.0f;
        final float v6 = /*EL:58*/(v2 & 0xFF) / 255.0f;
        final Tessellator v7 = /*EL:59*/Tessellator.func_178181_a();
        final BufferBuilder v8 = /*EL:60*/v7.func_178180_c();
        /*SL:61*/GlStateManager.func_179147_l();
        /*SL:62*/GlStateManager.func_179090_x();
        /*SL:63*/GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        /*SL:64*/GlStateManager.func_179131_c(v4, v5, v6, v3);
        /*SL:65*/v8.func_181668_a(7, DefaultVertexFormats.field_181705_e);
        /*SL:66*/v8.func_181662_b((double)a3, (double)v1, 0.0).func_181675_d();
        /*SL:67*/v8.func_181662_b((double)a5, (double)v1, 0.0).func_181675_d();
        /*SL:68*/v8.func_181662_b((double)a5, (double)a4, 0.0).func_181675_d();
        /*SL:69*/v8.func_181662_b((double)a3, (double)a4, 0.0).func_181675_d();
        /*SL:70*/v7.func_78381_a();
        /*SL:71*/GlStateManager.func_179098_w();
        /*SL:72*/GlStateManager.func_179084_k();
    }
    
    public static int getHeight() {
        /*SL:76*/return Legacy.moduleManager.getModuleByName("CustomFont").isEnabled() ? Legacy.fontRenderer.getHeight() : Legacy.fontRenderer.getHeight();
    }
    
    public static void drawVerticalLine(final int a2, int a3, int a4, final int v1) {
        /*SL:80*/if (a4 < a3) {
            final int a5 = /*EL:81*/a3;
            /*SL:82*/a3 = a4;
            /*SL:83*/a4 = a5;
        }
        drawRect(/*EL:85*/a2, a3 + 1, a2 + 1, a4, v1);
    }
    
    public static void drawCenteredString(final String a1, final int a2, final int a3, final int a4) {
        /*SL:89*/if (Legacy.moduleManager.getModuleByName("CustomFont").isEnabled()) {
            Legacy.fontRenderer.drawStringWithShadow(/*EL:90*/a1, a2 - Legacy.fontRenderer.getStringWidth(a1) / 2, a3, a4);
        }
        else {
            /*SL:92*/Minecraft.func_71410_x().field_71466_p.func_175063_a(a1, (float)(a2 - Legacy.fontRenderer.getStringWidth(a1) / 2), (float)a3, a4);
        }
    }
}
