package me.dev.legacy.api.util;

import java.awt.Color;
import org.lwjgl.opengl.GL11;

public class ColorHolder
{
    int r;
    int g;
    int b;
    int a;
    
    public ColorHolder(final int a1, final int a2, final int a3) {
        this.r = a1;
        this.g = a2;
        this.b = a3;
        this.a = 255;
    }
    
    public ColorHolder(final int a1, final int a2, final int a3, final int a4) {
        this.r = a1;
        this.g = a2;
        this.b = a3;
        this.a = a4;
    }
    
    public ColorHolder brighter() {
        /*SL:32*/return new ColorHolder(Math.min(this.r + 10, 255), Math.min(this.g + 10, 255), Math.min(this.b + 10, 255), this.getA());
    }
    
    public ColorHolder darker() {
        /*SL:36*/return new ColorHolder(Math.max(this.r - 10, 0), Math.max(this.g - 10, 0), Math.max(this.b - 10, 0), this.getA());
    }
    
    public void setGLColour() {
        /*SL:40*/this.setGLColour(-1, -1, -1, -1);
    }
    
    public void setGLColour(final int a1, final int a2, final int a3, final int a4) {
        /*SL:44*/GL11.glColor4f(((a1 == -1) ? this.r : a1) / 255.0f, ((a2 == -1) ? this.g : a2) / 255.0f, ((a3 == -1) ? this.b : a3) / 255.0f, ((a4 == -1) ? this.a : a4) / 255.0f);
    }
    
    public void becomeGLColour() {
    }
    
    public void becomeHex(final int a1) {
        /*SL:54*/this.setR((a1 & 0xFF0000) >> 16);
        /*SL:55*/this.setG((a1 & 0xFF00) >> 8);
        /*SL:56*/this.setB(a1 & 0xFF);
        /*SL:57*/this.setA(255);
    }
    
    public static ColorHolder fromHex(final int a1) {
        final ColorHolder v1 = /*EL:61*/new ColorHolder(0, 0, 0);
        /*SL:62*/v1.becomeHex(a1);
        /*SL:63*/return v1;
    }
    
    public static int toHex(final int a1, final int a2, final int a3) {
        /*SL:67*/return 0xFF000000 | (a1 & 0xFF) << 16 | (a2 & 0xFF) << 8 | (a3 & 0xFF);
    }
    
    public int toHex() {
        /*SL:71*/return toHex(this.r, this.g, this.b);
    }
    
    public int getB() {
        /*SL:75*/return this.b;
    }
    
    public int getG() {
        /*SL:79*/return this.g;
    }
    
    public int getR() {
        /*SL:83*/return this.r;
    }
    
    public int getA() {
        /*SL:87*/return this.a;
    }
    
    public ColorHolder setR(final int a1) {
        /*SL:91*/this.r = a1;
        /*SL:92*/return this;
    }
    
    public ColorHolder setB(final int a1) {
        /*SL:96*/this.b = a1;
        /*SL:97*/return this;
    }
    
    public ColorHolder setG(final int a1) {
        /*SL:101*/this.g = a1;
        /*SL:102*/return this;
    }
    
    public ColorHolder setA(final int a1) {
        /*SL:106*/this.a = a1;
        /*SL:107*/return this;
    }
    
    public ColorHolder clone() {
        /*SL:112*/return new ColorHolder(this.r, this.g, this.b, this.a);
    }
    
    public Color toJavaColour() {
        /*SL:116*/return new Color(this.r, this.g, this.b, this.a);
    }
}
