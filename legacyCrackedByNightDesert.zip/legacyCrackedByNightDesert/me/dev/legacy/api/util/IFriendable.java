package me.dev.legacy.api.util;

public interface IFriendable
{
    String getAlias();
    
    void setAlias(String p0);
}
