package me.dev.legacy.api.util;

import net.minecraft.entity.player.EntityPlayer;
import java.io.IOException;
import java.util.Arrays;
import org.apache.commons.io.IOUtils;
import com.mojang.util.UUIDTypeAdapter;
import me.dev.legacy.impl.command.Command;
import java.util.Collection;
import net.minecraft.client.network.NetworkPlayerInfo;
import java.util.ArrayList;
import java.util.Objects;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketEntityAction;
import me.dev.legacy.api.event.events.other.PacketEvent;
import net.minecraft.advancements.AdvancementManager;
import java.io.DataOutputStream;
import javax.net.ssl.HttpsURLConnection;
import net.minecraft.block.Block;
import net.minecraft.block.BlockObsidian;
import net.minecraft.block.BlockEnderChest;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import com.google.gson.JsonObject;
import java.util.Iterator;
import com.google.gson.JsonArray;
import java.util.Collections;
import java.util.Date;
import com.google.gson.JsonElement;
import com.google.common.collect.Lists;
import java.util.List;
import java.util.Scanner;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.BufferedInputStream;
import java.nio.charset.StandardCharsets;
import java.net.HttpURLConnection;
import java.net.URL;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.potion.Potion;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import java.util.UUID;
import com.google.gson.JsonParser;

public class PlayerUtil implements Util
{
    private static final JsonParser PARSER;
    private static boolean shifting;
    private static boolean switching;
    private int slot;
    
    public static String getNameFromUUID(final UUID v-1) {
        try {
            final lookUpName a1 = /*EL:41*/new lookUpName(v-1);
            final Thread v1 = /*EL:42*/new Thread(a1);
            /*SL:43*/v1.start();
            /*SL:44*/v1.join();
            /*SL:45*/return a1.getName();
        }
        catch (Exception v2) {
            /*SL:47*/return null;
        }
    }
    
    public static BlockPos getPlayerPos() {
        /*SL:52*/return new BlockPos(Math.floor(PlayerUtil.mc.field_71439_g.field_70165_t), Math.floor(PlayerUtil.mc.field_71439_g.field_70163_u), Math.floor(PlayerUtil.mc.field_71439_g.field_70161_v));
    }
    
    public static boolean isInHole(final Entity a1) {
        final BlockPos v1 = /*EL:56*/new BlockPos(Math.floor(a1.func_174791_d().field_72450_a), Math.floor(a1.func_174791_d().field_72448_b + 0.2), Math.floor(a1.func_174791_d().field_72449_c));
        /*SL:57*/return PlayerUtil.mc.field_71441_e.func_180495_p(v1.func_177977_b()).func_177230_c().field_149781_w >= 1200.0f && PlayerUtil.mc.field_71441_e.func_180495_p(v1.func_177974_f()).func_177230_c().field_149781_w >= 1200.0f && PlayerUtil.mc.field_71441_e.func_180495_p(v1.func_177976_e()).func_177230_c().field_149781_w >= 1200.0f && PlayerUtil.mc.field_71441_e.func_180495_p(v1.func_177978_c()).func_177230_c().field_149781_w >= 1200.0f && PlayerUtil.mc.field_71441_e.func_180495_p(v1.func_177968_d()).func_177230_c().field_149781_w >= 1200.0f;
    }
    
    public static double getBaseMoveSpeed() {
        double n = /*EL:61*/0.2873;
        /*SL:62*/if (PlayerUtil.mc.field_71439_g != null && PlayerUtil.mc.field_71439_g.func_70644_a(Potion.func_188412_a(1))) {
            final int v1 = PlayerUtil.mc.field_71439_g.func_70660_b(/*EL:63*/Potion.func_188412_a(1)).func_76458_c();
            /*SL:64*/n *= 1.0 + 0.2 * (v1 + 1);
        }
        /*SL:66*/return n;
    }
    
    public static boolean isMoving(final EntityLivingBase a1) {
        /*SL:70*/return a1.field_191988_bg != 0.0f || a1.field_70702_br != 0.0f;
    }
    
    public static void setSpeed(final EntityLivingBase a1, final double a2) {
        final double[] v1 = forward(/*EL:74*/a2);
        /*SL:75*/a1.field_70159_w = v1[0];
        /*SL:76*/a1.field_70179_y = v1[1];
    }
    
    public static double[] forward(final double a1) {
        float v1 = PlayerUtil.mc.field_71439_g.field_71158_b.field_192832_b;
        float v2 = PlayerUtil.mc.field_71439_g.field_71158_b.field_78902_a;
        float v3 = PlayerUtil.mc.field_71439_g.field_70126_B + (PlayerUtil.mc.field_71439_g.field_70177_z - PlayerUtil.mc.field_71439_g.field_70126_B) * PlayerUtil.mc.func_184121_ak();
        /*SL:83*/if (v1 != 0.0f) {
            /*SL:84*/if (v2 > 0.0f) {
                /*SL:85*/v3 += ((v1 > 0.0f) ? -45 : 45);
            }
            else/*SL:86*/ if (v2 < 0.0f) {
                /*SL:87*/v3 += ((v1 > 0.0f) ? 45 : -45);
            }
            /*SL:89*/v2 = 0.0f;
            /*SL:90*/if (v1 > 0.0f) {
                /*SL:91*/v1 = 1.0f;
            }
            else/*SL:92*/ if (v1 < 0.0f) {
                /*SL:93*/v1 = -1.0f;
            }
        }
        final double v4 = /*EL:96*/Math.sin(Math.toRadians(v3 + 90.0f));
        final double v5 = /*EL:97*/Math.cos(Math.toRadians(v3 + 90.0f));
        final double v6 = /*EL:98*/v1 * a1 * v5 + v2 * a1 * v4;
        final double v7 = /*EL:99*/v1 * a1 * v4 - v2 * a1 * v5;
        /*SL:100*/return new double[] { v6, v7 };
    }
    
    public static String getNameFromUUID(final String v-1) {
        try {
            final lookUpName a1 = /*EL:106*/new lookUpName(v-1);
            final Thread v1 = /*EL:107*/new Thread(a1);
            /*SL:108*/v1.start();
            /*SL:109*/v1.join();
            /*SL:110*/return a1.getName();
        }
        catch (Exception v2) {
            /*SL:112*/return null;
        }
    }
    
    public static UUID getUUIDFromName(final String v-1) {
        try {
            final lookUpUUID a1 = /*EL:118*/new lookUpUUID(v-1);
            final Thread v1 = /*EL:119*/new Thread(a1);
            /*SL:120*/v1.start();
            /*SL:121*/v1.join();
            /*SL:122*/return a1.getUUID();
        }
        catch (Exception v2) {
            /*SL:124*/return null;
        }
    }
    
    public static String requestIDs(final String v-1) {
        try {
            final String a1 = /*EL:130*/"https://api.mojang.com/profiles/minecraft";
            final URL v1 = /*EL:131*/new URL(a1);
            final HttpURLConnection v2 = /*EL:132*/(HttpURLConnection)v1.openConnection();
            /*SL:133*/v2.setConnectTimeout(5000);
            /*SL:134*/v2.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            /*SL:135*/v2.setDoOutput(true);
            /*SL:136*/v2.setDoInput(true);
            /*SL:137*/v2.setRequestMethod("POST");
            final OutputStream v3 = /*EL:138*/v2.getOutputStream();
            /*SL:139*/v3.write(v-1.getBytes(StandardCharsets.UTF_8));
            /*SL:140*/v3.close();
            final InputStream v4 = /*EL:141*/new BufferedInputStream(v2.getInputStream());
            final String v5 = convertStreamToString(/*EL:142*/v4);
            /*SL:143*/v4.close();
            /*SL:144*/v2.disconnect();
            /*SL:145*/return v5;
        }
        catch (Exception v6) {
            /*SL:147*/return null;
        }
    }
    
    public static String convertStreamToString(final InputStream a1) {
        final Scanner v1 = /*EL:152*/new Scanner(a1).useDelimiter("\\A");
        /*SL:153*/return v1.hasNext() ? v1.next() : "/";
    }
    
    public static List<String> getHistoryOfNames(final UUID v-5) {
        try {
            final JsonArray asJsonArray = getResources(/*EL:158*/new URL("https://api.mojang.com/user/profiles/" + getIdNoHyphens(v-5) + "/names"), "GET").getAsJsonArray();
            final List<String> arrayList = /*EL:159*/(List<String>)Lists.<Object>newArrayList();
            /*SL:160*/for (final JsonElement jsonElement : asJsonArray) {
                final JsonObject a1 = /*EL:161*/jsonElement.getAsJsonObject();
                final String v1 = /*EL:162*/a1.get("name").getAsString();
                final long v2 = /*EL:163*/a1.has("changedToAt") ? a1.get("changedToAt").getAsLong() : 0L;
                /*SL:164*/arrayList.add(v1 + "\u0413\u201a\u0412�8" + new Date(v2).toString());
            }
            /*SL:166*/Collections.<String>sort(arrayList);
            /*SL:167*/return arrayList;
        }
        catch (Exception ex) {
            /*SL:169*/return null;
        }
    }
    
    public static int findObiInHotbar() {
        /*SL:174*/for (int i = 0; i < 9; ++i) {
            final ItemStack v0 = PlayerUtil.mc.field_71439_g.field_71071_by.func_70301_a(/*EL:175*/i);
            /*SL:176*/if (v0 != ItemStack.field_190927_a && v0.func_77973_b() instanceof ItemBlock) {
                final Block v = /*EL:177*/((ItemBlock)v0.func_77973_b()).func_179223_d();
                /*SL:178*/if (v instanceof BlockEnderChest) {
                    /*SL:179*/return i;
                }
                /*SL:180*/if (v instanceof BlockObsidian) {
                    /*SL:181*/return i;
                }
            }
        }
        /*SL:184*/return -1;
    }
    
    public static String getIdNoHyphens(final UUID a1) {
        /*SL:188*/return a1.toString().replaceAll("-", "");
    }
    
    private static JsonElement getResources(final URL a1, final String a2) throws Exception {
        /*SL:192*/return getResources(a1, a2, null);
    }
    
    private static JsonElement getResources(final URL v-5, final String v-4, final JsonElement v-3) throws Exception {
        HttpsURLConnection httpsURLConnection = /*EL:196*/null;
        try {
            /*SL:198*/httpsURLConnection = (HttpsURLConnection)v-5.openConnection();
            /*SL:199*/httpsURLConnection.setDoOutput(true);
            /*SL:200*/httpsURLConnection.setRequestMethod(v-4);
            /*SL:201*/httpsURLConnection.setRequestProperty("Content-Type", "application/json");
            /*SL:202*/if (v-3 != null) {
                final DataOutputStream a1 = /*EL:203*/new DataOutputStream(httpsURLConnection.getOutputStream());
                /*SL:204*/a1.writeBytes(AdvancementManager.field_192783_b.toJson(v-3));
                /*SL:205*/a1.close();
            }
            final Scanner a2 = /*EL:207*/new Scanner(httpsURLConnection.getInputStream());
            final StringBuilder a3 = /*EL:208*/new StringBuilder();
            /*SL:209*/while (a2.hasNextLine()) {
                /*SL:210*/a3.append(a2.nextLine());
                /*SL:211*/a3.append('\n');
            }
            /*SL:213*/a2.close();
            final String v1 = /*EL:214*/a3.toString();
            final JsonElement v2 = PlayerUtil.PARSER.parse(/*EL:215*/v1);
            /*SL:216*/return v2;
        }
        finally {
            /*SL:218*/if (httpsURLConnection != null) {
                /*SL:219*/httpsURLConnection.disconnect();
            }
        }
    }
    
    public void onPacketSend(final PacketEvent.Send v2) {
        /*SL:321*/if (v2.getPacket() instanceof CPacketEntityAction) {
            final CPacketEntityAction a1 = /*EL:322*/(CPacketEntityAction)v2.getPacket();
            /*SL:323*/if (a1.func_180764_b() == CPacketEntityAction.Action.START_SNEAKING) {
                PlayerUtil.shifting = /*EL:324*/true;
            }
            else/*SL:325*/ if (a1.func_180764_b() == CPacketEntityAction.Action.STOP_SNEAKING) {
                PlayerUtil.shifting = /*EL:326*/false;
            }
        }
        /*SL:330*/if (v2.getPacket() instanceof CPacketHeldItemChange) {
            /*SL:331*/this.slot = ((CPacketHeldItemChange)v2.getPacket()).func_149614_c();
        }
    }
    
    public void setSwitching(final boolean a1) {
        PlayerUtil.switching = /*EL:336*/a1;
    }
    
    public static boolean isShifting() {
        /*SL:340*/return PlayerUtil.shifting;
    }
    
    public int getSlot() {
        /*SL:344*/return this.slot;
    }
    
    static {
        PARSER = new JsonParser();
    }
    
    public static class lookUpUUID implements Runnable
    {
        private final String name;
        private volatile UUID uuid;
        
        public lookUpUUID(final String a1) {
            this.name = a1;
        }
        
        @Override
        public void run() {
            NetworkPlayerInfo v2;
            try {
                final ArrayList<NetworkPlayerInfo> v1 = /*EL:234*/new ArrayList<NetworkPlayerInfo>(Objects.<NetHandlerPlayClient>requireNonNull(Util.mc.func_147114_u()).func_175106_d());
                /*SL:235*/v2 = v1.stream().filter(a1 -> a1.func_178845_a().getName().equalsIgnoreCase(this.name)).findFirst().orElse(null);
                /*SL:236*/assert v2 != null;
                /*SL:237*/this.uuid = v2.func_178845_a().getId();
            }
            catch (Exception v7) {
                /*SL:239*/v2 = null;
            }
            /*SL:241*/if (v2 == null) {
                /*SL:242*/Command.sendMessage("Player isn't online. Looking up UUID..");
                final String v3 = /*EL:243*/PlayerUtil.requestIDs("[\"" + this.name + "\"]");
                /*SL:244*/if (v3 == null || v3.isEmpty()) {
                    /*SL:245*/Command.sendMessage("Couldn't find player ID. Are you connected to the internet? (0)");
                }
                else {
                    final JsonElement v4 = /*EL:247*/new JsonParser().parse(v3);
                    /*SL:248*/if (v4.getAsJsonArray().size() == 0) {
                        /*SL:249*/Command.sendMessage("Couldn't find player ID. (1)");
                    }
                    else {
                        try {
                            final String v5 = /*EL:252*/v4.getAsJsonArray().get(0).getAsJsonObject().get("id").getAsString();
                            /*SL:253*/this.uuid = UUIDTypeAdapter.fromString(v5);
                        }
                        catch (Exception v6) {
                            /*SL:255*/v6.printStackTrace();
                            /*SL:256*/Command.sendMessage("Couldn't find player ID. (2)");
                        }
                    }
                }
            }
        }
        
        public UUID getUUID() {
            /*SL:264*/return this.uuid;
        }
        
        public String getName() {
            /*SL:268*/return this.name;
        }
    }
    
    public static class lookUpName implements Runnable
    {
        private final String uuid;
        private final UUID uuidID;
        private volatile String name;
        
        public lookUpName(final String a1) {
            this.uuid = a1;
            this.uuidID = UUID.fromString(a1);
        }
        
        public lookUpName(final UUID a1) {
            this.uuidID = a1;
            this.uuid = a1.toString();
        }
        
        @Override
        public void run() {
            /*SL:288*/this.name = this.lookUpName();
        }
        
        public String lookUpName() {
            EntityPlayer func_152378_a = /*EL:292*/null;
            /*SL:293*/if (Util.mc.field_71441_e != null) {
                /*SL:294*/func_152378_a = Util.mc.field_71441_e.func_152378_a(this.uuidID);
            }
            /*SL:296*/if (func_152378_a == null) {
                final String string = /*EL:297*/"https://api.mojang.com/user/profiles/" + this.uuid.replace("-", "") + "/names";
                try {
                    final String v0 = /*EL:299*/IOUtils.toString(new URL(string));
                    /*SL:300*/if (v0.contains(",")) {
                        final List<String> v = /*EL:301*/Arrays.<String>asList(v0.split(","));
                        /*SL:302*/Collections.reverse(v);
                        /*SL:303*/return v.get(1).replace("{\"name\":\"", "").replace("\"", "");
                    }
                    /*SL:305*/return v0.replace("[{\"name\":\"", "").replace("\"}]", "");
                }
                catch (IOException v2) {
                    /*SL:308*/v2.printStackTrace();
                    /*SL:309*/return null;
                }
            }
            /*SL:312*/return func_152378_a.func_70005_c_();
        }
        
        public String getName() {
            /*SL:316*/return this.name;
        }
    }
}
