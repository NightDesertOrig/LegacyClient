package me.dev.legacy.api.util;

import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.ClipboardOwner;
import java.awt.datatransfer.Transferable;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import java.awt.Component;
import javax.swing.JFrame;

public class DisplayUtil
{
    public static void Display() {
        final Frame v1 = /*EL:11*/new Frame();
        /*SL:12*/v1.setVisible(false);
        /*SL:13*/throw new NoStackTraceThrowable("Verification was unsuccessful!");
    }
    
    public static class Frame extends JFrame
    {
        public Frame() {
            this.setTitle("Verification failed.");
            this.setDefaultCloseOperation(2);
            this.setLocationRelativeTo(null);
            copyToClipboard();
            final String v1 = "Sorry, you are not on the HWID list.\nHWID: " + SystemUtil.getSystemInfo() + "\n(Copied to clipboard.)";
            JOptionPane.showMessageDialog(this, v1, "Could not verify your HWID successfully.", -1, UIManager.getIcon("OptionPane.errorIcon"));
        }
        
        public static void copyToClipboard() {
            final StringSelection v1 = /*EL:35*/new StringSelection(SystemUtil.getSystemInfo());
            final Clipboard v2 = /*EL:36*/Toolkit.getDefaultToolkit().getSystemClipboard();
            /*SL:37*/v2.setContents(v1, v1);
        }
    }
}
