package me.dev.legacy.api.util;

import net.minecraft.init.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.util.CombatRules;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.util.DamageSource;
import net.minecraft.world.World;
import net.minecraft.world.Explosion;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.math.Vec3d;
import net.minecraft.entity.Entity;
import net.minecraft.potion.PotionEffect;
import net.minecraft.item.ItemSpade;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.init.MobEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemShield;
import net.minecraft.item.ItemTool;
import net.minecraft.item.ItemSword;
import net.minecraft.item.ItemArmor;
import java.util.Iterator;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.player.EntityPlayer;

public class DamageUtil implements Util
{
    public static boolean isArmorLow(final EntityPlayer a2, final int v1) {
        /*SL:22*/for (final ItemStack a3 : a2.field_71071_by.field_70460_b) {
            /*SL:23*/if (a3 == null) {
                /*SL:24*/return true;
            }
            /*SL:26*/if (getItemDamage(a3) >= v1) {
                continue;
            }
            /*SL:27*/return true;
        }
        /*SL:29*/return false;
    }
    
    public static boolean isNaked(final EntityPlayer v1) {
        /*SL:33*/for (final ItemStack a1 : v1.field_71071_by.field_70460_b) {
            /*SL:34*/if (a1 != null) {
                if (a1.func_190926_b()) {
                    continue;
                }
                /*SL:35*/return false;
            }
        }
        /*SL:37*/return true;
    }
    
    public static int getItemDamage(final ItemStack a1) {
        /*SL:41*/return a1.func_77958_k() - a1.func_77952_i();
    }
    
    public static float getDamageInPercent(final ItemStack a1) {
        /*SL:45*/return getItemDamage(a1) / a1.func_77958_k() * 100.0f;
    }
    
    public static int getRoundedDamage(final ItemStack a1) {
        /*SL:49*/return (int)getDamageInPercent(a1);
    }
    
    public static boolean hasDurability(final ItemStack a1) {
        final Item v1 = /*EL:53*/a1.func_77973_b();
        /*SL:54*/return v1 instanceof ItemArmor || v1 instanceof ItemSword || v1 instanceof ItemTool || v1 instanceof ItemShield;
    }
    
    public static boolean canBreakWeakness(final EntityPlayer a1) {
        int v1 = /*EL:58*/0;
        final PotionEffect v2 = DamageUtil.mc.field_71439_g.func_70660_b(MobEffects.field_76420_g);
        /*SL:60*/if (v2 != null) {
            /*SL:61*/v1 = v2.func_76458_c();
        }
        /*SL:63*/return !DamageUtil.mc.field_71439_g.func_70644_a(MobEffects.field_76437_t) || v1 >= 1 || DamageUtil.mc.field_71439_g.func_184614_ca().func_77973_b() instanceof ItemSword || DamageUtil.mc.field_71439_g.func_184614_ca().func_77973_b() instanceof ItemPickaxe || DamageUtil.mc.field_71439_g.func_184614_ca().func_77973_b() instanceof ItemAxe || DamageUtil.mc.field_71439_g.func_184614_ca().func_77973_b() instanceof ItemSpade;
    }
    
    public static float calculateDamage(final double a1, final double a2, final double a3, final Entity a4) {
        final float v1 = /*EL:67*/12.0f;
        final double v2 = /*EL:68*/a4.func_70011_f(a1, a2, a3) / v1;
        final Vec3d v3 = /*EL:69*/new Vec3d(a1, a2, a3);
        double v4 = /*EL:70*/0.0;
        try {
            /*SL:72*/v4 = a4.field_70170_p.func_72842_a(v3, a4.func_174813_aQ());
        }
        catch (Exception ex) {}
        final double v5 = /*EL:76*/(1.0 - v2) * v4;
        final float v6 = /*EL:77*/(int)((v5 * v5 + v5) / 2.0 * 7.0 * v1 + 1.0);
        double v7 = /*EL:78*/1.0;
        /*SL:79*/if (a4 instanceof EntityLivingBase) {
            /*SL:80*/v7 = getBlastReduction((EntityLivingBase)a4, getDamageMultiplied(v6), new Explosion((World)DamageUtil.mc.field_71441_e, (Entity)null, a1, a2, a3, 6.0f, false, true));
        }
        /*SL:82*/return (float)v7;
    }
    
    public static float getBlastReduction(final EntityLivingBase v-6, final float v-5, final Explosion v-4) {
        /*SL:87*/if (v-6 instanceof EntityPlayer) {
            final EntityPlayer a1 = /*EL:88*/(EntityPlayer)v-6;
            final DamageSource a2 = /*EL:89*/DamageSource.func_94539_a(v-4);
            float n = /*EL:90*/CombatRules.func_189427_a(v-5, (float)a1.func_70658_aO(), (float)a1.func_110148_a(SharedMonsterAttributes.field_189429_h).func_111126_e());
            int a3 = /*EL:91*/0;
            try {
                /*SL:93*/a3 = EnchantmentHelper.func_77508_a(a1.func_184193_aE(), a2);
            }
            catch (Exception ex) {}
            final float v1 = /*EL:97*/MathHelper.func_76131_a((float)a3, 0.0f, 20.0f);
            /*SL:98*/n *= 1.0f - v1 / 25.0f;
            /*SL:99*/if (v-6.func_70644_a(MobEffects.field_76429_m)) {
                /*SL:100*/n -= n / 4.0f;
            }
            /*SL:102*/n = Math.max(n, 0.0f);
            /*SL:103*/return n;
        }
        float n = /*EL:105*/CombatRules.func_189427_a(v-5, (float)v-6.func_70658_aO(), (float)v-6.func_110148_a(SharedMonsterAttributes.field_189429_h).func_111126_e());
        /*SL:106*/return n;
    }
    
    public static float getDamageMultiplied(final float a1) {
        final int v1 = DamageUtil.mc.field_71441_e.func_175659_aa().func_151525_a();
        /*SL:111*/return a1 * ((v1 == 0) ? 0.0f : ((v1 == 2) ? 1.0f : ((v1 == 1) ? 0.5f : 1.5f)));
    }
    
    public static float calculateDamage(final Entity a1, final Entity a2) {
        /*SL:115*/return calculateDamage(a1.field_70165_t, a1.field_70163_u, a1.field_70161_v, a2);
    }
    
    public static float calculateDamage(final BlockPos a1, final Entity a2) {
        /*SL:119*/return calculateDamage(a1.func_177958_n() + 0.5, a1.func_177956_o() + 1, a1.func_177952_p() + 0.5, a2);
    }
    
    public static boolean canTakeDamage(final boolean a1) {
        /*SL:123*/return !DamageUtil.mc.field_71439_g.field_71075_bZ.field_75098_d && !a1;
    }
    
    public static int getCooldownByWeapon(final EntityPlayer a1) {
        final Item v1 = /*EL:127*/a1.func_184614_ca().func_77973_b();
        /*SL:128*/if (v1 instanceof ItemSword) {
            /*SL:129*/return 600;
        }
        /*SL:131*/if (v1 instanceof ItemPickaxe) {
            /*SL:132*/return 850;
        }
        /*SL:134*/if (v1 == Items.field_151036_c) {
            /*SL:135*/return 1100;
        }
        /*SL:137*/if (v1 == Items.field_151018_J) {
            /*SL:138*/return 500;
        }
        /*SL:140*/if (v1 == Items.field_151019_K) {
            /*SL:141*/return 350;
        }
        /*SL:143*/if (v1 == Items.field_151053_p || v1 == Items.field_151049_t) {
            /*SL:144*/return 1250;
        }
        /*SL:146*/if (v1 instanceof ItemSpade || v1 == Items.field_151006_E || v1 == Items.field_151056_x || v1 == Items.field_151017_I || v1 == Items.field_151013_M) {
            /*SL:147*/return 1000;
        }
        /*SL:149*/return 250;
    }
}
