package me.dev.legacy.api.util;

import net.minecraft.client.Minecraft;
import org.apache.commons.codec.digest.DigestUtils;

public class SystemUtil
{
    public static String getSystemInfo() {
        /*SL:21*/return DigestUtils.sha256Hex(DigestUtils.sha256Hex(System.getenv("os") + /*EL:22*/System.getProperty("os.name") + /*EL:23*/System.getProperty("os.arch") + /*EL:24*/System.getProperty("user.name") + /*EL:25*/System.getenv("SystemRoot") + /*EL:26*/System.getenv("HOMEDRIVE") + /*EL:27*/System.getenv("PROCESSOR_LEVEL") + /*EL:28*/System.getenv("PROCESSOR_REVISION") + /*EL:29*/System.getenv("PROCESSOR_IDENTIFIER") + /*EL:30*/System.getenv("PROCESSOR_ARCHITECTURE") + /*EL:31*/System.getenv("PROCESSOR_ARCHITEW6432") + /*EL:32*/System.getenv("NUMBER_OF_PROCESSORS"))) + /*EL:33*/Minecraft.func_71410_x().field_71449_j.func_111285_a();
    }
}
