package me.dev.legacy.api.util;

public class BoostTimer
{
    private long time;
    
    public BoostTimer() {
        this.time = -1L;
    }
    
    public boolean passedS(final double a1) {
        /*SL:8*/return this.passedMs((long)a1 * 1000L);
    }
    
    public boolean passedDms(final double a1) {
        /*SL:12*/return this.passedMs((long)a1 * 10L);
    }
    
    public boolean passedDs(final double a1) {
        /*SL:16*/return this.passedMs((long)a1 * 100L);
    }
    
    public boolean passedMs(final long a1) {
        /*SL:20*/return this.passedNS(this.convertToNS(a1));
    }
    
    public void setMs(final long a1) {
        /*SL:24*/this.time = System.nanoTime() - this.convertToNS(a1);
    }
    
    public boolean passedNS(final long a1) {
        /*SL:28*/return System.nanoTime() - this.time >= a1;
    }
    
    public long getPassedTimeMs() {
        /*SL:32*/return this.getMs(System.nanoTime() - this.time);
    }
    
    public BoostTimer reset() {
        /*SL:36*/this.time = System.nanoTime();
        /*SL:37*/return this;
    }
    
    public long getMs(final long a1) {
        /*SL:41*/return a1 / 1000000L;
    }
    
    public long convertToNS(final long a1) {
        /*SL:45*/return a1 * 1000000L;
    }
}
