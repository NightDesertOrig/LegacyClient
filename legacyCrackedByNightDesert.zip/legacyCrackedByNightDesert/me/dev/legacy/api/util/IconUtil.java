package me.dev.legacy.api.util;

import java.io.IOException;
import java.awt.image.BufferedImage;
import java.util.Arrays;
import javax.imageio.ImageIO;
import java.nio.ByteBuffer;
import java.io.InputStream;

public class IconUtil
{
    public static final IconUtil INSTANCE;
    
    public ByteBuffer readImageToBuffer(final InputStream a1) throws IOException {
        final BufferedImage v1 = /*EL:16*/ImageIO.read(a1);
        final int[] v2 = /*EL:17*/v1.getRGB(0, 0, v1.getWidth(), v1.getHeight(), null, 0, v1.getWidth());
        final ByteBuffer v3 = /*EL:18*/ByteBuffer.allocate(4 * v2.length);
        /*SL:19*/Arrays.stream(v2).map(a1 -> a1 << 8 | (a1 >> 24 & 0xFF)).forEach(v3::putInt);
        /*SL:20*/v3.flip();
        /*SL:21*/return v3;
    }
    
    static {
        INSTANCE = new IconUtil();
    }
}
