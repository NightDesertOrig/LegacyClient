package me.dev.legacy.api.util;

import me.dev.legacy.modules.client.ClickGui;
import net.minecraft.util.math.Vec3i;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class RotationUtil implements Util
{
    public static Vec3d getEyesPos() {
        /*SL:13*/return new Vec3d(RotationUtil.mc.field_71439_g.field_70165_t, RotationUtil.mc.field_71439_g.field_70163_u + RotationUtil.mc.field_71439_g.func_70047_e(), RotationUtil.mc.field_71439_g.field_70161_v);
    }
    
    public static float[] getLegitRotations(final Vec3d a1) {
        final Vec3d v1 = getEyesPos();
        final double v2 = /*EL:18*/a1.field_72450_a - v1.field_72450_a;
        final double v3 = /*EL:19*/a1.field_72448_b - v1.field_72448_b;
        final double v4 = /*EL:20*/a1.field_72449_c - v1.field_72449_c;
        final double v5 = /*EL:21*/Math.sqrt(v2 * v2 + v4 * v4);
        final float v6 = /*EL:22*/(float)Math.toDegrees(Math.atan2(v4, v2)) - 90.0f;
        final float v7 = /*EL:23*/(float)(-Math.toDegrees(Math.atan2(v3, v5)));
        /*SL:24*/return new float[] { RotationUtil.mc.field_71439_g.field_70177_z + MathHelper.func_76142_g(v6 - RotationUtil.mc.field_71439_g.field_70177_z), RotationUtil.mc.field_71439_g.field_70125_A + MathHelper.func_76142_g(v7 - RotationUtil.mc.field_71439_g.field_70125_A) };
    }
    
    public static void faceVector(final Vec3d a1, final boolean a2) {
        final float[] v1 = getLegitRotations(/*EL:28*/a1);
        RotationUtil.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:29*/(Packet)new CPacketPlayer.Rotation(v1[0], a2 ? ((float)MathHelper.func_180184_b((int)v1[1], 360)) : v1[1], RotationUtil.mc.field_71439_g.field_70122_E));
    }
    
    public static int getDirection4D() {
        /*SL:33*/return MathHelper.func_76128_c(RotationUtil.mc.field_71439_g.field_70177_z * 4.0f / 360.0f + 0.5) & 0x3;
    }
    
    public static String getDirection4D(final boolean a1) {
        final int v1 = getDirection4D();
        /*SL:38*/if (v1 == 0) {
            /*SL:39*/return "South (+Z)";
        }
        /*SL:41*/if (v1 == 1) {
            /*SL:42*/return "West (-X)";
        }
        /*SL:44*/if (v1 == 2) {
            /*SL:45*/return (a1 ? "\u00c2�c" : "") + "North (-Z)";
        }
        /*SL:47*/if (v1 == 3) {
            /*SL:48*/return "East (+X)";
        }
        /*SL:50*/return "Loading...";
    }
    
    public static boolean isInFov(final BlockPos a1) {
        /*SL:54*/return a1 != null && (RotationUtil.mc.field_71439_g.func_174818_b(a1) < 4.0 || yawDist(a1) < getHalvedfov() + 2.0f);
    }
    
    public static boolean isInFov(final Entity a1) {
        /*SL:58*/return a1 != null && (RotationUtil.mc.field_71439_g.func_70068_e(a1) < 4.0 || yawDist(a1) < getHalvedfov() + 2.0f);
    }
    
    public static double yawDist(final BlockPos v-1) {
        /*SL:62*/if (v-1 != null) {
            final Vec3d a1 = /*EL:63*/new Vec3d((Vec3i)v-1).func_178788_d(RotationUtil.mc.field_71439_g.func_174824_e(RotationUtil.mc.func_184121_ak()));
            final double v1 = /*EL:64*/Math.abs(RotationUtil.mc.field_71439_g.field_70177_z - (Math.toDegrees(Math.atan2(a1.field_72449_c, a1.field_72450_a)) - 90.0)) % 360.0;
            /*SL:65*/return (v1 > 180.0) ? (360.0 - v1) : v1;
        }
        /*SL:67*/return 0.0;
    }
    
    public static double yawDist(final Entity v-1) {
        /*SL:71*/if (v-1 != null) {
            final Vec3d a1 = /*EL:72*/v-1.func_174791_d().func_72441_c(0.0, (double)(v-1.func_70047_e() / 2.0f), 0.0).func_178788_d(RotationUtil.mc.field_71439_g.func_174824_e(RotationUtil.mc.func_184121_ak()));
            final double v1 = /*EL:73*/Math.abs(RotationUtil.mc.field_71439_g.field_70177_z - (Math.toDegrees(Math.atan2(a1.field_72449_c, a1.field_72450_a)) - 90.0)) % 360.0;
            /*SL:74*/return (v1 > 180.0) ? (360.0 - v1) : v1;
        }
        /*SL:76*/return 0.0;
    }
    
    public static boolean isInFov(final Vec3d a1, final Vec3d a2) {
        Label_0069: {
            /*SL:80*/if (RotationUtil.mc.field_71439_g.field_70125_A > 30.0f) {
                if (a2.field_72448_b <= RotationUtil.mc.field_71439_g.field_70163_u) {
                    break Label_0069;
                }
            }
            else if (RotationUtil.mc.field_71439_g.field_70125_A >= -30.0f || a2.field_72448_b >= RotationUtil.mc.field_71439_g.field_70163_u) {
                break Label_0069;
            }
            /*SL:81*/return true;
        }
        final float v1 = /*EL:83*/MathUtil.calcAngleNoY(a1, a2)[0] - transformYaw();
        /*SL:84*/if (v1 < -270.0f) {
            /*SL:85*/return true;
        }
        final float v2 = /*EL:87*/(ClickGui.getInstance().customFov.getValue() ? ClickGui.getInstance().fov.getValue() : RotationUtil.mc.field_71474_y.field_74334_X) / 2.0f;
        /*SL:88*/return v1 < v2 + 10.0f && v1 > -v2 - 10.0f;
    }
    
    public static float transformYaw() {
        float v1 = RotationUtil.mc.field_71439_g.field_70177_z % /*EL:92*/360.0f;
        /*SL:93*/if (RotationUtil.mc.field_71439_g.field_70177_z > 0.0f) {
            /*SL:94*/if (v1 > 180.0f) {
                /*SL:95*/v1 = -180.0f + (v1 - 180.0f);
            }
        }
        else/*SL:97*/ if (v1 < -180.0f) {
            /*SL:98*/v1 = 180.0f + (v1 + 180.0f);
        }
        /*SL:100*/if (v1 < 0.0f) {
            /*SL:101*/return 180.0f + v1;
        }
        /*SL:103*/return -180.0f + v1;
    }
    
    public static float getFov() {
        /*SL:107*/return ClickGui.getInstance().customFov.getValue() ? ClickGui.getInstance().fov.getValue() : RotationUtil.mc.field_71474_y.field_74334_X;
    }
    
    public static float getHalvedfov() {
        /*SL:111*/return getFov() / 2.0f;
    }
}
