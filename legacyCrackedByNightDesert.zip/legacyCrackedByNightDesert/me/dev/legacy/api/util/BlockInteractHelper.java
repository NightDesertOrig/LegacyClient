package me.dev.legacy.api.util;

import java.util.Arrays;
import java.util.ArrayList;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.util.math.MathHelper;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.EnumActionResult;
import net.minecraft.network.Packet;
import net.minecraft.entity.Entity;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.Vec3i;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.Vec3d;
import net.minecraft.block.BlockSlab;
import net.minecraft.util.math.BlockPos;
import net.minecraft.client.Minecraft;
import net.minecraft.block.Block;
import java.util.List;

public class BlockInteractHelper
{
    public static final List<Block> blackList;
    public static final List<Block> shulkerList;
    private static final Minecraft mc;
    
    public static PlaceResult place(final BlockPos v-11, final float v-10, final boolean v-9, final boolean v-8) {
        final IBlockState func_180495_p = BlockInteractHelper.mc.field_71441_e.func_180495_p(/*EL:45*/v-11);
        final boolean func_76222_j = /*EL:47*/func_180495_p.func_185904_a().func_76222_j();
        final boolean b = /*EL:49*/func_180495_p.func_177230_c() instanceof BlockSlab;
        /*SL:51*/if (!func_76222_j && !b) {
            /*SL:52*/return PlaceResult.NotReplaceable;
        }
        /*SL:53*/if (!checkForNeighbours(v-11)) {
            /*SL:54*/return PlaceResult.Neighbors;
        }
        /*SL:58*/if (v-8 && b && !func_180495_p.func_185917_h()) {
            /*SL:59*/return PlaceResult.CantPlace;
        }
        final Vec3d vec3d = /*EL:62*/new Vec3d(BlockInteractHelper.mc.field_71439_g.field_70165_t, BlockInteractHelper.mc.field_71439_g.field_70163_u + BlockInteractHelper.mc.field_71439_g.func_70047_e(), BlockInteractHelper.mc.field_71439_g.field_70161_v);
        /*SL:64*/for (final EnumFacing v0 : EnumFacing.values()) {
            final BlockPos v = /*EL:65*/v-11.func_177972_a(v0);
            final EnumFacing v2 = /*EL:66*/v0.func_176734_d();
            /*SL:68*/if (BlockInteractHelper.mc.field_71441_e.func_180495_p(v).func_177230_c().func_176209_a(BlockInteractHelper.mc.field_71441_e.func_180495_p(v), false)) {
                Vec3d a4 = /*EL:69*/new Vec3d((Vec3i)v).func_72441_c(0.5, 0.5, 0.5).func_178787_e(new Vec3d(v2.func_176730_m()).func_186678_a(0.5));
                /*SL:70*/if (vec3d.func_72438_d(a4) <= v-10) {
                    final Block a2 = BlockInteractHelper.mc.field_71441_e.func_180495_p(/*EL:72*/v).func_177230_c();
                    final boolean a3 = /*EL:74*/a2.func_180639_a((World)BlockInteractHelper.mc.field_71441_e, v-11, BlockInteractHelper.mc.field_71441_e.func_180495_p(v-11), (EntityPlayer)BlockInteractHelper.mc.field_71439_g, EnumHand.MAIN_HAND, v0, 0.0f, 0.0f, 0.0f);
                    /*SL:76*/if (BlockInteractHelper.blackList.contains(a2) || BlockInteractHelper.shulkerList.contains(a2) || a3) {
                        BlockInteractHelper.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:78*/(Packet)new CPacketEntityAction((Entity)BlockInteractHelper.mc.field_71439_g, CPacketEntityAction.Action.START_SNEAKING));
                    }
                    /*SL:80*/if (v-9) {
                        faceVectorPacketInstant(/*EL:82*/a4);
                    }
                    /*SL:84*/a4 = BlockInteractHelper.mc.field_71442_b.func_187099_a(BlockInteractHelper.mc.field_71439_g, BlockInteractHelper.mc.field_71441_e, v, v2, a4, EnumHand.MAIN_HAND);
                    /*SL:86*/if (a4 != EnumActionResult.FAIL) {
                        BlockInteractHelper.mc.field_71439_g.func_184609_a(EnumHand.MAIN_HAND);
                        /*SL:89*/if (a3) {
                            BlockInteractHelper.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:91*/(Packet)new CPacketEntityAction((Entity)BlockInteractHelper.mc.field_71439_g, CPacketEntityAction.Action.STOP_SNEAKING));
                        }
                        /*SL:93*/return PlaceResult.Placed;
                    }
                }
            }
        }
        /*SL:98*/return PlaceResult.CantPlace;
    }
    
    public static ValidResult valid(final BlockPos v-10) {
        /*SL:104*/if (!BlockInteractHelper.mc.field_71441_e.func_72855_b(new AxisAlignedBB(v-10))) {
            /*SL:105*/return ValidResult.NoEntityCollision;
        }
        /*SL:107*/if (!checkForNeighbours(v-10)) {
            /*SL:108*/return ValidResult.NoNeighbors;
        }
        final IBlockState func_180495_p = BlockInteractHelper.mc.field_71441_e.func_180495_p(/*EL:110*/v-10);
        /*SL:112*/if (func_180495_p.func_177230_c() == Blocks.field_150350_a) {
            final BlockPos[] array2;
            final BlockPos[] array = /*EL:117*/array2 = new BlockPos[] { v-10.func_177978_c(), v-10.func_177968_d(), v-10.func_177974_f(), v-10.func_177976_e(), v-10.func_177984_a(), v-10.func_177977_b() };
            for (final BlockPos blockPos : array2) {
                final IBlockState func_180495_p2 = BlockInteractHelper.mc.field_71441_e.func_180495_p(/*EL:119*/blockPos);
                /*SL:121*/if (func_180495_p2.func_177230_c() != Blocks.field_150350_a) {
                    /*SL:124*/for (final EnumFacing v1 : EnumFacing.values()) {
                        final BlockPos a1 = /*EL:126*/v-10.func_177972_a(v1);
                        /*SL:128*/if (BlockInteractHelper.mc.field_71441_e.func_180495_p(a1).func_177230_c().func_176209_a(BlockInteractHelper.mc.field_71441_e.func_180495_p(a1), false)) {
                            /*SL:130*/return ValidResult.Ok;
                        }
                    }
                }
            }
            /*SL:135*/return ValidResult.NoNeighbors;
        }
        /*SL:138*/return ValidResult.AlreadyBlockThere;
    }
    
    public static float[] getLegitRotations(final Vec3d a1) {
        final Vec3d v1 = getEyesPos();
        final double v2 = /*EL:143*/a1.field_72450_a - v1.field_72450_a;
        final double v3 = /*EL:144*/a1.field_72448_b - v1.field_72448_b;
        final double v4 = /*EL:145*/a1.field_72449_c - v1.field_72449_c;
        final double v5 = /*EL:146*/Math.sqrt(v2 * v2 + v4 * v4);
        final float v6 = /*EL:147*/(float)Math.toDegrees(Math.atan2(v4, v2)) - 90.0f;
        final float v7 = /*EL:148*/(float)(-Math.toDegrees(Math.atan2(v3, v5)));
        /*SL:149*/return new float[] { BlockInteractHelper.mc.field_71439_g.field_70177_z + MathHelper.func_76142_g(v6 - BlockInteractHelper.mc.field_71439_g.field_70177_z), BlockInteractHelper.mc.field_71439_g.field_70125_A + MathHelper.func_76142_g(v7 - BlockInteractHelper.mc.field_71439_g.field_70125_A) };
    }
    
    private static Vec3d getEyesPos() {
        /*SL:153*/return new Vec3d(BlockInteractHelper.mc.field_71439_g.field_70165_t, BlockInteractHelper.mc.field_71439_g.field_70163_u + BlockInteractHelper.mc.field_71439_g.func_70047_e(), BlockInteractHelper.mc.field_71439_g.field_70161_v);
    }
    
    public static void faceVectorPacketInstant(final Vec3d a1) {
        final float[] v1 = getLegitRotations(/*EL:157*/a1);
        BlockInteractHelper.mc.field_71439_g.field_71174_a.func_147297_a(/*EL:159*/(Packet)new CPacketPlayer.Rotation(v1[0], v1[1], BlockInteractHelper.mc.field_71439_g.field_70122_E));
    }
    
    public static boolean canBeClicked(final BlockPos a1) {
        /*SL:163*/return getBlock(a1).func_176209_a(getState(a1), false);
    }
    
    private static Block getBlock(final BlockPos a1) {
        /*SL:167*/return getState(a1).func_177230_c();
    }
    
    private static IBlockState getState(final BlockPos a1) {
        /*SL:171*/return BlockInteractHelper.mc.field_71441_e.func_180495_p(a1);
    }
    
    public static boolean checkForNeighbours(final BlockPos v-3) {
        /*SL:175*/if (!hasNeighbour(v-3)) {
            /*SL:176*/for (final EnumFacing v1 : EnumFacing.values()) {
                final BlockPos a1 = /*EL:177*/v-3.func_177972_a(v1);
                /*SL:178*/if (hasNeighbour(a1)) {
                    /*SL:179*/return true;
                }
            }
            /*SL:182*/return false;
        }
        /*SL:184*/return true;
    }
    
    private static boolean hasNeighbour(final BlockPos v-3) {
        /*SL:188*/for (final EnumFacing v1 : EnumFacing.values()) {
            final BlockPos a1 = /*EL:189*/v-3.func_177972_a(v1);
            /*SL:190*/if (!BlockInteractHelper.mc.field_71441_e.func_180495_p(a1).func_185904_a().func_76222_j()) {
                /*SL:191*/return true;
            }
        }
        /*SL:194*/return false;
    }
    
    public static List<BlockPos> getSphere(final BlockPos a6, final float v1, final int v2, final boolean v3, final boolean v4, final int v5) {
        final ArrayList<BlockPos> v6 = /*EL:198*/new ArrayList<BlockPos>();
        final int v7 = /*EL:199*/a6.func_177958_n();
        final int v8 = /*EL:200*/a6.func_177956_o();
        final int v9 = /*EL:201*/a6.func_177952_p();
        /*SL:203*/for (int v10 = v7 - (int)v1; v10 <= v7 + v1; /*SL:219*/++v10) {
            for (int a7 = v9 - (int)v1; a7 <= v9 + v1; ++a7) {
                int a8 = v4 ? (v8 - (int)v1) : v8;
                while (true) {
                    final float a9 = v4 ? (v8 + v1) : (v8 + v2);
                    if (a8 >= a9) {
                        break;
                    }
                    final double a10 = (v7 - v10) * (v7 - v10) + (v9 - a7) * (v9 - a7) + (v4 ? ((v8 - a8) * (v8 - a8)) : 0);
                    if (a10 < v1 * v1 && (!v3 || a10 >= (v1 - 1.0f) * (v1 - 1.0f))) {
                        final BlockPos a11 = new BlockPos(v10, a8 + v5, a7);
                        v6.add(a11);
                    }
                    ++a8;
                }
            }
        }
        /*SL:221*/return v6;
    }
    
    static {
        blackList = Arrays.<Block>asList(Blocks.field_150477_bB, Blocks.field_150486_ae, Blocks.field_150447_bR, Blocks.field_150462_ai, Blocks.field_150467_bQ, Blocks.field_150382_bo, Blocks.field_150438_bZ, Blocks.field_150409_cd, Blocks.field_150367_z);
        shulkerList = Arrays.<Block>asList(Blocks.field_190977_dl, Blocks.field_190978_dm, Blocks.field_190979_dn, Blocks.field_190980_do, Blocks.field_190981_dp, Blocks.field_190982_dq, Blocks.field_190983_dr, Blocks.field_190984_ds, Blocks.field_190985_dt, Blocks.field_190986_du, Blocks.field_190987_dv, Blocks.field_190988_dw, Blocks.field_190989_dx, Blocks.field_190990_dy, Blocks.field_190991_dz, Blocks.field_190975_dA);
        mc = Minecraft.func_71410_x();
    }
    
    public enum ValidResult
    {
        NoEntityCollision, 
        AlreadyBlockThere, 
        NoNeighbors, 
        Ok;
    }
    
    public enum PlaceResult
    {
        NotReplaceable, 
        Neighbors, 
        CantPlace, 
        Placed;
    }
}
