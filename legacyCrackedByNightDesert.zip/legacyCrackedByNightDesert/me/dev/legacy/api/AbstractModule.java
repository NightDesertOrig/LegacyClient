package me.dev.legacy.api;

import java.util.Iterator;
import java.util.Collection;
import me.dev.legacy.impl.gui.LegacyGui;
import me.dev.legacy.modules.Module;
import me.dev.legacy.Legacy;
import java.util.ArrayList;
import me.dev.legacy.api.manager.TextManager;
import me.dev.legacy.impl.setting.Setting;
import java.util.List;
import me.dev.legacy.api.util.Util;

public class AbstractModule implements Util
{
    public List<Setting> settings;
    public TextManager renderer;
    private String name;
    
    public AbstractModule() {
        this.settings = new ArrayList<Setting>();
        this.renderer = Legacy.textManager;
    }
    
    public AbstractModule(final String a1) {
        this.settings = new ArrayList<Setting>();
        this.renderer = Legacy.textManager;
        this.name = a1;
    }
    
    public static boolean nullCheck() {
        /*SL:27*/return AbstractModule.mc.field_71439_g == null;
    }
    
    public static boolean fullNullCheck() {
        /*SL:31*/return AbstractModule.mc.field_71439_g == null || AbstractModule.mc.field_71441_e == null;
    }
    
    public String getName() {
        /*SL:35*/return this.name;
    }
    
    public List<Setting> getSettings() {
        /*SL:39*/return this.settings;
    }
    
    public boolean hasSettings() {
        /*SL:43*/return !this.settings.isEmpty();
    }
    
    public boolean isEnabled() {
        /*SL:47*/return this instanceof Module && /*EL:48*/((Module)this).isOn();
    }
    
    public boolean isDisabled() {
        /*SL:54*/return !this.isEnabled();
    }
    
    public Setting register(final Setting a1) {
        /*SL:58*/a1.setFeature(this);
        /*SL:59*/this.settings.add(a1);
        /*SL:60*/if (this instanceof Module && AbstractModule.mc.field_71462_r instanceof LegacyGui) {
            /*SL:61*/LegacyGui.getInstance().updateModule((Module)this);
        }
        /*SL:63*/return a1;
    }
    
    public void unregister(final Setting v2) {
        final ArrayList<Setting> v3 = /*EL:67*/new ArrayList<Setting>();
        /*SL:68*/for (final Setting a1 : this.settings) {
            /*SL:69*/if (!a1.equals(v2)) {
                continue;
            }
            /*SL:70*/v3.add(a1);
        }
        /*SL:72*/if (!v3.isEmpty()) {
            /*SL:73*/this.settings.removeAll(v3);
        }
        /*SL:75*/if (this instanceof Module && AbstractModule.mc.field_71462_r instanceof LegacyGui) {
            /*SL:76*/LegacyGui.getInstance().updateModule((Module)this);
        }
    }
    
    public Setting getSettingByName(final String v2) {
        /*SL:81*/for (final Setting a1 : this.settings) {
            /*SL:82*/if (!a1.getName().equalsIgnoreCase(v2)) {
                continue;
            }
            /*SL:83*/return a1;
        }
        /*SL:85*/return null;
    }
    
    public void reset() {
        /*SL:89*/for (final Setting v1 : this.settings) {
            /*SL:90*/v1.setValue(v1.getDefaultValue());
        }
    }
    
    public void clearSettings() {
        /*SL:95*/this.settings = new ArrayList<Setting>();
    }
}
