package me.dev.legacy.api.event.events.render;

import me.dev.legacy.api.event.EventStage;

public class RenderItemEvent extends EventStage
{
    double mainX;
    double mainY;
    double mainZ;
    double offX;
    double offY;
    double offZ;
    double mainRAngel;
    double mainRx;
    double mainRy;
    double mainRz;
    double offRAngel;
    double offRx;
    double offRy;
    double offRz;
    double mainHandScaleX;
    double mainHandScaleY;
    double mainHandScaleZ;
    double offHandScaleX;
    double offHandScaleY;
    double offHandScaleZ;
    
    public RenderItemEvent(final double a1, final double a2, final double a3, final double a4, final double a5, final double a6, final double a7, final double a8, final double a9, final double a10, final double a11, final double a12, final double a13, final double a14, final double a15, final double a16, final double a17, final double a18, final double a19, final double a20) {
        this.mainX = a1;
        this.mainY = a2;
        this.mainZ = a3;
        this.offX = a4;
        this.offY = a5;
        this.offZ = a6;
        this.mainRAngel = a7;
        this.mainRx = a8;
        this.mainRy = a9;
        this.mainRz = a10;
        this.offRAngel = a11;
        this.offRx = a12;
        this.offRy = a13;
        this.offRz = a14;
        this.mainHandScaleX = a15;
        this.mainHandScaleY = a16;
        this.mainHandScaleZ = a17;
        this.offHandScaleX = a18;
        this.offHandScaleY = a19;
        this.offHandScaleZ = a20;
    }
    
    public void setMainX(final double a1) {
        /*SL:43*/this.mainX = a1;
    }
    
    public void setMainY(final double a1) {
        /*SL:47*/this.mainY = a1;
    }
    
    public void setMainZ(final double a1) {
        /*SL:51*/this.mainZ = a1;
    }
    
    public void setOffX(final double a1) {
        /*SL:55*/this.offX = a1;
    }
    
    public void setOffY(final double a1) {
        /*SL:59*/this.offY = a1;
    }
    
    public void setOffZ(final double a1) {
        /*SL:63*/this.offZ = a1;
    }
    
    public void setOffRAngel(final double a1) {
        /*SL:67*/this.offRAngel = a1;
    }
    
    public void setOffRx(final double a1) {
        /*SL:71*/this.offRx = a1;
    }
    
    public void setOffRy(final double a1) {
        /*SL:75*/this.offRy = a1;
    }
    
    public void setOffRz(final double a1) {
        /*SL:79*/this.offRz = a1;
    }
    
    public void setMainRAngel(final double a1) {
        /*SL:83*/this.mainRAngel = a1;
    }
    
    public void setMainRx(final double a1) {
        /*SL:87*/this.mainRx = a1;
    }
    
    public void setMainRy(final double a1) {
        /*SL:91*/this.mainRy = a1;
    }
    
    public void setMainRz(final double a1) {
        /*SL:95*/this.mainRz = a1;
    }
    
    public void setMainHandScaleX(final double a1) {
        /*SL:99*/this.mainHandScaleX = a1;
    }
    
    public void setMainHandScaleY(final double a1) {
        /*SL:103*/this.mainHandScaleY = a1;
    }
    
    public void setMainHandScaleZ(final double a1) {
        /*SL:107*/this.mainHandScaleZ = a1;
    }
    
    public void setOffHandScaleX(final double a1) {
        /*SL:111*/this.offHandScaleX = a1;
    }
    
    public void setOffHandScaleY(final double a1) {
        /*SL:115*/this.offHandScaleY = a1;
    }
    
    public void setOffHandScaleZ(final double a1) {
        /*SL:119*/this.offHandScaleZ = a1;
    }
    
    public double getMainX() {
        /*SL:124*/return this.mainX;
    }
    
    public double getMainY() {
        /*SL:128*/return this.mainY;
    }
    
    public double getMainZ() {
        /*SL:132*/return this.mainZ;
    }
    
    public double getOffX() {
        /*SL:136*/return this.offX;
    }
    
    public double getOffY() {
        /*SL:140*/return this.offY;
    }
    
    public double getOffZ() {
        /*SL:144*/return this.offZ;
    }
    
    public double getMainRAngel() {
        /*SL:148*/return this.mainRAngel;
    }
    
    public double getMainRx() {
        /*SL:152*/return this.mainRx;
    }
    
    public double getMainRy() {
        /*SL:156*/return this.mainRy;
    }
    
    public double getMainRz() {
        /*SL:160*/return this.mainRz;
    }
    
    public double getOffRAngel() {
        /*SL:164*/return this.offRAngel;
    }
    
    public double getOffRx() {
        /*SL:168*/return this.offRx;
    }
    
    public double getOffRy() {
        /*SL:172*/return this.offRy;
    }
    
    public double getOffRz() {
        /*SL:176*/return this.offRz;
    }
    
    public double getMainHandScaleX() {
        /*SL:180*/return this.mainHandScaleX;
    }
    
    public double getMainHandScaleY() {
        /*SL:184*/return this.mainHandScaleY;
    }
    
    public double getMainHandScaleZ() {
        /*SL:188*/return this.mainHandScaleZ;
    }
    
    public double getOffHandScaleX() {
        /*SL:192*/return this.offHandScaleX;
    }
    
    public double getOffHandScaleY() {
        /*SL:196*/return this.offHandScaleY;
    }
    
    public double getOffHandScaleZ() {
        /*SL:200*/return this.offHandScaleZ;
    }
}
