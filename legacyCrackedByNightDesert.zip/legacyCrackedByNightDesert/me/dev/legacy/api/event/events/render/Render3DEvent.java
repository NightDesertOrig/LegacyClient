package me.dev.legacy.api.event.events.render;

import me.dev.legacy.api.event.EventStage;

public class Render3DEvent extends EventStage
{
    private float partialTicks;
    
    public Render3DEvent(final float a1) {
        this.partialTicks = a1;
    }
    
    public float getPartialTicks() {
        /*SL:14*/return this.partialTicks;
    }
}
