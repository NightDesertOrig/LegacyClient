package me.dev.legacy.api.event.events.block;

import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import me.dev.legacy.api.event.EventStage;

public class BlockCollisionBoundingBoxEvent extends EventStage
{
    private BlockPos pos;
    private AxisAlignedBB _boundingBox;
    
    public BlockCollisionBoundingBoxEvent(final BlockPos a1) {
        this.pos = a1;
    }
    
    public BlockPos getPos() {
        /*SL:17*/return this.pos;
    }
    
    public AxisAlignedBB getBoundingBox() {
        /*SL:21*/return this._boundingBox;
    }
    
    public void setBoundingBox(final AxisAlignedBB a1) {
        /*SL:25*/this._boundingBox = a1;
    }
}
