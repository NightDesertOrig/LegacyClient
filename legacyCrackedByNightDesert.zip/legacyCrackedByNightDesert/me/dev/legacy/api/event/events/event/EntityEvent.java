package me.dev.legacy.api.event.events.event;

import net.minecraft.entity.Entity;
import me.dev.legacy.api.event.EventStage;

public class EntityEvent extends EventStage
{
    private Entity entity;
    
    public EntityEvent(final Entity a1) {
        this.entity = a1;
    }
    
    public Entity getEntity() {
        /*SL:16*/return this.entity;
    }
    
    public static class EntityCollision extends EntityEvent
    {
        double x;
        double y;
        double z;
        
        public EntityCollision(final Entity a1, final double a2, final double a3, final double a4) {
            super(a1);
            this.x = a2;
            this.y = a3;
            this.z = a4;
        }
        
        public double getX() {
            /*SL:30*/return this.x;
        }
        
        public double getY() {
            /*SL:34*/return this.y;
        }
        
        public double getZ() {
            /*SL:38*/return this.z;
        }
        
        public void setX(final double a1) {
            /*SL:42*/this.x = a1;
        }
        
        public void setY(final double a1) {
            /*SL:46*/this.y = a1;
        }
        
        public void setZ(final double a1) {
            /*SL:50*/this.z = a1;
        }
    }
}
