package me.dev.legacy.api.event.events.move;

import me.dev.legacy.api.event.EventStage;

public class UpdateWalkingPlayerEvent extends EventStage
{
    public UpdateWalkingPlayerEvent(final int a1) {
        super(a1);
    }
}
