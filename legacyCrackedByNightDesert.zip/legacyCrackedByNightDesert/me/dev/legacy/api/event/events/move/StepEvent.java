package me.dev.legacy.api.event.events.move;

import net.minecraft.entity.Entity;
import net.minecraftforge.fml.common.eventhandler.Cancelable;
import me.dev.legacy.api.event.EventStage;

@Cancelable
public class StepEvent extends EventStage
{
    private final Entity entity;
    private float height;
    
    public StepEvent(final int a1, final Entity a2) {
        super(a1);
        this.entity = a2;
        this.height = a2.field_70138_W;
    }
    
    public Entity getEntity() {
        /*SL:20*/return this.entity;
    }
    
    public float getHeight() {
        /*SL:24*/return this.height;
    }
    
    public void setHeight(final float a1) {
        /*SL:28*/this.height = a1;
    }
}
