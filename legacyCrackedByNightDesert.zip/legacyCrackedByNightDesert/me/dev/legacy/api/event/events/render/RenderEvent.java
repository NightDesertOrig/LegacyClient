package me.dev.legacy.api.event.events.render;

import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.util.math.Vec3d;
import me.dev.legacy.api.event.EventStage;

public class RenderEvent extends EventStage
{
    private Vec3d renderPos;
    private Tessellator tessellator;
    private final float partialTicks;
    
    public void resetTranslation() {
        /*SL:14*/this.setTranslation(this.renderPos);
    }
    
    public Vec3d getRenderPos() {
        /*SL:18*/return this.renderPos;
    }
    
    public BufferBuilder getBuffer() {
        /*SL:22*/return this.tessellator.func_178180_c();
    }
    
    public Tessellator getTessellator() {
        /*SL:26*/return this.tessellator;
    }
    
    public RenderEvent(final Tessellator a1, final Vec3d a2, final float a3) {
        this.tessellator = a1;
        this.renderPos = a2;
        this.partialTicks = a3;
    }
    
    public void setTranslation(final Vec3d a1) {
        /*SL:36*/this.getBuffer().func_178969_c(-a1.field_72450_a, -a1.field_72448_b, -a1.field_72449_c);
    }
    
    public float getPartialTicks() {
        /*SL:40*/return this.partialTicks;
    }
}
