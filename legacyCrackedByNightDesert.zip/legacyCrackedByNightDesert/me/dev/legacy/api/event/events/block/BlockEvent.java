package me.dev.legacy.api.event.events.block;

import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.eventhandler.Cancelable;
import me.dev.legacy.api.event.EventStage;

@Cancelable
public class BlockEvent extends EventStage
{
    public BlockPos pos;
    public EnumFacing facing;
    
    public BlockEvent(final int a1, final BlockPos a2, final EnumFacing a3) {
        super(a1);
        this.pos = a2;
        this.facing = a3;
    }
}
