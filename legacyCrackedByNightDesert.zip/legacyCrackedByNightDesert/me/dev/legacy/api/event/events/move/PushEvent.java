package me.dev.legacy.api.event.events.move;

import net.minecraft.entity.Entity;
import net.minecraftforge.fml.common.eventhandler.Cancelable;
import me.dev.legacy.api.event.EventStage;

@Cancelable
public class PushEvent extends EventStage
{
    public Entity entity;
    public double x;
    public double y;
    public double z;
    public boolean airbone;
    
    public PushEvent(final Entity a1, final double a2, final double a3, final double a4, final boolean a5) {
        super(0);
        this.entity = a1;
        this.x = a2;
        this.y = a3;
        this.z = a4;
        this.airbone = a5;
    }
    
    public PushEvent(final int a1) {
        super(a1);
    }
    
    public PushEvent(final int a1, final Entity a2) {
        super(a1);
        this.entity = a2;
    }
}
