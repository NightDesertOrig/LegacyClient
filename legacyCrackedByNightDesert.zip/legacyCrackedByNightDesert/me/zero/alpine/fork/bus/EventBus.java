package me.zero.alpine.fork.bus;

import java.util.function.Consumer;
import java.util.Arrays;
import me.zero.alpine.fork.listener.Listener;
import me.zero.alpine.fork.listener.Listenable;

public interface EventBus
{
    void subscribe(Listenable p0);
    
    void subscribe(Listener p0);
    
    default void subscribeAll(Listenable... a1) {
        /*SL:47*/Arrays.<Listenable>stream(a1).forEach(this::subscribe);
    }
    
    default void subscribeAll(Iterable<Listenable> a1) {
        /*SL:59*/a1.forEach(this::subscribe);
    }
    
    default void subscribeAll(Listener... a1) {
        /*SL:71*/Arrays.<Listener>stream(a1).forEach(this::subscribe);
    }
    
    void unsubscribe(Listenable p0);
    
    void unsubscribe(Listener p0);
    
    default void unsubscribeAll(Listenable... a1) {
        /*SL:101*/Arrays.<Listenable>stream(a1).forEach(this::unsubscribe);
    }
    
    default void unsubscribeAll(Iterable<Listenable> a1) {
        /*SL:113*/a1.forEach(this::unsubscribe);
    }
    
    default void unsubscribeAll(Listener... a1) {
        /*SL:125*/Arrays.<Listener>stream(a1).forEach(this::unsubscribe);
    }
    
    void post(Object p0);
}
