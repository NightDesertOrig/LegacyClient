package me.zero.alpine.fork.bus;

import java.lang.annotation.Annotation;
import me.zero.alpine.fork.listener.EventHandler;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Consumer;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.Objects;
import java.util.function.Predicate;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.concurrent.ConcurrentHashMap;
import me.zero.alpine.fork.listener.Listener;
import java.util.List;
import me.zero.alpine.fork.listener.Listenable;
import java.util.Map;

public class EventManager implements EventBus
{
    private final Map<Listenable, List<Listener>> SUBSCRIPTION_CACHE;
    private final Map<Class<?>, List<Listener>> SUBSCRIPTION_MAP;
    
    public EventManager() {
        this.SUBSCRIPTION_CACHE = new ConcurrentHashMap<Listenable, List<Listener>>();
        this.SUBSCRIPTION_MAP = new ConcurrentHashMap<Class<?>, List<Listener>>();
    }
    
    @Override
    public void subscribe(final Listenable a1) {
        final List<Listener> v1 = /*EL:36*/this.SUBSCRIPTION_CACHE.computeIfAbsent(a1, a1 -> Arrays.<Field>stream(a1.getClass().getDeclaredFields()).filter(EventManager::isValidField).<Object>map(/*EL:43*/a2 -> asListener(a1, a2)).filter(/*EL:44*/Objects::nonNull).<List<? super Object>, ?>collect((Collector<? super Object, ?, List<? super Object>>)Collectors.<Object>toList()));
        v1.forEach(this::subscribe);
    }
    
    @Override
    public void subscribe(final Listener a1) {
        List<Listener> v1;
        int v2;
        for (/*SL:48*/v1 = this.SUBSCRIPTION_MAP.computeIfAbsent(a1.getTarget(), a1 -> new CopyOnWriteArrayList()), /*SL:50*/v2 = 0; /*EL:51*/v2 < v1.size() && /*EL:52*/a1.getPriority() <= v1.get(v2).getPriority(); ++v2) {}
        /*SL:57*/v1.add(v2, a1);
    }
    
    @Override
    public void unsubscribe(final Listenable a1) {
        final List<Listener> v1 = /*EL:62*/this.SUBSCRIPTION_CACHE.get(a1);
        /*SL:63*/if (v1 == null) {
            /*SL:64*/return;
        }
        /*SL:66*/this.SUBSCRIPTION_MAP.values().forEach(a2 -> a2.removeIf(v1::contains));
    }
    
    @Override
    public void unsubscribe(final Listener a1) {
        /*SL:71*/this.SUBSCRIPTION_MAP.get(a1.getTarget()).removeIf(a2 -> a2.equals(a1));
    }
    
    @Override
    public void post(final Object a1) {
        final List<Listener> v1 = /*EL:77*/this.SUBSCRIPTION_MAP.get(a1.getClass());
        /*SL:78*/if (v1 != null) {
            /*SL:79*/v1.forEach(a2 -> a2.invoke(a1));
        }
    }
    
    private static boolean isValidField(final Field a1) {
        /*SL:93*/return a1.isAnnotationPresent(EventHandler.class) && Listener.class.isAssignableFrom(a1.getType());
    }
    
    private static Listener asListener(final Listenable v-1, final Field v0) {
        try {
            final boolean a1 = /*EL:108*/v0.isAccessible();
            /*SL:109*/v0.setAccessible(true);
            final Listener a2 = /*EL:110*/(Listener)v0.get(v-1);
            /*SL:111*/v0.setAccessible(a1);
            /*SL:113*/if (a2 == null) {
                /*SL:114*/return null;
            }
            /*SL:116*/return a2;
        }
        catch (IllegalAccessException v) {
            /*SL:118*/return null;
        }
    }
}
