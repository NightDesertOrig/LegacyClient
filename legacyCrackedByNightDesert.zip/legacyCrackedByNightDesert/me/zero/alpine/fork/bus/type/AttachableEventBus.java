package me.zero.alpine.fork.bus.type;

import me.zero.alpine.fork.bus.EventBus;

public interface AttachableEventBus extends EventBus
{
    void attach(EventBus p0);
    
    void detach(EventBus p0);
}
