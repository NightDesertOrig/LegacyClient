package me.zero.alpine.fork.bus.type;

import me.zero.alpine.fork.listener.Listener;
import me.zero.alpine.fork.listener.Listenable;
import java.util.ArrayList;
import me.zero.alpine.fork.bus.EventBus;
import java.util.List;
import me.zero.alpine.fork.bus.EventManager;

public class AttachableEventManager extends EventManager implements AttachableEventBus
{
    private final List<EventBus> attached;
    
    public AttachableEventManager() {
        this.attached = new ArrayList<EventBus>();
    }
    
    @Override
    public void subscribe(final Listenable a1) {
        /*SL:26*/super.subscribe(a1);
        /*SL:28*/if (!this.attached.isEmpty()) {
            /*SL:29*/this.attached.forEach(a2 -> a2.subscribe(a1));
        }
    }
    
    @Override
    public void subscribe(final Listener a1) {
        /*SL:34*/super.subscribe(a1);
        /*SL:36*/if (!this.attached.isEmpty()) {
            /*SL:37*/this.attached.forEach(a2 -> a2.subscribe(a1));
        }
    }
    
    @Override
    public void unsubscribe(final Listenable a1) {
        /*SL:42*/super.unsubscribe(a1);
        /*SL:44*/if (!this.attached.isEmpty()) {
            /*SL:45*/this.attached.forEach(a2 -> a2.unsubscribe(a1));
        }
    }
    
    @Override
    public void unsubscribe(final Listener a1) {
        /*SL:50*/super.unsubscribe(a1);
        /*SL:52*/if (!this.attached.isEmpty()) {
            /*SL:53*/this.attached.forEach(a2 -> a2.unsubscribe(a1));
        }
    }
    
    @Override
    public void post(final Object a1) {
        /*SL:58*/super.post(a1);
        /*SL:60*/if (!this.attached.isEmpty()) {
            /*SL:61*/this.attached.forEach(a2 -> a2.post(a1));
        }
    }
    
    @Override
    public void attach(final EventBus a1) {
        /*SL:66*/if (!this.attached.contains(a1)) {
            /*SL:67*/this.attached.add(a1);
        }
    }
    
    @Override
    public void detach(final EventBus a1) {
        /*SL:72*/this.attached.remove(a1);
    }
}
