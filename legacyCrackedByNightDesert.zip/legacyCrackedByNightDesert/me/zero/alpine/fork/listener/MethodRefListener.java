package me.zero.alpine.fork.listener;

import java.util.function.Predicate;

public class MethodRefListener<T> extends Listener<T>
{
    private Class<T> target;
    
    public MethodRefListener(final Class<T> a1, final EventHook<T> a2, final Predicate<T>... a3) {
        super(a2, a3);
        this.target = a1;
    }
    
    public MethodRefListener(final Class<T> a1, final EventHook<T> a2, final int a3, final Predicate<T>... a4) {
        super(a2, a3, a4);
        this.target = a1;
    }
    
    @Override
    public Class<T> getTarget() {
        /*SL:32*/return this.target;
    }
}
