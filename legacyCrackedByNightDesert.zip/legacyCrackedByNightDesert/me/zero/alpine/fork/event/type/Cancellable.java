package me.zero.alpine.fork.event.type;

public class Cancellable implements ICancellable
{
    private boolean cancelled;
    
    @Override
    public void cancel() {
        /*SL:18*/this.cancelled = true;
    }
    
    @Override
    public boolean isCancelled() {
        /*SL:23*/return this.cancelled;
    }
}
