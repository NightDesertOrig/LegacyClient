package me.zero.alpine.type;

public class Cancellable
{
    private boolean cancelled;
    
    public final void cancel() {
        /*SL:22*/this.cancelled = true;
    }
    
    public final boolean isCancelled() {
        /*SL:29*/return this.cancelled;
    }
}
